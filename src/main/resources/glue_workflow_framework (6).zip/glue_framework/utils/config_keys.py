"""
utils/config_keys.py
─────────────────────────────────────────────────────────────────────────────
Canonical config key names and a normaliser that makes all YAML config dicts
key-case-insensitive.

All YAML config files now use lowercase snake_case keys (matching the spec):

  task_config.yaml                  workflow_config.yaml
  ────────────────────────────      ────────────────────────────
  taskConfig                        workflow
  service_name                        name
  auth_ref                            source_type
  query_enable                        auth_enabled
  enable                              required_auth_keys
  sourceService                       batch_config
  serviceMethod                       groups
  serviceHeader                         id
  queryParams                           dependsOn
    from                                tasks
    sourceType
    transform                       auth_config.yaml
    required                        ────────────────────────────
    defaultValue                    auth
  select_sql                          <ref_name>:
  response_key                          url
  target                                method
    catalog                             headers
    database                            json
    table                                 client_id
    mode                                  client_secret
  columns                               grant_type
    name                                scope
    raw_type                          token_json_path
    nullable                          token_prefix
    cast                              timeout_seconds
    to_date                           expiry_minutes
    format
    alias
  extra_columns
    name
    source
    nullable
    to_date
    format
    alias

The get() helper below accepts a config dict and a primary (new) key name
plus an optional legacy (old CamelCase) fallback.  This means configs written
with either casing work correctly during any transition period.
"""
from typing import Any


def cfg(d: dict, key: str, *legacy_keys, default=None) -> Any:
    """
    Lookup `key` in dict `d`.  Falls back to each `legacy_key` in order,
    then returns `default` if nothing matches.

    All comparisons are case-insensitive so neither the YAML author nor the
    code needs to worry about exact casing.

    Usage:
        url = cfg(task, "sourceservice")            # new key
        url = cfg(task, "sourceservice", "SourceService")  # + legacy fallback
    """
    lower_key = key.lower()
    # Build a lowercase → original-key index once
    index = {k.lower(): k for k in d}
    if lower_key in index:
        return d[index[lower_key]]
    for lk in legacy_keys:
        lk_lower = lk.lower()
        if lk_lower in index:
            return d[index[lk_lower]]
    return default


# ──────────────────────────────────────────────────────────────────────────────
# Canonical key constants — use these in code instead of bare strings
# ──────────────────────────────────────────────────────────────────────────────

# ── task config ───────────────────────────────────────────────────────────────
K_SERVICE_NAME    = "service_name"
K_AUTH_REF        = "auth_ref"
K_QUERY_ENABLE    = "query_enable"
K_ENABLE          = "enable"
K_SOURCE_SERVICE  = "sourceService"
K_SERVICE_METHOD  = "serviceMethod"
K_SERVICE_HEADER  = "serviceHeader"
K_QUERY_PARAMS    = "queryParams"
K_SELECT_SQL      = "select_sql"
K_RESPONSE_KEY    = "response_key"
K_CUSTOM_ENABLED  = "customEnabled"
K_BATCH_SIZE      = "batch_size"
K_MAX_WORKERS     = "max_workers"
K_RETRY_COUNT     = "retry_count"
K_RETRY_DELAY     = "retry_delay"

# ── target ────────────────────────────────────────────────────────────────────
K_TARGET          = "target"
K_CATALOG         = "catalog"
K_DATABASE        = "database"
K_TABLE           = "table"
K_MODE            = "mode"

# ── columns ───────────────────────────────────────────────────────────────────
K_COLUMNS         = "columns"
K_EXTRA_COLUMNS   = "extra_columns"
K_NAME            = "name"
K_RAW_TYPE        = "raw_type"
K_NULLABLE        = "nullable"
K_CAST            = "cast"
K_TO_DATE         = "to_date"
K_FORMAT          = "format"
K_ALIAS           = "alias"
K_SOURCE          = "source"

# ── queryParams entry ─────────────────────────────────────────────────────────
K_FROM            = "from"
K_SOURCE_TYPE     = "sourceType"
K_TRANSFORM       = "transform"
K_REQUIRED        = "required"
K_DEFAULT_VALUE   = "defaultValue"

# ── workflow config ───────────────────────────────────────────────────────────
K_WORKFLOW        = "workflow"
K_WF_NAME         = "name"
K_SOURCE_TYPE_WF  = "source_type"
K_AUTH_ENABLED    = "auth_enabled"
K_REQUIRED_AUTH   = "required_auth_keys"
K_GROUPS          = "groups"
K_GROUP_ID        = "id"
K_DEPENDS_ON      = "dependsOn"
K_TASKS           = "tasks"
K_BATCH_CFG       = "batch_config"
K_FILE_CFG        = "file_config"

# ── auth config ───────────────────────────────────────────────────────────────
K_AUTH_ROOT       = "auth"
K_URL             = "url"
K_METHOD          = "method"
K_HEADERS         = "headers"
K_JSON_BODY       = "json"
K_CLIENT_ID       = "client_id"
K_CLIENT_SECRET   = "client_secret"
K_GRANT_TYPE      = "grant_type"
K_SCOPE           = "scope"
K_TOKEN_PATH      = "token_json_path"
K_TOKEN_PREFIX    = "token_prefix"
K_TIMEOUT         = "timeout_seconds"
K_EXPIRY          = "expiry_minutes"
