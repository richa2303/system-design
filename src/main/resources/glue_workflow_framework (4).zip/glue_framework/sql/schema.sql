-- ============================================================
-- AWS Glue Workflow Orchestration — PostgreSQL Schema
-- ============================================================
-- Run once against your Aurora PostgreSQL (or RDS PostgreSQL) database.
-- The Glue JDBC connection must point at the same database.
-- ============================================================

-- Workflow execution tracking
CREATE TABLE IF NOT EXISTS glue_workflow_execution (
    workflow_execution_id   VARCHAR(64)     NOT NULL,
    workflow_name           VARCHAR(256)    NOT NULL,
    run_id                  VARCHAR(64)     NOT NULL,
    is_retry                BOOLEAN         NOT NULL DEFAULT FALSE,
    retry_of_execution_id   VARCHAR(64),
    input_params            JSONB,
    status                  VARCHAR(32)     NOT NULL,   -- STARTED | SUCCESS | FAILED
    started_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    completed_at            TIMESTAMP,
    error_message           TEXT,
    created_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    PRIMARY KEY (workflow_execution_id)
);

CREATE INDEX IF NOT EXISTS idx_wfe_name_status
    ON glue_workflow_execution (workflow_name, status);
CREATE INDEX IF NOT EXISTS idx_wfe_name_started
    ON glue_workflow_execution (workflow_name, started_at DESC);


-- Group execution tracking
CREATE TABLE IF NOT EXISTS glue_group_execution (
    group_execution_id      VARCHAR(64)     NOT NULL,
    workflow_execution_id   VARCHAR(64)     NOT NULL,
    workflow_name           VARCHAR(256)    NOT NULL,
    group_id                VARCHAR(256)    NOT NULL,
    depends_on              JSONB,
    status                  VARCHAR(32)     NOT NULL,   -- STARTED | SUCCESS | FAILED | SKIPPED
    started_at              TIMESTAMP,
    completed_at            TIMESTAMP,
    error_message           TEXT,
    created_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    PRIMARY KEY (group_execution_id),
    FOREIGN KEY (workflow_execution_id)
        REFERENCES glue_workflow_execution (workflow_execution_id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_ge_workflow_exec
    ON glue_group_execution (workflow_execution_id);
CREATE INDEX IF NOT EXISTS idx_ge_name_group
    ON glue_group_execution (workflow_name, group_id);


-- Task execution tracking
CREATE TABLE IF NOT EXISTS glue_task_execution (
    task_execution_id       VARCHAR(64)     NOT NULL,
    group_execution_id      VARCHAR(64)     NOT NULL,
    workflow_execution_id   VARCHAR(64)     NOT NULL,
    workflow_name           VARCHAR(256)    NOT NULL,
    group_id                VARCHAR(256)    NOT NULL,
    task_name               VARCHAR(256)    NOT NULL,
    service_name            VARCHAR(256),
    query_enabled           BOOLEAN         NOT NULL DEFAULT FALSE,
    status                  VARCHAR(32)     NOT NULL,   -- STARTED | SUCCESS | FAILED | SKIPPED
    query_row_count         INTEGER,
    api_batch_count         INTEGER,
    api_success_count       INTEGER,
    api_failure_count       INTEGER,
    records_written         BIGINT,
    started_at              TIMESTAMP,
    completed_at            TIMESTAMP,
    error_message           TEXT,
    stack_trace             TEXT,
    created_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    PRIMARY KEY (task_execution_id),
    FOREIGN KEY (group_execution_id)
        REFERENCES glue_group_execution (group_execution_id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_te_group_exec
    ON glue_task_execution (group_execution_id);
CREATE INDEX IF NOT EXISTS idx_te_workflow_exec
    ON glue_task_execution (workflow_execution_id);
CREATE INDEX IF NOT EXISTS idx_te_task_status
    ON glue_task_execution (workflow_name, task_name, status);


-- ============================================================
-- Useful views for monitoring / retry analysis
-- ============================================================

CREATE OR REPLACE VIEW v_workflow_summary AS
SELECT
    wfe.workflow_name,
    wfe.workflow_execution_id,
    wfe.run_id,
    wfe.is_retry,
    wfe.status                                          AS workflow_status,
    wfe.started_at,
    wfe.completed_at,
    EXTRACT(EPOCH FROM (wfe.completed_at - wfe.started_at))
                                                        AS duration_seconds,
    COUNT(DISTINCT ge.group_id)                         AS total_groups,
    COUNT(DISTINCT ge.group_id)
        FILTER (WHERE ge.status = 'SUCCESS')            AS succeeded_groups,
    COUNT(DISTINCT ge.group_id)
        FILTER (WHERE ge.status = 'FAILED')             AS failed_groups,
    COUNT(DISTINCT ge.group_id)
        FILTER (WHERE ge.status = 'SKIPPED')            AS skipped_groups,
    COUNT(te.task_execution_id)                         AS total_tasks,
    COUNT(te.task_execution_id)
        FILTER (WHERE te.status = 'SUCCESS')            AS succeeded_tasks,
    COUNT(te.task_execution_id)
        FILTER (WHERE te.status = 'FAILED')             AS failed_tasks,
    SUM(te.records_written)                             AS total_records_written
FROM       glue_workflow_execution wfe
LEFT JOIN  glue_group_execution    ge  ON ge.workflow_execution_id = wfe.workflow_execution_id
LEFT JOIN  glue_task_execution     te  ON te.workflow_execution_id = wfe.workflow_execution_id
GROUP BY   wfe.workflow_execution_id, wfe.workflow_name, wfe.run_id,
           wfe.is_retry, wfe.status, wfe.started_at, wfe.completed_at;


CREATE OR REPLACE VIEW v_retry_candidates AS
-- Shows the latest FAILED execution per workflow and what needs to re-run
SELECT
    wfe.workflow_name,
    wfe.workflow_execution_id,
    wfe.started_at                      AS failed_at,
    ge.group_id,
    ge.status                           AS group_status,
    te.task_name,
    te.status                           AS task_status,
    te.error_message
FROM (
    SELECT DISTINCT ON (workflow_name)
           workflow_execution_id, workflow_name, started_at
    FROM   glue_workflow_execution
    WHERE  status = 'FAILED'
    ORDER  BY workflow_name, started_at DESC
)                                       wfe
JOIN  glue_group_execution              ge
      ON ge.workflow_execution_id = wfe.workflow_execution_id
      AND ge.status IN ('FAILED', 'SKIPPED')
JOIN  glue_task_execution               te
      ON te.workflow_execution_id = wfe.workflow_execution_id
      AND te.group_id = ge.group_id
      AND te.status IN ('FAILED', 'SKIPPED')
ORDER BY wfe.workflow_name, ge.group_id, te.task_name;
