"""
core/workflow_orchestrator.py
Orchestrates workflow execution:
  - Resolves group dependency order into sequential execution waves
  - Runs independent groups within each wave in parallel threads
  - Runs tasks within a group sequentially
  - Tracks every state transition in Aurora RDS via RDSTracker
  - Delegates to APIIngestionEngine or FileIngestionEngine per source_type

─────────────────────────────────────────────────────────────────────────────
Retry mode
─────────────────────────────────────────────────────────────────────────────
When retry_mode=True the orchestrator:

  1. Queries RDS for the LATEST FAILED execution of this workflow.
  2. Builds the set of groups that need to re-run:
       • Groups whose status was FAILED in the previous run
       • Groups whose status was SKIPPED in the previous run (because a
         dependency group had failed — that dependency may now succeed)
  3. Builds the set of tasks that need to re-run per group:
       • Tasks whose status was FAILED
       • Tasks whose status was SKIPPED (group was skipped, so they never ran)
     Tasks that were SUCCESS in the previous run are NOT re-executed.
  4. Groups that were SUCCESS in the previous run are treated as already-done
     and their result is injected into group_statuses as True so that
     downstream dependency checks work correctly.
  5. A new workflow_execution row is created (is_retry=True,
     retry_of_execution_id=<prev_id>) so every retry is independently tracked.

─────────────────────────────────────────────────────────────────────────────
Dependency / wave model
─────────────────────────────────────────────────────────────────────────────
Groups are sorted into sequential "waves" by topological sort:
  Wave 1: all groups with dependsOn=[]
  Wave 2: groups whose every dependency is in wave 1
  …and so on.

Within a wave all groups run in parallel (ThreadPoolExecutor).
A group that finds any of its dependencies failed is SKIPPED (not FAILED),
and all its tasks are also recorded as SKIPPED.
"""
import json
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

from pyspark.sql import SparkSession

from core.auth_manager import AuthManager
from db.rds_tracker import RDSTracker, STATUS_FAILED, STATUS_SKIPPED, STATUS_SUCCESS
from ingestion.api_ingestion import APIIngestionEngine
from ingestion.file_ingestion import FileIngestionEngine
from utils.email_notifier import (
    WorkflowEmailNotifier, WorkflowReport, GroupReport, TaskReport,
    NotificationConfig,
)
from utils.logger import get_logger

logger = get_logger("orchestrator")

SOURCE_API  = "api_ingestion"
SOURCE_FILE = "file_ingestion"


class WorkflowOrchestrator:
    """Top-level orchestrator for a single workflow run."""

    def __init__(self, spark: SparkSession, tracker: RDSTracker,
                 workflow_cfg: dict, task_cfg: dict,
                 runtime_params: dict, run_id: str,
                 retry_mode: bool = False,
                 auth_config_s3_path: str = None,
                 notification_config: NotificationConfig = None):
        """
        auth_config_s3_path:  S3 URI to the auth YAML file.
        notification_config:  If provided, an HTML execution report email is
                              sent to the configured recipients after every
                              workflow run via AWS SES.
        """
        wf = workflow_cfg["Workflow"]

        self.spark          = spark
        self.tracker        = tracker
        self.wf_name        = wf["Name"]
        self.source_type    = wf.get("Source_type", SOURCE_API)
        self.auth_enabled   = wf.get("Auth_enabled", False)
        self.groups_cfg     = wf.get("Groups", [])
        self.task_map       = task_cfg.get("taskConfig", {})
        self.runtime_params = runtime_params
        self.run_id         = run_id
        self.retry_mode     = retry_mode

        # Build auth manager from S3 YAML file
        # The auth file path comes from the --auth_config_s3_path job parameter.
        batch_cfg = wf.get("Batch_config", {})
        if self.auth_enabled:
            if not auth_config_s3_path:
                raise ValueError(
                    f"Workflow '{self.wf_name}' has Auth_enabled=true but "
                    f"auth_config_s3_path was not provided. "
                    f"Pass --auth_config_s3_path to the Glue job."
                )
            self.auth_manager = AuthManager.from_s3(auth_config_s3_path)
        else:
            self.auth_manager = AuthManager({})   # no-op auth manager

        # Build ingestion engine
        # Import custom task implementations so they self-register
        import ingestion.custom.custom_task_examples  # noqa: F401

        if self.source_type == SOURCE_API:
            self.engine = APIIngestionEngine(spark, self.auth_manager, batch_cfg)
        elif self.source_type == SOURCE_FILE:
            self.engine = FileIngestionEngine(spark, wf.get("File_config", {}))
        else:
            raise ValueError(f"Unknown source_type: '{self.source_type}'")

        # Retry state — populated by _load_retry_context()
        self._prev_exec_id:       Optional[str]       = None
        # group_ids that must be re-executed (FAILED or SKIPPED in prev run)
        self._retry_group_ids:    set[str]             = set()
        # group_id → set of task_names that must be re-executed
        self._retry_task_names:   dict[str, set[str]]  = {}
        # group_ids that already succeeded in prev run — pre-seed group_statuses
        self._succeeded_group_ids: set[str]            = set()

        # Email notifier — None means notifications are disabled
        self._notifier = (
            WorkflowEmailNotifier(notification_config)
            if notification_config and notification_config.enabled
            else None
        )

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def run(self) -> bool:
        """
        Execute the full workflow.
        Returns True if every group/task succeeded, False otherwise.
        """
        # Pre-load auth tokens once upfront (before any parallel threads start)
        if self.auth_enabled:
            logger.info("Pre-loading auth tokens …")
            self.auth_manager.preload_all()

        # Load retry context BEFORE registering the new execution row
        if self.retry_mode:
            self._load_retry_context()

        # Register this run in RDS
        wf_exec_id = self.tracker.start_workflow(
            workflow_name=self.wf_name,
            run_id=self.run_id,
            input_params=self.runtime_params,
            is_retry=self.retry_mode,
            retry_of=self._prev_exec_id,
        )

        # File ingestion: unzip the source archive once before groups start
        extracted_files: dict = {}
        if self.source_type == SOURCE_FILE:
            try:
                extracted_files = self.engine.prepare_zip()
            except Exception as exc:
                logger.error(f"ZIP preparation failed: {exc}")
                self.tracker.complete_workflow(wf_exec_id, False, str(exc))
                return False

        # Pre-seed group_statuses with groups that already succeeded in a
        # previous run (retry mode).  This means their downstream dependants
        # will correctly see them as done without re-executing them.
        group_statuses: dict[str, bool] = {
            gid: True for gid in self._succeeded_group_ids
        }
        if self._succeeded_group_ids:
            logger.info(f"Retry: pre-seeding succeeded groups as done: "
                        f"{self._succeeded_group_ids}")

        # Execute groups in topologically-sorted waves
        waves = self._build_execution_waves()
        for wave_idx, wave in enumerate(waves):
            logger.info(
                f"=== Wave {wave_idx + 1}/{len(waves)}: "
                f"{[g['Id'] for g in wave]} ==="
            )
            wave_results = self._execute_wave(
                wave, wf_exec_id, group_statuses, extracted_files
            )
            group_statuses.update(wave_results)

        overall_success = all(group_statuses.values())
        self.tracker.complete_workflow(wf_exec_id, overall_success)
        logger.info(
            f"Workflow '{self.wf_name}' completed → "
            f"{'SUCCESS' if overall_success else 'FAILED'}"
        )

        # Send execution report email (never raises — errors are logged only)
        if self._notifier:
            self._send_notification(wf_exec_id)

        return overall_success

    # ------------------------------------------------------------------
    # Topological wave builder
    # ------------------------------------------------------------------

    def _build_execution_waves(self) -> list[list[dict]]:
        """
        Sort groups into sequential execution waves so that every group's
        dependencies are in an earlier wave.

        Algorithm: iteratively pull groups whose deps are all resolved.
        """
        resolved:  set[str]   = set()
        waves:     list       = []
        remaining: list[dict] = list(self.groups_cfg)

        while remaining:
            wave = [
                g for g in remaining
                if all(dep in resolved for dep in (g.get("dependsOn") or []))
            ]
            if not wave:
                unresolved_ids = [g["Id"] for g in remaining]
                raise RuntimeError(
                    f"Circular dependency or missing group references: "
                    f"{unresolved_ids}"
                )
            waves.append(wave)
            for g in wave:
                resolved.add(g["Id"])
            remaining = [g for g in remaining if g not in wave]

        return waves

    # ------------------------------------------------------------------
    # Wave execution (parallel groups)
    # ------------------------------------------------------------------

    def _execute_wave(self, wave: list[dict], wf_exec_id: str,
                      group_statuses: dict[str, bool],
                      extracted_files: dict) -> dict[str, bool]:
        """Run all groups in this wave concurrently."""
        results: dict[str, bool] = {}

        with ThreadPoolExecutor(max_workers=len(wave)) as pool:
            futures = {
                pool.submit(
                    self._execute_group,
                    grp, wf_exec_id, group_statuses, extracted_files
                ): grp["Id"]
                for grp in wave
            }
            for fut in as_completed(futures):
                gid          = futures[fut]
                results[gid] = fut.result()

        return results

    # ------------------------------------------------------------------
    # Group execution
    # ------------------------------------------------------------------

    def _execute_group(self, grp_cfg: dict, wf_exec_id: str,
                       group_statuses: dict[str, bool],
                       extracted_files: dict) -> bool:
        """
        Execute one group.

        In retry mode:
          • If the group is NOT in _retry_group_ids it already succeeded —
            return True immediately (do NOT write a new DB row; the previous
            success row still stands and group_statuses was pre-seeded).
          • If the group IS in _retry_group_ids, run it (some or all tasks
            may still be skipped at the task level if they already succeeded).

        In normal mode:
          • If any dependency group failed/was-skipped → SKIP this group.
          • Otherwise execute all tasks sequentially.
        """
        gid        = grp_cfg["Id"]
        depends_on = grp_cfg.get("dependsOn") or []
        tasks      = grp_cfg.get("Tasks", [])

        # ── Retry mode: skip groups that already succeeded ─────────────
        if self.retry_mode and gid not in self._retry_group_ids:
            logger.info(f"Group '{gid}' already succeeded in previous run — "
                        f"skipping re-execution")
            return True   # group_statuses pre-seeded with True in run()

        # ── Dependency check ───────────────────────────────────────────
        for parent in depends_on:
            parent_ok = group_statuses.get(parent)
            if not parent_ok:
                reason = (f"Dependency group '{parent}' "
                          f"failed or was skipped in this run")
                logger.warning(f"Group '{gid}' SKIPPED: {reason}")
                self.tracker.skip_group(wf_exec_id, self.wf_name,
                                        gid, depends_on, reason)
                for task_name in tasks:
                    self.tracker.skip_task(
                        "n/a", wf_exec_id, self.wf_name,
                        gid, task_name, reason
                    )
                return False

        # ── Execute group ──────────────────────────────────────────────
        group_exec_id = self.tracker.start_group(
            wf_exec_id, self.wf_name, gid, depends_on
        )

        task_results: list[bool] = []
        for task_name in tasks:
            ok = self._execute_task(
                task_name, gid, group_exec_id, wf_exec_id, extracted_files
            )
            task_results.append(ok)

        group_ok = all(task_results)
        error_msg = None if group_ok else "One or more tasks failed — see task logs"
        self.tracker.complete_group(group_exec_id, group_ok, error_msg)
        logger.info(f"Group '{gid}' → {'SUCCESS' if group_ok else 'FAILED'}")
        return group_ok

    # ------------------------------------------------------------------
    # Task execution
    # ------------------------------------------------------------------

    def _execute_task(self, task_name: str, gid: str,
                      group_exec_id: str, wf_exec_id: str,
                      extracted_files: dict) -> bool:
        """
        Execute one task.

        In retry mode, tasks that succeeded in the previous run are skipped.
        Tasks that were FAILED or SKIPPED (never ran) are re-executed.
        """
        task_cfg = self.task_map.get(task_name)
        if not task_cfg:
            logger.error(f"Task '{task_name}' not found in taskConfig — "
                         f"check task config YAML")
            return False

        if not task_cfg.get("Enable", True):
            logger.info(f"Task '{task_name}' is disabled (Enable=false) — skipping")
            self.tracker.skip_task(
                group_exec_id, wf_exec_id, self.wf_name,
                gid, task_name, "Task disabled via Enable=false in config"
            )
            return True   # disabled tasks do not count as failures

        # ── Retry mode: skip tasks that already succeeded ──────────────
        if self.retry_mode:
            tasks_needing_retry = self._retry_task_names.get(gid, set())
            if task_name not in tasks_needing_retry:
                logger.info(
                    f"Task '{task_name}' in group '{gid}' already succeeded "
                    f"in previous run — skipping re-execution"
                )
                return True

        # ── Start task ─────────────────────────────────────────────────
        service_name  = task_cfg.get("Service_name", task_name)
        query_enabled = task_cfg.get("Query_enable", False)

        task_exec_id = self.tracker.start_task(
            group_exec_id, wf_exec_id, self.wf_name,
            gid, task_name, service_name, query_enabled
        )

        try:
            if self.source_type == SOURCE_API:
                stats = self.engine.execute(task_cfg, self.runtime_params)
            elif self.source_type == SOURCE_FILE:
                stats = self.engine.execute(task_cfg, extracted_files)
            else:
                raise ValueError(f"Unknown source_type: '{self.source_type}'")

            self.tracker.complete_task(
                task_exec_id, True,
                query_row_count   = stats.get("query_row_count"),
                api_batch_count   = stats.get("api_batch_count"),
                api_success_count = stats.get("api_success_count"),
                api_failure_count = stats.get("api_failure_count"),
                records_written   = stats.get("records_written"),
            )
            logger.info(f"Task '{task_name}' SUCCESS | stats={stats}")
            return True

        except Exception as exc:
            err   = str(exc)
            stack = traceback.format_exc()
            logger.error(f"Task '{task_name}' FAILED: {err}\n{stack}")
            self.tracker.complete_task(
                task_exec_id, False,
                error=err[:2000],
                stack=stack[:4000],
            )
            return False

    # ------------------------------------------------------------------
    # Email notification
    # ------------------------------------------------------------------

    def _send_notification(self, wf_exec_id: str):
        """
        Query RDS for the completed execution, build a WorkflowReport,
        and send the HTML email. Errors are caught — never crashes the job.
        """
        try:
            raw    = self.tracker.get_execution_report(wf_exec_id)
            report = self._build_report(raw)
            self._notifier.send(report)
        except Exception as exc:
            logger.error(f"Notification failed (non-fatal): {exc}")

    def _build_report(self, raw: dict) -> "WorkflowReport":
        """
        Convert raw DB rows from get_execution_report() into a typed
        WorkflowReport ready for the email renderer.
        """
        import json as _json

        wf = raw.get("workflow", {})

        # ── Build group map ────────────────────────────────────────────
        group_map: dict = {}
        for g in raw.get("groups", []):
            gid       = g["group_id"]
            raw_dep   = g.get("depends_on")
            depends_on = []
            if isinstance(raw_dep, list):
                depends_on = raw_dep
            elif isinstance(raw_dep, str):
                try:
                    depends_on = _json.loads(raw_dep)
                except Exception:
                    depends_on = []

            group_map[gid] = GroupReport(
                group_id     = gid,
                depends_on   = depends_on,
                status       = g.get("status", "UNKNOWN"),
                started_at   = g.get("started_at"),
                completed_at = g.get("completed_at"),
            )

        # ── Attach tasks to their groups ───────────────────────────────
        for t in raw.get("tasks", []):
            gid = t["group_id"]
            if gid not in group_map:
                group_map[gid] = GroupReport(
                    group_id=gid, depends_on=[], status="SUCCESS",
                    started_at=None, completed_at=None,
                )
            group_map[gid].tasks.append(TaskReport(
                task_name         = t.get("task_name", ""),
                service_name      = t.get("service_name") or "",
                status            = t.get("status", "UNKNOWN"),
                started_at        = t.get("started_at"),
                completed_at      = t.get("completed_at"),
                records_written   = t.get("records_written"),
                query_row_count   = t.get("query_row_count"),
                api_success_count = t.get("api_success_count"),
                api_failure_count = t.get("api_failure_count"),
                error_message     = t.get("error_message"),
            ))

        # ── Order groups to match original config order ────────────────
        config_order = [g["Id"] for g in self.groups_cfg]

        def _rank(gr):
            try:
                return config_order.index(gr.group_id)
            except ValueError:
                return 999

        ordered = sorted(group_map.values(), key=_rank)

        return WorkflowReport(
            workflow_name = wf.get("workflow_name", self.wf_name),
            execution_id  = wf.get("workflow_execution_id", ""),
            run_id        = wf.get("run_id", self.run_id),
            status        = wf.get("status", "UNKNOWN"),
            is_retry      = bool(wf.get("is_retry", False)),
            retry_of_id   = wf.get("retry_of_execution_id"),
            started_at    = wf.get("started_at"),
            completed_at  = wf.get("completed_at"),
            groups        = ordered,
        )

    # ------------------------------------------------------------------
    # Retry context loading
    # ------------------------------------------------------------------

    def _load_retry_context(self):
        """
        Query RDS to build the full retry execution plan.

        Steps:
          1. Find the latest FAILED workflow_execution_id for this workflow.
             If none exists, disable retry mode and run everything fresh.
          2. Fetch all FAILED and SKIPPED groups → these must be re-run.
          3. Derive succeeded groups (all groups minus failed/skipped) →
             used to pre-seed group_statuses so dependency checks work.
          4. Fetch all FAILED and SKIPPED tasks → these must be re-run
             per group.  (Tasks that were SUCCESS are left out — they will
             be skipped by _execute_task.)

        After this method:
          self._prev_exec_id        — the execution ID being retried
          self._retry_group_ids     — set of group IDs to re-run
          self._retry_task_names    — {group_id: {task_name, …}} to re-run
          self._succeeded_group_ids — group IDs to pre-seed as True
        """
        # ── Step 1: find the latest failed execution ───────────────────
        prev_id = self.tracker.get_latest_failed_execution_id(self.wf_name)
        if not prev_id:
            logger.warning(
                f"Retry mode requested for workflow '{self.wf_name}' but no "
                f"FAILED execution exists in RDS — running full workflow instead."
            )
            self.retry_mode = False
            return

        self._prev_exec_id = prev_id
        logger.info(f"Retry: targeting previous failed execution {prev_id}")

        # ── Step 2: groups that need re-running ────────────────────────
        # FAILED  = group started, at least one task failed
        # SKIPPED = group never started because a dependency failed
        groups_to_retry = self.tracker.get_groups_to_retry(prev_id)
        self._retry_group_ids = {g["group_id"] for g in groups_to_retry}

        # ── Step 3: groups that already succeeded (pre-seed) ───────────
        # All group IDs defined in the workflow config
        all_configured_group_ids = {g["Id"] for g in self.groups_cfg}
        # Succeeded = configured - (failed ∪ skipped)
        self._succeeded_group_ids = (
            all_configured_group_ids - self._retry_group_ids
        )

        logger.info(
            f"Retry plan:\n"
            f"  Groups to re-run  : {sorted(self._retry_group_ids)}\n"
            f"  Groups pre-seeded : {sorted(self._succeeded_group_ids)}"
        )

        # ── Step 4: tasks that need re-running ─────────────────────────
        # FAILED  = task started and threw an exception
        # SKIPPED = task never started because its group was skipped
        # (Tasks with status SUCCESS are NOT included — they won't re-run)
        tasks_to_retry = self.tracker.get_tasks_to_retry(prev_id)
        for t in tasks_to_retry:
            gid       = t["group_id"]
            task_name = t["task_name"]
            self._retry_task_names.setdefault(gid, set()).add(task_name)

        # Log per-group retry task breakdown
        for gid, task_set in self._retry_task_names.items():
            logger.info(f"  Tasks to re-run in '{gid}': {sorted(task_set)}")

        # Sanity: warn about tasks in retry groups that have NO tasks listed
        # (means all their tasks succeeded — group failed for another reason)
        for gid in self._retry_group_ids:
            if gid not in self._retry_task_names:
                logger.warning(
                    f"Group '{gid}' is in retry list but has no failed/skipped "
                    f"tasks recorded — all tasks may have succeeded before the "
                    f"group-level failure.  Group will re-run and tasks will be "
                    f"skipped individually."
                )
                self._retry_task_names[gid] = set()   # empty → all tasks skipped
