"""
utils/config_loader.py
Loads task and workflow YAML configs from S3.
Config file S3 paths are resolved from AWS Parameter Store using naming convention:
  /{workflow_name}/task_config_s3_path
  /{workflow_name}/workflow_config_s3_path
"""
import io
import boto3
import yaml
from utils.logger import get_logger

logger = get_logger("config_loader")


class ConfigLoader:
    """Resolves and loads workflow/task config YAMLs from S3."""

    TASK_CONFIG_PARAM_SUFFIX    = "_task_config_s3_path"
    WORKFLOW_CONFIG_PARAM_SUFFIX = "_workflow_config_s3_path"

    def __init__(self, param_store_prefix: str = "/glue/workflows"):
        self.ssm    = boto3.client("ssm")
        self.s3     = boto3.client("s3")
        self.prefix = param_store_prefix.rstrip("/")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_configs(self, workflow_name: str) -> tuple[dict, dict]:
        """Return (task_config, workflow_config) for the given workflow."""
        task_path     = self._get_s3_path(workflow_name, self.TASK_CONFIG_PARAM_SUFFIX)
        workflow_path = self._get_s3_path(workflow_name, self.WORKFLOW_CONFIG_PARAM_SUFFIX)

        logger.info(f"Loading task config from s3: {task_path}")
        logger.info(f"Loading workflow config from s3: {workflow_path}")

        task_cfg     = self._read_yaml_from_s3(task_path)
        workflow_cfg = self._read_yaml_from_s3(workflow_path)
        return task_cfg, workflow_cfg

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _get_s3_path(self, workflow_name: str, suffix: str) -> str:
        param_name = f"{self.prefix}/{workflow_name}{suffix}"
        logger.info(f"Fetching SSM parameter: {param_name}")
        resp = self.ssm.get_parameter(Name=param_name, WithDecryption=False)
        return resp["Parameter"]["Value"]

    def _read_yaml_from_s3(self, s3_uri: str) -> dict:
        """Read s3://bucket/key and parse as YAML."""
        bucket, key = self._parse_s3_uri(s3_uri)
        obj = self.s3.get_object(Bucket=bucket, Key=key)
        content = obj["Body"].read().decode("utf-8")
        return yaml.safe_load(content)

    @staticmethod
    def _parse_s3_uri(uri: str) -> tuple[str, str]:
        assert uri.startswith("s3://"), f"Invalid S3 URI: {uri}"
        parts  = uri[5:].split("/", 1)
        bucket = parts[0]
        key    = parts[1] if len(parts) > 1 else ""
        return bucket, key
