"""
ingestion/custom/base_custom_task.py
─────────────────────────────────────────────────────────────────────────────
Base class for custom ingestion tasks.

What "custom" means
─────────────────────────────────────────────────────────────────────────────
In the generic flow, query parameters are resolved automatically from a
Select_SQL query + the queryParams config block.  Custom tasks are needed
when that automatic derivation is not enough — for example:

  • Params require business-logic computation (date arithmetic, ID padding,
    currency conversion, conditional branching, etc.)
  • Params come from multiple sources that must be combined (two SQL queries
    cross-joined, a lookup table applied, a static list hard-coded in code)
  • The same endpoint must be called multiple times with different param
    structures in a single task
  • Params depend on the response of a *previous* API call in the same task

The ONLY thing a custom task must implement is build_params().
Everything else — calling the API with token-refresh, collecting responses,
transforming records, writing to Iceberg — is handled by this base class.

Contract
─────────────────────────────────────────────────────────────────────────────
Subclass MUST implement:

    def build_params(self) -> list[dict]:
        \"\"\"
        Return a list of parameter dicts.  Each dict becomes one API call.
        Keys in each dict must match what the API expects as query/body params.
        These same dicts are passed as resolved_params to transform_row() so
        Extra_columns with Source=query_param can reference them by name.
        \"\"\"

Subclass MAY override:

    def validate_config(self):
        # add task-specific YAML config checks
        super().validate_config()
        ...

Helpers available to subclasses (call from build_params or anywhere):

    self.run_sql(sql)               → list[dict]   run Spark SQL
    self.call_api(params)           → list[dict]   one API call, returns items
    self.call_api_batch(param_list) → list[dict]   parallel batched API calls
    self.get_resolved_headers()     → dict         headers with live auth token
    self.runtime_params             → dict         job-level runtime params
    self.task_cfg                   → dict         full task config block
    self.logger                     → Logger

Full execution flow (orchestrated by execute() — do NOT override):
    1. build_params()   → list of param dicts
    2. call_api_batch() → all API responses collected in parallel
    3. transform_row()  → column mapping + extra_columns enrichment applied
    4. write_to_iceberg() → Spark writeTo Iceberg

Task config YAML example
─────────────────────────────────────────────────────────────────────────────
Custom_config.my_task:
  Service_name: my_custom_task        # must match @register_custom_task key
  CustomEnabled: true
  Enable: true
  Auth_ref: type1_auth_token
  SourceService: "https://api.example.com/v1/endpoint"
  ServiceMethod: GET
  ServiceHeader:
    Accept: "application/json"
    Authorization: "${type1_auth_token}"
  Response_key: "data"                # optional: dot-path to list in response
  Api_timeout_seconds: 30             # optional, default 30
  Target:
    Catalog: glue_emp_catalog
    Database: emp_db
    Table: my_table
    Mode: append
  Columns:
    - name: fieldA
      Alias: field_a
    - name: nested.fieldB
      Alias: field_b
  Extra_columns:
    - name: dept_code                 # must match a key in the param dict
      Source: query_param             # value stitched from the call's params
      Alias: department_code
"""
from __future__ import annotations

import time
import traceback
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Optional

import requests
from pyspark.sql import SparkSession, Row

from core.auth_manager import AuthManager
from utils.config_keys import (
    cfg,
    K_SOURCE_SERVICE, K_SERVICE_METHOD, K_SERVICE_HEADER, K_AUTH_REF,
    K_RESPONSE_KEY, K_COLUMNS, K_EXTRA_COLUMNS,
    K_TARGET, K_CATALOG, K_DATABASE, K_TABLE, K_MODE,
    K_API_TIMEOUT_SECS,
    K_TASK_BATCH_SIZE, K_TASK_MAX_WORKERS, K_TASK_RETRY_COUNT, K_TASK_RETRY_DELAY,
)
from utils.transforms import transform_row, extract_nested_value
from utils.logger import get_logger

# Fallback keys used to find the record list inside a response dict
_RESPONSE_LIST_KEYS = ("data", "results", "items", "records", "content")

_DEFAULT_BATCH_SIZE  = 50
_DEFAULT_MAX_WORKERS = 10
_DEFAULT_RETRIES     = 3
_DEFAULT_RETRY_DELAY = 5


class BaseCustomTask(ABC):
    """
    Base class for all custom ingestion tasks.
    Subclasses implement build_params(); the base class does everything else.
    """

    def __init__(self, spark: SparkSession, auth_manager: AuthManager,
                 task_cfg: dict, runtime_params: dict):
        self.spark           = spark
        self.auth_manager    = auth_manager
        self.task_cfg        = task_cfg
        self.runtime_params  = runtime_params
        self.task_name       = task_cfg.get("Service_name", self.__class__.__name__)
        self.logger          = get_logger(f"custom.{self.task_name}")

        # API call settings — can be overridden via task_cfg
        self._url          = cfg(task_cfg, K_SOURCE_SERVICE, default="") or ""
        self._method       = (cfg(task_cfg, K_SERVICE_METHOD, default="GET") or "GET").upper()
        self._timeout      = int(cfg(task_cfg, K_API_TIMEOUT_SECS, default=30) or 30)
        self._response_key = cfg(task_cfg, K_RESPONSE_KEY, default=None)
        self._columns      = cfg(task_cfg, K_COLUMNS, default=[]) or []
        self._extra_cols   = cfg(task_cfg, K_EXTRA_COLUMNS, default=[]) or []
        self._auth_ref     = cfg(task_cfg, K_AUTH_REF, default=None)

        # Batch / retry settings (from task_cfg or defaults)
        self._batch_size  = int(cfg(task_cfg, K_TASK_BATCH_SIZE,  default=_DEFAULT_BATCH_SIZE) or _DEFAULT_BATCH_SIZE)
        self._max_workers = int(cfg(task_cfg, K_TASK_MAX_WORKERS, default=_DEFAULT_MAX_WORKERS) or _DEFAULT_MAX_WORKERS)
        self._retries     = int(cfg(task_cfg, K_TASK_RETRY_COUNT, default=_DEFAULT_RETRIES) or _DEFAULT_RETRIES)
        self._retry_delay = int(cfg(task_cfg, K_TASK_RETRY_DELAY, default=_DEFAULT_RETRY_DELAY) or _DEFAULT_RETRY_DELAY)

        self.validate_config()

    # ------------------------------------------------------------------
    # Abstract — subclass MUST implement this
    # ------------------------------------------------------------------

    @abstractmethod
    def build_params(self) -> list[dict]:
        """
        Build and return the list of parameter dicts that will be used to
        drive API calls.  Each dict in the list produces exactly one API call.

        The keys in each dict should match what the API expects as query
        string parameters (GET) or JSON body fields (POST/PUT).

        These same dicts are also passed to transform_row() as resolved_params
        so that Extra_columns with Source=query_param can reference their
        values by name.

        Return an empty list to skip all API calls for this task.
        """

    # ------------------------------------------------------------------
    # Lifecycle — do NOT override (override build_params instead)
    # ------------------------------------------------------------------

    def execute(self) -> list[dict]:
        """
        Full execution lifecycle:
          1. build_params()     → list of per-call param dicts
          2. call_api_batch()   → parallel API calls, all records collected
          3. transform_row()    → column mapping + extra_columns enrichment
          4. Returns records for the caller (_execute_custom) to write to Iceberg

        The stats dict is returned by _execute_custom, not here.
        """
        self.logger.info(f"[{self.task_name}] Building custom params …")
        param_list = self.build_params()

        if not param_list:
            self.logger.warning(
                f"[{self.task_name}] build_params() returned empty list — "
                f"no API calls will be made."
            )
            return []

        self.logger.info(
            f"[{self.task_name}] build_params() produced {len(param_list)} "
            f"param set(s) → {len(param_list)} API call(s) queued"
        )

        records = self.call_api_batch(param_list)
        self.logger.info(
            f"[{self.task_name}] Collected {len(records)} records "
            f"from {len(param_list)} API calls"
        )
        return records

    # ------------------------------------------------------------------
    # API helpers — available to build_params() and execute()
    # ------------------------------------------------------------------

    def get_resolved_headers(self) -> dict:
        """
        Return ServiceHeader with the live auth token substituted in.
        Safe to call repeatedly — AuthManager handles caching and refresh.
        """
        raw = self.task_cfg.get("ServiceHeader", {}) or {}
        if self._auth_ref:
            return self.auth_manager.resolve_headers(raw, self._auth_ref)
        return dict(raw)

    def call_api(self, params: dict,
                 url: str = None,
                 method: str = None,
                 timeout: int = None) -> list[dict]:
        """
        Make one API call with the given params and return a list of
        response records (after response normalisation).

        Handles token expiry transparently — headers are resolved fresh on
        every call so long-running tasks automatically use refreshed tokens.

        Args:
            params:  The parameter dict for this specific call.
            url:     Override SourceService for this call (optional).
            method:  Override ServiceMethod for this call (optional).
            timeout: Override Api_timeout_seconds for this call (optional).

        Returns:
            List of raw response record dicts (not yet transformed).
        """
        url     = url     or self._url
        method  = (method or self._method).upper()
        timeout = timeout or self._timeout

        if not url:
            raise ValueError(
                f"[{self.task_name}] call_api: no URL — set SourceService in "
                f"task config or pass url= explicitly"
            )

        # Re-fetch headers on every call — AuthManager returns cached token
        # unless it is near-expiry, in which case it refreshes automatically
        headers = self.get_resolved_headers()

        resp = requests.request(
            method, url, headers=headers,
            params=params if method == "GET"           else None,
            json=params   if method in ("POST", "PUT") else None,
            timeout=timeout,
        )
        resp.raise_for_status()
        data = resp.json()
        return self._extract_items(data)

    def call_api_with_retry(self, params: dict,
                            url: str = None,
                            method: str = None,
                            timeout: int = None) -> tuple[list[dict], bool]:
        """
        call_api() wrapped with configurable retry and 403-aware token refresh.

        Normal retry: sleep _retry_delay seconds between attempts for any
        non-403 error.

        403 handling:
          HTTP 403 (Forbidden / token rejected by server) triggers an
          immediate force-refresh of the auth token via
          AuthManager.force_refresh_token() before the next attempt.
          No sleep is added for 403 retries — the fresh token is available
          as soon as the token endpoint responds.

        Returns (transformed_records, success_flag).
        """
        for attempt in range(1, self._retries + 1):
            try:
                items = self.call_api(params, url=url, method=method,
                                      timeout=timeout)
                # Apply column mapping + extra_columns enrichment
                records = [
                    transform_row(item, self._columns, self._extra_cols,
                                  resolved_params=params)
                    for item in items
                ]
                # Reset 403 backoff counter on success
                if self._auth_ref:
                    self.auth_manager.reset_403_counter(self._auth_ref)
                return records, True

            except requests.HTTPError as http_exc:
                status_code = (http_exc.response.status_code
                               if http_exc.response is not None else 0)

                if status_code == 403 and self._auth_ref:
                    self.logger.warning(
                        f"[{self.task_name}] HTTP 403 on attempt "
                        f"{attempt}/{self._retries} — "
                        f"force-refreshing token '{self._auth_ref}' "
                        f"and retrying"
                    )
                    if attempt < self._retries:
                        self.auth_manager.force_refresh_token(self._auth_ref)
                        continue   # retry immediately — no sleep for 403
                    else:
                        self.logger.error(
                            f"[{self.task_name}] HTTP 403 persists after "
                            f"{self._retries} attempts — giving up"
                        )
                        return [], False

                # Non-403 HTTP error — normal retry with sleep
                self.logger.warning(
                    f"[{self.task_name}] HTTP {status_code} on attempt "
                    f"{attempt}/{self._retries}: {http_exc}"
                )
                if attempt == self._retries:
                    self.logger.error(
                        f"[{self.task_name}] All retries exhausted:\n"
                        f"{traceback.format_exc()}"
                    )
                    return [], False
                time.sleep(self._retry_delay)

            except Exception as exc:
                self.logger.warning(
                    f"[{self.task_name}] Attempt {attempt}/{self._retries} "
                    f"failed: {exc}"
                )
                if attempt == self._retries:
                    self.logger.error(
                        f"[{self.task_name}] All retries exhausted:\n"
                        f"{traceback.format_exc()}"
                    )
                    return [], False
                time.sleep(self._retry_delay)

        return [], False

    def call_api_batch(self, param_list: list[dict],
                       url: str = None,
                       method: str = None) -> list[dict]:
        """
        Execute call_api_with_retry in parallel batches across the full
        param_list.  Returns all collected records from all successful calls.

        Records from failed calls are dropped (warnings are logged).

        Args:
            param_list: All parameter dicts to call the API with.
            url:        URL override applied to every call in the batch.
            method:     Method override applied to every call in the batch.
        """
        all_records: list[dict] = []
        total_success = total_failure = 0

        # Split into batches
        batches = [
            param_list[i: i + self._batch_size]
            for i in range(0, len(param_list), self._batch_size)
        ]

        for batch_idx, batch in enumerate(batches):
            self.logger.info(
                f"[{self.task_name}] Batch {batch_idx + 1}/{len(batches)} "
                f"— {len(batch)} API call(s)"
            )

            with ThreadPoolExecutor(max_workers=self._max_workers) as pool:
                futures = {
                    pool.submit(self.call_api_with_retry, p,
                                url, method): p
                    for p in batch
                }
                for fut in as_completed(futures):
                    records, ok = fut.result()
                    if ok:
                        all_records.extend(records)
                        total_success += 1
                    else:
                        total_failure += 1

        self.logger.info(
            f"[{self.task_name}] Batch complete — "
            f"{total_success} succeeded, {total_failure} failed, "
            f"{len(all_records)} records collected"
        )
        return all_records

    # ------------------------------------------------------------------
    # SQL helper — available to build_params()
    # ------------------------------------------------------------------

    def run_sql(self, sql: str) -> list[dict]:
        """
        Run a Spark SQL statement and return each result row as a dict.
        ${key} tokens in the SQL are substituted from runtime_params.
        """
        for k, v in self.runtime_params.items():
            sql = sql.replace(f"${{{k}}}", str(v))
        self.logger.info(
            f"[{self.task_name}] run_sql: "
            f"{sql[:200]}{'…' if len(sql) > 200 else ''}"
        )
        return [r.asDict() for r in self.spark.sql(sql).collect()]

    # ------------------------------------------------------------------
    # Iceberg write — called by _execute_custom in api_ingestion
    # ------------------------------------------------------------------

    def write_to_iceberg(self, records: list[dict]) -> int:
        """
        Write records to the Iceberg table defined in task_cfg.Target.
        Returns the number of records written.
        Called by the framework (_execute_custom) — subclasses do not
        normally need to call this directly.
        """
        if not records:
            return 0

        target   = cfg(self.task_cfg, K_TARGET, default={}) or {}
        catalog  = cfg(target, K_CATALOG,  default="") or ""
        database = cfg(target, K_DATABASE, default="") or ""
        table    = cfg(target, K_TABLE,    default="") or ""
        mode     = cfg(target, K_MODE, default="append") or "append"
        full_table = f"{catalog}.{database}.{table}"

        rows = [Row(**r) for r in records]
        df   = self.spark.createDataFrame(rows)

        if mode == "overwrite":
            df.writeTo(full_table).overwritePartitions()
        else:
            df.writeTo(full_table).append()

        count = df.count()
        self.logger.info(
            f"[{self.task_name}] Wrote {count} records → "
            f"{full_table} (mode={mode})"
        )
        return count

    # ------------------------------------------------------------------
    # Config validation — override to add task-specific checks
    # ------------------------------------------------------------------

    def validate_config(self):
        """
        Validate that required task config keys are present.
        Override and call super() to add task-specific validation.
        """
        for key in [K_SOURCE_SERVICE, K_TARGET]:
            if not cfg(self.task_cfg, key, default=None):
                raise ValueError(
                    f"Custom task '{self.task_name}' is missing required "
                    f"config key '{key}'"
                )

    # ------------------------------------------------------------------
    # Internal: normalise API response to a flat list of record dicts
    # ------------------------------------------------------------------

    def _extract_items(self, data: Any) -> list[dict]:
        """
        Extract the list of records from an API response.
        Tries Response_key (dot-notation), then common wrapper keys,
        then wraps a plain dict as a single-item list.
        """
        if self._response_key:
            nested = extract_nested_value(
                data if isinstance(data, dict) else {}, self._response_key
            )
            if isinstance(nested, list):
                return nested
            self.logger.warning(
                f"[{self.task_name}] Response_key='{self._response_key}' "
                f"resolved to {type(nested).__name__} — falling back"
            )

        if isinstance(data, list):
            return data

        if isinstance(data, dict):
            for key in _RESPONSE_LIST_KEYS:
                candidate = data.get(key)
                if isinstance(candidate, list):
                    return candidate
                if isinstance(candidate, dict):
                    for sub_val in candidate.values():
                        if isinstance(sub_val, list):
                            return sub_val
            return [data]

        return []
