"""
utils/config_keys.py
─────────────────────────────────────────────────────────────────────────────
Single source of truth for ALL YAML configuration key names.

Rules
─────────────────────────────────────────────────────────────────────────────
1. Every key used in any YAML config file is defined here as a constant.
2. No legacy / CamelCase keys — all keys are lowercase snake_case.
3. cfg() does an EXACT dict lookup by the constant value.
   If a key is absent and no default= is given, KeyError is raised with
   a diagnostic message listing available keys.

Usage
─────────────────────────────────────────────────────────────────────────────
    from utils.config_keys import cfg, K_SERVICE_NAME, K_AUTH_REF, ...

    service_name = cfg(task_dict, K_SERVICE_NAME)             # required key
    mode         = cfg(target,    K_MODE, default="append")   # optional key

Key reference
─────────────────────────────────────────────────────────────────────────────
  workflow_config.yaml              task_config.yaml
  ──────────────────────────────    ────────────────────────────────────────
  workflow:                         taskConfig:
    name:                             <task_key>:
    source_type:                        service_name:
    auth_enabled:                       auth_ref:
    required_auth_keys:                 query_enable:
    task_config_s3_path:                enable:
    batch_config:                       sourceService:
      batch_size:                       serviceMethod:
      max_workers:                      serviceHeader:
      retry_attempts:                   queryParams:
      retry_delay_seconds:                <param_name>:
    file_config:                            from:
    groups:                                 sourceType:
      - id:                                 transform:
        depends_on:                         required:
        tasks:                              defaultValue:
                                      select_sql:
  auth_config.yaml                    response_key:
  ──────────────────────────          customEnabled:
  auth:                               api_timeout_seconds:
    <ref_name>:                       batch_size:
      url:                            max_workers:
      method:                         retry_count:
      headers:                        retry_delay:
      json:                           target:
        client_id:                      catalog:
        client_secret:                  database:
        grant_type:                     table:
        scope:                          mode:
      token_json_path:                columns:
      token_prefix:                     - name:
      timeout_seconds:                    raw_type:
      expiry_minutes:                     nullable:
                                          cast:
                                          to_date:
                                          format:
                                          alias:
                                    extra_columns:
                                      - name:
                                          source:
                                          nullable:
                                          to_date:
                                          format:
                                          alias:
"""
from typing import Any

_SENTINEL = object()


def cfg(d: dict, key: str, default: Any = _SENTINEL) -> Any:
    """
    Exact lookup of `key` in dict `d`.

    - If `key` is present: return its value.
    - If absent and `default` is given: return `default`.
    - If absent and no `default`: raise KeyError with available keys listed.

    Examples:
        name = cfg(wf_dict, K_WF_NAME)                   # required
        mode = cfg(target,  K_MODE, default="append")    # optional
    """
    if not isinstance(d, dict):
        if default is not _SENTINEL:
            return default
        raise KeyError(
            f"Cannot look up '{key}': expected dict, "
            f"got {type(d).__name__}"
        )

    if key in d:
        return d[key]

    if default is not _SENTINEL:
        return default

    raise KeyError(
        f"Required config key '{key}' not found. "
        f"Available keys: {sorted(d.keys())}"
    )


# ──────────────────────────────────────────────────────────────────────────────
# workflow_config.yaml  —  top-level
# ──────────────────────────────────────────────────────────────────────────────
K_WORKFLOW            = "workflow"

# ──────────────────────────────────────────────────────────────────────────────
# workflow_config.yaml  —  workflow fields
# ──────────────────────────────────────────────────────────────────────────────
K_WF_NAME             = "name"
K_SOURCE_TYPE         = "source_type"
K_AUTH_ENABLED        = "auth_enabled"
K_REQUIRED_AUTH_KEYS  = "required_auth_keys"
K_TASK_CONFIG_S3_PATH = "task_config_s3_path"   # S3 URI to task config, inside workflow cfg
K_BATCH_CFG           = "batch_config"
K_FILE_CFG            = "file_config"
K_GROUPS              = "groups"

# ──────────────────────────────────────────────────────────────────────────────
# workflow_config.yaml  —  batch_config fields
# ──────────────────────────────────────────────────────────────────────────────
K_BATCH_SIZE          = "batch_size"
K_MAX_WORKERS         = "max_workers"
K_RETRY_ATTEMPTS      = "retry_attempts"
K_RETRY_DELAY_SECS    = "retry_delay_seconds"

# ──────────────────────────────────────────────────────────────────────────────
# workflow_config.yaml  —  group fields
# ──────────────────────────────────────────────────────────────────────────────
K_GROUP_ID            = "id"
K_DEPENDS_ON          = "depends_on"
K_TASKS               = "tasks"

# ──────────────────────────────────────────────────────────────────────────────
# task_config.yaml  —  top-level
# ──────────────────────────────────────────────────────────────────────────────
K_TASK_CONFIG         = "taskConfig"

# ──────────────────────────────────────────────────────────────────────────────
# task_config.yaml  —  task fields
# ──────────────────────────────────────────────────────────────────────────────
K_SERVICE_NAME        = "service_name"
K_AUTH_REF            = "auth_ref"
K_QUERY_ENABLE        = "query_enable"
K_ENABLE              = "enable"
K_SOURCE_SERVICE      = "sourceService"
K_SERVICE_METHOD      = "serviceMethod"
K_SERVICE_HEADER      = "serviceHeader"
K_QUERY_PARAMS        = "queryParams"
K_SELECT_SQL          = "select_sql"
K_RESPONSE_KEY        = "response_key"
K_CUSTOM_ENABLED      = "customEnabled"
K_API_TIMEOUT_SECS    = "api_timeout_seconds"
K_TASK_BATCH_SIZE     = "batch_size"        # per-task override (same key as batch_config)
K_TASK_MAX_WORKERS    = "max_workers"       # per-task override
K_TASK_RETRY_COUNT    = "retry_count"
K_TASK_RETRY_DELAY    = "retry_delay"

# ──────────────────────────────────────────────────────────────────────────────
# task_config.yaml  —  target fields
# ──────────────────────────────────────────────────────────────────────────────
K_TARGET              = "target"
K_CATALOG             = "catalog"
K_DATABASE            = "database"
K_TABLE               = "table"
K_MODE                = "mode"

# ──────────────────────────────────────────────────────────────────────────────
# task_config.yaml  —  columns fields
# ──────────────────────────────────────────────────────────────────────────────
K_COLUMNS             = "columns"
K_EXTRA_COLUMNS       = "extra_columns"
K_COL_NAME            = "name"
K_RAW_TYPE            = "raw_type"
K_NULLABLE            = "nullable"
K_CAST                = "cast"
K_TO_DATE             = "to_date"
K_FORMAT              = "format"
K_ALIAS               = "alias"
K_SOURCE              = "source"

# ──────────────────────────────────────────────────────────────────────────────
# task_config.yaml  —  queryParams entry fields
# ──────────────────────────────────────────────────────────────────────────────
K_QP_FROM             = "from"
K_QP_SOURCE_TYPE      = "sourceType"
K_QP_TRANSFORM        = "transform"
K_QP_REQUIRED         = "required"
K_QP_DEFAULT_VALUE    = "defaultValue"

# ──────────────────────────────────────────────────────────────────────────────
# auth_config.yaml  —  top-level
# ──────────────────────────────────────────────────────────────────────────────
K_AUTH                = "auth"

# ──────────────────────────────────────────────────────────────────────────────
# auth_config.yaml  —  auth entry fields
# ──────────────────────────────────────────────────────────────────────────────
K_AUTH_URL            = "url"
K_AUTH_METHOD         = "method"
K_AUTH_HEADERS        = "headers"
K_AUTH_JSON           = "json"
K_CLIENT_ID           = "client_id"
K_CLIENT_SECRET       = "client_secret"
K_GRANT_TYPE          = "grant_type"
K_SCOPE               = "scope"
K_TOKEN_JSON_PATH     = "token_json_path"
K_TOKEN_PREFIX        = "token_prefix"
K_TIMEOUT_SECONDS     = "timeout_seconds"
K_EXPIRY_MINUTES      = "expiry_minutes"

# ──────────────────────────────────────────────────────────────────────────────
# Glue job parameter keys  —  passed as --key=value arguments
# ──────────────────────────────────────────────────────────────────────────────
P_WORKFLOW_NAME             = "workflow_name"
P_WORKFLOW_CONFIG_S3_PATH   = "workflow_config_s3_path"
P_AUTH_CONFIG_S3_PATH       = "auth_config_s3_path"
P_GLUE_CONNECTION_NAME      = "glue_connection_name"
P_INPUT_DATE                = "input_date"
P_RETRY                     = "retry"
P_JOB_RUN_ID                = "JOB_RUN_ID"
P_NOTIFICATION_RECIPIENTS   = "notification_recipients"
P_NOTIFICATION_SENDER       = "notification_sender"
P_SMTP_HOST                 = "smtp_host"
P_SMTP_PORT                 = "smtp_port"
P_SMTP_USER                 = "smtp_user"
P_SMTP_PASSWORD_PARAM       = "smtp_password_param"
P_SMTP_USE_TLS              = "smtp_use_tls"

# ──────────────────────────────────────────────────────────────────────────────
# Fixed / enumerated values
# ──────────────────────────────────────────────────────────────────────────────
V_API_INGESTION       = "api_ingestion"
V_FILE_INGESTION      = "file_ingestion"
V_QUERY_PARAM         = "query_param"
