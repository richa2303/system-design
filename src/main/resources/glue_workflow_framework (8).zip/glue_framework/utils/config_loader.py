"""
utils/config_loader.py
─────────────────────────────────────────────────────────────────────────────
Loads all YAML configuration files from S3.

Load sequence
─────────────────────────────────────────────────────────────────────────────
  Step 1  Read workflow config
            ← from --workflow_config_s3_path (Glue job parameter)

  Step 2  Read task config
            ← path read from workflow config field: workflow.task_config_s3_path

  Step 3  Read auth config  (api_ingestion only)
            ← from --auth_config_s3_path (Glue job parameter)
            ← skipped entirely for file_ingestion workflows

Result: WorkflowBundle(workflow_cfg, task_cfg, auth_cfg | None)

Why each path comes from where it does
─────────────────────────────────────────────────────────────────────────────
  workflow_config_s3_path  — job param: changes per workflow, operator selects it
  task_config_s3_path      — workflow config field: the workflow owns its tasks,
                             so the task file path is co-located in the workflow config
  auth_config_s3_path      — job param: auth.yaml is shared across many workflows
                             and environments; keeping it outside the workflow config
                             means auth credentials can be rotated independently
                             without touching any workflow config file

Usage in glue_job_main.py
─────────────────────────────────────────────────────────────────────────────
    bundle = ConfigLoader().load(
        workflow_config_s3_path = args[P_WORKFLOW_CONFIG_S3_PATH],
        auth_config_s3_path     = args.get(P_AUTH_CONFIG_S3_PATH),
    )
    bundle.workflow_cfg   # parsed workflow YAML
    bundle.task_cfg       # parsed task YAML
    bundle.auth_cfg       # parsed auth YAML — None for file_ingestion
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import boto3
import yaml

from utils.config_keys import (
    cfg,
    K_WORKFLOW, K_SOURCE_TYPE, K_TASK_CONFIG_S3_PATH,
    K_TASK_CONFIG, K_AUTH, K_WF_NAME,
    V_API_INGESTION,
)
from utils.logger import get_logger

logger = get_logger("config_loader")


# ──────────────────────────────────────────────────────────────────────────────
# Result container
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class WorkflowBundle:
    """All parsed config dicts for one workflow execution."""
    workflow_cfg: dict           # parsed workflow_config.yaml
    task_cfg:     dict           # parsed task_config.yaml
    auth_cfg:     Optional[dict] # parsed auth.yaml — None for file_ingestion


# ──────────────────────────────────────────────────────────────────────────────
# Loader
# ──────────────────────────────────────────────────────────────────────────────

class ConfigLoader:
    """
    Loads workflow, task and (conditionally) auth configs from S3.

    workflow config path  → Glue job parameter
    task config path      → field inside workflow config
    auth config path      → Glue job parameter (api_ingestion only)
    """

    def __init__(self):
        self._s3 = boto3.client("s3")

    # ------------------------------------------------------------------
    # Primary entry point
    # ------------------------------------------------------------------

    def load(self,
             workflow_config_s3_path: str,
             auth_config_s3_path: str = None) -> WorkflowBundle:
        """
        Load all configs for a workflow run.

        Args:
            workflow_config_s3_path:
                S3 URI to the workflow YAML.
                Passed as --workflow_config_s3_path Glue job parameter.

            auth_config_s3_path:
                S3 URI to the auth YAML.
                Passed as --auth_config_s3_path Glue job parameter.
                Required when source_type == api_ingestion.
                Ignored for file_ingestion workflows.

        Returns:
            WorkflowBundle(workflow_cfg, task_cfg, auth_cfg)
        """
        # ── Step 1: workflow config ────────────────────────────────────
        logger.info(f"[Step 1] Loading workflow config: {workflow_config_s3_path}")
        workflow_cfg = self._read_yaml(workflow_config_s3_path)
        _validate_workflow_cfg(workflow_cfg, workflow_config_s3_path)

        wf          = cfg(workflow_cfg, K_WORKFLOW)
        source_type = cfg(wf, K_SOURCE_TYPE, default=V_API_INGESTION)

        # ── Step 2: task config (path lives inside workflow config) ────
        task_s3_path = cfg(wf, K_TASK_CONFIG_S3_PATH)
        logger.info(f"[Step 2] Loading task config:     {task_s3_path}")
        task_cfg = self._read_yaml(task_s3_path)
        _validate_task_cfg(task_cfg, task_s3_path)

        # ── Step 3: auth config (api_ingestion only, path from job param)
        auth_cfg = None
        if source_type == V_API_INGESTION:
            if not auth_config_s3_path:
                raise ValueError(
                    f"Workflow '{cfg(wf, K_WF_NAME)}' has "
                    f"source_type='{V_API_INGESTION}' but "
                    f"--auth_config_s3_path was not provided as a job parameter."
                )
            logger.info(f"[Step 3] Loading auth config:     {auth_config_s3_path}")
            auth_cfg = self._read_yaml(auth_config_s3_path)
            _validate_auth_cfg(auth_cfg, auth_config_s3_path)
        else:
            logger.info(
                f"[Step 3] source_type='{source_type}' — "
                f"auth config not required, skipping"
            )

        task_count = len(cfg(task_cfg, K_TASK_CONFIG, default={}))
        logger.info(
            f"Config load complete — "
            f"workflow='{cfg(wf, K_WF_NAME)}' "
            f"source_type={source_type} "
            f"tasks={task_count} "
            f"auth={'loaded' if auth_cfg else 'n/a'}"
        )
        return WorkflowBundle(
            workflow_cfg = workflow_cfg,
            task_cfg     = task_cfg,
            auth_cfg     = auth_cfg,
        )

    # ------------------------------------------------------------------
    # S3 read + YAML parse
    # ------------------------------------------------------------------

    def _read_yaml(self, s3_uri: str) -> dict:
        """Fetch an S3 object and parse it as a YAML dict."""
        bucket, key = _split_s3_uri(s3_uri)
        logger.info(f"  Reading s3://{bucket}/{key}")
        try:
            obj     = self._s3.get_object(Bucket=bucket, Key=key)
            content = obj["Body"].read().decode("utf-8")
        except Exception as exc:
            raise FileNotFoundError(
                f"Cannot read config file s3://{bucket}/{key} — {exc}"
            ) from exc

        parsed = yaml.safe_load(content)
        if not isinstance(parsed, dict):
            raise ValueError(
                f"Config file s3://{bucket}/{key} is not a YAML mapping "
                f"(got {type(parsed).__name__})"
            )
        return parsed


# ──────────────────────────────────────────────────────────────────────────────
# Validation functions (module-level so they are independently testable)
# ──────────────────────────────────────────────────────────────────────────────

def _validate_workflow_cfg(parsed: dict, path: str) -> None:
    """Raise ValueError if required workflow config structure is missing."""
    if K_WORKFLOW not in parsed:
        raise ValueError(
            f"Workflow config '{path}' must have a top-level "
            f"'{K_WORKFLOW}:' key. Found: {sorted(parsed.keys())}"
        )
    wf = parsed[K_WORKFLOW]
    for required in (K_WF_NAME, K_SOURCE_TYPE, K_TASK_CONFIG_S3_PATH):
        if required not in wf:
            raise ValueError(
                f"Workflow config '{path}': missing required field "
                f"'workflow.{required}'. Found: {sorted(wf.keys())}"
            )


def _validate_task_cfg(parsed: dict, path: str) -> None:
    """Raise ValueError if required task config structure is missing."""
    if K_TASK_CONFIG not in parsed:
        raise ValueError(
            f"Task config '{path}' must have a top-level "
            f"'{K_TASK_CONFIG}:' key. Found: {sorted(parsed.keys())}"
        )
    if not parsed[K_TASK_CONFIG]:
        raise ValueError(
            f"Task config '{path}' has an empty '{K_TASK_CONFIG}' section."
        )


def _validate_auth_cfg(parsed: dict, path: str) -> None:
    """Raise ValueError if required auth config structure is missing."""
    if K_AUTH not in parsed:
        raise ValueError(
            f"Auth config '{path}' must have a top-level "
            f"'{K_AUTH}:' key. Found: {sorted(parsed.keys())}"
        )
    if not parsed[K_AUTH]:
        raise ValueError(
            f"Auth config '{path}' has an empty '{K_AUTH}' section."
        )


# ──────────────────────────────────────────────────────────────────────────────
# S3 URI helper  (imported by other modules)
# ──────────────────────────────────────────────────────────────────────────────

def _split_s3_uri(uri: str) -> tuple[str, str]:
    """Split 's3://bucket/key/path' → ('bucket', 'key/path')."""
    if not uri.startswith("s3://"):
        raise ValueError(f"Expected an s3:// URI, got: {uri!r}")
    rest   = uri[5:]
    parts  = rest.split("/", 1)
    bucket = parts[0]
    key    = parts[1] if len(parts) > 1 else ""
    if not bucket:
        raise ValueError(f"S3 URI has no bucket: {uri!r}")
    return bucket, key


# Backward-compatible alias
_parse_s3_uri = _split_s3_uri
