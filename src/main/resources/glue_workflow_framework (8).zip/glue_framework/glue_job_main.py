"""
glue_job_main.py
─────────────────────────────────────────────────────────────────────────────
AWS Glue Job Entry Point — Workflow Orchestration Framework

Job Parameters
─────────────────────────────────────────────────────────────────────────────
  Required:
    --workflow_name               Name of the workflow to execute
    --workflow_config_s3_path     S3 URI to the workflow YAML
                                  e.g. s3://my-bucket/glue/configs/daily_data_sync_workflow_config.yaml
    --glue_connection_name        Glue JDBC connection name → PostgreSQL

  Conditionally required:
    --auth_config_s3_path         S3 URI to auth.yaml
                                  Required when workflow source_type = api_ingestion.
                                  Shared across workflows — kept as a job param so
                                  auth credentials can be rotated without editing
                                  any workflow config file.

  Optional (execution):
    --input_date                  Business date for tasks (default: today)
    --retry                       "true" to retry the last failed run
    --JOB_RUN_ID                  Injected automatically by Glue

  Optional (SMTP notifications):
    --notification_recipients     Comma-separated To: addresses
    --notification_sender         From: address
    --smtp_host                   SMTP server hostname or IP
    --smtp_port                   SMTP port (default: 587)
    --smtp_user                   SMTP username (omit for anonymous relay)
    --smtp_password_param         SSM SecureString path for SMTP password
    --smtp_use_tls                true/false — STARTTLS (default: true)

Config loading
─────────────────────────────────────────────────────────────────────────────
  workflow config  ← --workflow_config_s3_path job param
  task config      ← path read from workflow.task_config_s3_path field
  auth config      ← --auth_config_s3_path job param (api_ingestion only)
"""
import sys
from datetime import date

from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession

from utils.logger import get_logger
from utils.config_loader import ConfigLoader
from utils.email_notifier import NotificationConfig
from utils.config_keys import (
    P_WORKFLOW_NAME, P_WORKFLOW_CONFIG_S3_PATH, P_AUTH_CONFIG_S3_PATH,
    P_GLUE_CONNECTION_NAME, P_INPUT_DATE, P_RETRY, P_JOB_RUN_ID,
    P_NOTIFICATION_RECIPIENTS, P_NOTIFICATION_SENDER,
    P_SMTP_HOST, P_SMTP_PORT, P_SMTP_USER, P_SMTP_PASSWORD_PARAM, P_SMTP_USE_TLS,
)
from db.rds_tracker import RDSTracker
from core.workflow_orchestrator import WorkflowOrchestrator

logger = get_logger("glue_main")


# ─────────────────────────────────────────────────────────────────────────────
# Argument parsing
# ─────────────────────────────────────────────────────────────────────────────

REQUIRED_ARGS = [
    P_WORKFLOW_NAME,
    P_WORKFLOW_CONFIG_S3_PATH,
    P_GLUE_CONNECTION_NAME,
]

OPTIONAL_DEFAULTS = {
    P_AUTH_CONFIG_S3_PATH:      "",      # required for api_ingestion, optional param
    P_INPUT_DATE:               str(date.today()),
    P_RETRY:                    "false",
    P_NOTIFICATION_RECIPIENTS:  "",
    P_NOTIFICATION_SENDER:      "",
    P_SMTP_HOST:                "",
    P_SMTP_PORT:                "587",
    P_SMTP_USER:                "",
    P_SMTP_PASSWORD_PARAM:      "",
    P_SMTP_USE_TLS:             "true",
    P_JOB_RUN_ID:               "local_run",
}


def parse_args() -> dict:
    passed_keys   = [a.lstrip("-") for a in sys.argv if a.startswith("--")]
    keys_to_fetch = list(set(REQUIRED_ARGS) | (set(passed_keys) - {""}))
    try:
        args = getResolvedOptions(sys.argv, keys_to_fetch)
    except Exception:
        args = {k: OPTIONAL_DEFAULTS.get(k, "") for k in REQUIRED_ARGS}
    for k, v in OPTIONAL_DEFAULTS.items():
        args.setdefault(k, v)
    return args


# ─────────────────────────────────────────────────────────────────────────────
# Spark / Glue context
# ─────────────────────────────────────────────────────────────────────────────

def build_glue_context() -> tuple[GlueContext, SparkSession]:
    sc           = SparkContext.getOrCreate()
    glue_context = GlueContext(sc)
    spark        = glue_context.spark_session

    spark.conf.set(
        "spark.sql.extensions",
        "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
    )
    spark.conf.set("spark.sql.catalog.glue_emp_catalog",
                   "org.apache.iceberg.spark.SparkCatalog")
    spark.conf.set("spark.sql.catalog.glue_emp_catalog.catalog-impl",
                   "org.apache.iceberg.aws.glue.GlueCatalog")
    spark.conf.set("spark.sql.catalog.glue_emp_catalog.warehouse",
                   "s3://your-iceberg-warehouse-bucket/warehouse/")
    spark.conf.set("spark.sql.catalog.glue_emp_catalog.io-impl",
                   "org.apache.iceberg.aws.s3.S3FileIO")

    return glue_context, spark


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    args                    = parse_args()
    workflow_name           = args[P_WORKFLOW_NAME]
    workflow_config_s3_path = args[P_WORKFLOW_CONFIG_S3_PATH]
    auth_config_s3_path     = args.get(P_AUTH_CONFIG_S3_PATH, "").strip() or None
    connection_name         = args[P_GLUE_CONNECTION_NAME]
    retry_mode              = args.get(P_RETRY, "false").lower() == "true"
    run_id                  = args.get(P_JOB_RUN_ID, "local_run")

    logger.info("=" * 60)
    logger.info("Glue Workflow Job Starting")
    logger.info(f"  workflow_name           : {workflow_name}")
    logger.info(f"  workflow_config_s3_path : {workflow_config_s3_path}")
    logger.info(f"  auth_config_s3_path     : {auth_config_s3_path or '(none — file_ingestion)'}")
    logger.info(f"  glue_connection         : {connection_name}")
    logger.info(f"  retry_mode              : {retry_mode}")
    logger.info(f"  run_id                  : {run_id}")
    logger.info("=" * 60)

    # ── Step 1: Load all configs ──────────────────────────────────────
    # - workflow config: from --workflow_config_s3_path
    # - task config:     path read from workflow.task_config_s3_path
    # - auth config:     from --auth_config_s3_path (api_ingestion only)
    loader = ConfigLoader()
    bundle = loader.load(
        workflow_config_s3_path = workflow_config_s3_path,
        auth_config_s3_path     = auth_config_s3_path,
    )

    # ── Step 2: Build Glue / Spark context ───────────────────────────
    glue_context, spark = build_glue_context()

    # ── Step 3: Build RDS tracker ─────────────────────────────────────
    tracker = RDSTracker.from_glue_connection(glue_context, connection_name)

    # ── Step 4: Build runtime params ──────────────────────────────────
    runtime_params: dict = {
        "inputDate":    args.get(P_INPUT_DATE, str(date.today())),
        "workflowName": workflow_name,
    }
    _skip = {P_WORKFLOW_CONFIG_S3_PATH, P_AUTH_CONFIG_S3_PATH,
             P_GLUE_CONNECTION_NAME, P_RETRY, P_JOB_RUN_ID}
    for k, v in args.items():
        if k not in _skip:
            runtime_params.setdefault(k, v)

    # ── Step 5: Notification config ───────────────────────────────────
    notification_cfg = NotificationConfig.from_args(args)
    if notification_cfg:
        logger.info(f"Email notifications → {notification_cfg.recipients}")
    else:
        logger.info("Email notifications disabled")

    # ── Step 6: Run workflow ──────────────────────────────────────────
    try:
        orchestrator = WorkflowOrchestrator(
            spark               = spark,
            tracker             = tracker,
            workflow_cfg        = bundle.workflow_cfg,
            task_cfg            = bundle.task_cfg,
            runtime_params      = runtime_params,
            run_id              = run_id,
            retry_mode          = retry_mode,
            auth_cfg            = bundle.auth_cfg,
            notification_config = notification_cfg,
        )
        success = orchestrator.run()
    finally:
        tracker.close()

    if not success:
        logger.error("Workflow completed with FAILURES — exiting with code 1")
        sys.exit(1)

    logger.info("Glue Workflow Job completed successfully")


if __name__ == "__main__":
    main()
