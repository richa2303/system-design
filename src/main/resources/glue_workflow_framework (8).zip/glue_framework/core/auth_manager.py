"""
core/auth_manager.py
─────────────────────────────────────────────────────────────────────────────
Manages OAuth bearer tokens for API ingestion.

Auth YAML format (lowercase snake_case keys)
─────────────────────────────────────────────────────────────────────────────
auth:
  type1_auth:
    url: "https://auth.example.com/oauth/token"
    method: "POST"
    headers:
      Content-Type: "application/x-www-form-urlencoded"
    json:
      client_id: "my-client-id"
      client_secret: "my-secret"
      grant_type: "client_credentials"
      scope: "read write"
    token_json_path: "access_token"   # dot-notation path into JSON response
    token_prefix: "Bearer"            # prepended in Authorization header
    timeout_seconds: 30
    expiry_minutes: 60

  type2_auth:
    url: "https://auth2.example.com/token"
    method: "POST"
    headers:
      Content-Type: "application/x-www-form-urlencoded"
    json:
      client_id: "client2"
      client_secret: "secret2"
      grant_type: "client_credentials"
      scope: "api"
    token_json_path: "access_token"
    token_prefix: "Bearer"
    timeout_seconds: 30
    expiry_minutes: 55

Workflow config selects which tokens to load
─────────────────────────────────────────────────────────────────────────────
workflow:
  auth_enabled: true
  required_auth_keys: type1_auth, type2_auth    # comma-separated OR list

Only the keys listed in required_auth_keys are loaded at startup.
Tokens not in that list are never fetched, even if they exist in auth.yaml.

403 backoff strategy
─────────────────────────────────────────────────────────────────────────────
When the API returns HTTP 403 the cached token is evicted and a new one is
fetched.  To avoid hammering the token endpoint if the auth server is
temporarily overloaded, an exponential backoff with jitter is applied:

  attempt 1 → force_refresh then wait: base_delay * 2^0 + jitter  (e.g. 2–4s)
  attempt 2 → force_refresh then wait: base_delay * 2^1 + jitter  (e.g. 4–6s)
  attempt 3 → force_refresh then wait: base_delay * 2^2 + jitter  (e.g. 8–10s)
  …

The backoff_base_seconds (default 2) and backoff_max_seconds (default 30)
are configurable per auth key in the YAML or globally in Batch_config.
"""
import random
import threading
import time
from datetime import datetime, timedelta
from typing import Optional

import requests

from utils.config_keys import (
    cfg,
    K_AUTH, K_AUTH_URL, K_AUTH_METHOD, K_AUTH_HEADERS, K_AUTH_JSON,
    K_TOKEN_JSON_PATH, K_TOKEN_PREFIX, K_TIMEOUT_SECONDS, K_EXPIRY_MINUTES,
)
from utils.logger import get_logger
from utils.transforms import extract_nested_value

logger = get_logger("auth_manager")

_REFRESH_BUFFER_SECS  = 120   # proactive refresh 2 min before stated expiry
_DEFAULT_BACKOFF_BASE = 2     # seconds — base for exponential backoff on 403
_DEFAULT_BACKOFF_MAX  = 30    # seconds — cap for exponential backoff


# ──────────────────────────────────────────────────────────────────────────────
# Token cache entry
# ──────────────────────────────────────────────────────────────────────────────

class _TokenEntry:
    __slots__ = ("raw_token", "prefixed_token", "expires_at")

    def __init__(self, raw_token: str, prefix: str, expiry_minutes: int):
        self.raw_token      = raw_token
        self.prefixed_token = f"{prefix} {raw_token}".strip() if prefix else raw_token
        self.expires_at     = datetime.utcnow() + timedelta(minutes=expiry_minutes)

    def is_valid(self) -> bool:
        remaining = (self.expires_at - datetime.utcnow()).total_seconds()
        return remaining > _REFRESH_BUFFER_SECS


# ──────────────────────────────────────────────────────────────────────────────
# Auth Manager
# ──────────────────────────────────────────────────────────────────────────────

class AuthManager:
    """
    Thread-safe OAuth token manager.

    Driven by an S3 auth YAML file.
    Only loads the tokens listed in required_auth_keys — not the whole file.
    Force-refresh on 403 uses exponential backoff to protect the token server.
    """

    def __init__(self, auth_defs: dict,
                 backoff_base: int = _DEFAULT_BACKOFF_BASE,
                 backoff_max:  int = _DEFAULT_BACKOFF_MAX):
        """
        auth_defs      : parsed Auth section of the YAML (all available defs)
        backoff_base   : base seconds for 403 exponential backoff
        backoff_max    : ceiling seconds for 403 exponential backoff
        """
        self._defs:         dict[str, dict]        = auth_defs or {}
        self._cache:        dict[str, _TokenEntry]  = {}
        self._lock           = threading.RLock()
        self._backoff_base   = backoff_base
        self._backoff_max    = backoff_max
        # Per-key 403 attempt counters (reset on success)
        self._403_attempts:  dict[str, int]         = {}

    # ------------------------------------------------------------------
    # Factory: build from S3 YAML path
    # ------------------------------------------------------------------

    @classmethod
    def from_auth_cfg(cls, auth_cfg: dict,
                      backoff_base: int = _DEFAULT_BACKOFF_BASE,
                      backoff_max:  int = _DEFAULT_BACKOFF_MAX) -> "AuthManager":
        """
        Build an AuthManager from a pre-loaded auth config dict.

        auth_cfg is the parsed content of auth.yaml — i.e. the dict that
        ConfigLoader already read from S3.  Pass auth_cfg[K_AUTH] (the
        section under the 'auth:' root key) as auth_defs.

        Keeping the S3 read outside AuthManager makes the class easier to
        test and separates concerns cleanly.
        """
        auth_defs = cfg(auth_cfg, K_AUTH, default=None)
        if not auth_defs:
            raise ValueError(
                f"auth_cfg must contain a top-level '{K_AUTH}:' key. "
                f"Found: {sorted(auth_cfg.keys()) if isinstance(auth_cfg, dict) else type(auth_cfg).__name__}"
            )
        logger.info(
            f"AuthManager initialised — {len(auth_defs)} definition(s): "
            f"{list(auth_defs.keys())}"
        )
        return cls(auth_defs, backoff_base=backoff_base, backoff_max=backoff_max)

    # ------------------------------------------------------------------
    # Selective preload — only the tokens the workflow actually needs
    # ------------------------------------------------------------------

    def preload_required(self, required_keys: list[str]):
        """
        Fetch and cache only the tokens listed in required_keys.

        required_keys comes from workflow_config:
            required_auth_keys: type1_auth, type2_auth

        Only these keys are fetched at startup.  Other keys in auth.yaml
        are completely ignored.  This prevents unnecessary token requests
        to auth servers that the current workflow doesn't use.

        Raises ValueError if a required key is not found in auth_defs.
        """
        if not required_keys:
            logger.info("No required_auth_keys specified — skipping token preload")
            return

        # Validate all required keys exist before fetching any
        missing = [k for k in required_keys if k not in self._defs]
        if missing:
            raise ValueError(
                f"required_auth_keys references token(s) not found in auth.yaml: "
                f"{missing}. Available: {list(self._defs.keys())}"
            )

        logger.info(f"Pre-loading {len(required_keys)} required token(s): {required_keys}")
        for ref_name in required_keys:
            logger.info(f"  Fetching token: '{ref_name}'")
            with self._lock:
                self._fetch_and_cache(ref_name)

    # Kept for backward compatibility — loads ALL defined tokens
    def preload_all(self):
        """Fetch all tokens defined in auth.yaml. Prefer preload_required()."""
        logger.warning(
            "preload_all() loads every token in auth.yaml. "
            "Consider using preload_required(required_keys) instead."
        )
        for ref_name in self._defs:
            with self._lock:
                self._fetch_and_cache(ref_name)

    # ------------------------------------------------------------------
    # Token access
    # ------------------------------------------------------------------

    def get_token(self, ref_name: str) -> str:
        """Return the raw token, refreshing if near-expiry. Thread-safe."""
        with self._lock:
            entry = self._cache.get(ref_name)
            if entry and entry.is_valid():
                return entry.raw_token
            logger.info(f"Token '{ref_name}' missing/near-expiry — refreshing")
            return self._fetch_and_cache(ref_name)

    def get_prefixed_token(self, ref_name: str) -> str:
        """Return the token with its configured prefix (e.g. 'Bearer <token>')."""
        with self._lock:
            entry = self._cache.get(ref_name)
            if entry and entry.is_valid():
                return entry.prefixed_token
            self._fetch_and_cache(ref_name)
            return self._cache[ref_name].prefixed_token

    def resolve_headers(self, raw_headers: dict, ref_name: str) -> dict:
        """
        Return raw_headers with every ${ref_name} placeholder replaced
        by the live prefixed token.

        Example:
            Authorization: "${type1_auth}"  →  "Bearer eyJ..."
        """
        prefixed = self.get_prefixed_token(ref_name)
        resolved = {}
        for k, v in raw_headers.items():
            if isinstance(v, str):
                v = v.replace(f"${{{ref_name}}}", prefixed)
            resolved[k] = v
        return resolved

    # ------------------------------------------------------------------
    # 403 force-refresh with exponential backoff
    # ------------------------------------------------------------------

    def force_refresh_token(self, ref_name: str) -> str:
        """
        Evict the cached token and fetch a fresh one.
        Called when the API returns HTTP 403.

        Applies exponential backoff with jitter BEFORE fetching so the
        token server is not hammered when it is having trouble.

        Backoff schedule (example with base=2, max=30):
            1st 403 → wait 2–4s   then fetch
            2nd 403 → wait 4–6s   then fetch
            3rd 403 → wait 8–10s  then fetch
            4th 403 → wait 16–18s then fetch
            5th 403 → wait 30–32s then fetch  (capped at max)

        The per-key attempt counter is reset to zero after a successful
        API call (caller must call reset_403_counter on success).
        """
        with self._lock:
            attempt = self._403_attempts.get(ref_name, 0)
            delay   = self._backoff_delay(attempt)

            logger.warning(
                f"403 force-refresh for '{ref_name}' "
                f"(attempt #{attempt + 1}, waiting {delay:.1f}s before fetch)"
            )

            self._cache.pop(ref_name, None)   # evict stale token

        # Sleep outside the lock so other threads are not blocked
        if delay > 0:
            time.sleep(delay)

        with self._lock:
            self._403_attempts[ref_name] = attempt + 1
            return self._fetch_and_cache(ref_name)

    def reset_403_counter(self, ref_name: str):
        """
        Reset the 403 backoff counter for ref_name after a successful call.
        Called by the API engines after a successful response.
        """
        with self._lock:
            self._403_attempts.pop(ref_name, None)

    def _backoff_delay(self, attempt: int) -> float:
        """
        Compute exponential backoff delay with ±1s random jitter.
            delay = min(base * 2^attempt, max) + uniform(-1, 1)
        Always >= 0.
        """
        exp     = min(self._backoff_base * (2 ** attempt), self._backoff_max)
        jitter  = random.uniform(-1.0, 1.0)
        return max(0.0, exp + jitter)

    # ------------------------------------------------------------------
    # Internal fetch + cache
    # ------------------------------------------------------------------

    def _fetch_and_cache(self, ref_name: str) -> str:
        """Fetch a fresh token from the auth endpoint and cache it."""
        auth_def = self._defs.get(ref_name)
        if not auth_def:
            raise ValueError(
                f"No auth definition for '{ref_name}'. "
                f"Available: {list(self._defs.keys())}"
            )

        url            = cfg(auth_def, K_AUTH_URL)
        method         = (cfg(auth_def, K_AUTH_METHOD,    default="POST")).upper()
        headers        = dict(cfg(auth_def, K_AUTH_HEADERS,   default={}) or {})
        body           = dict(cfg(auth_def, K_AUTH_JSON,       default={}) or {})
        token_path     = cfg(auth_def, K_TOKEN_JSON_PATH,  default="access_token")
        token_prefix   = cfg(auth_def, K_TOKEN_PREFIX,     default="")   or ""
        timeout        = int(cfg(auth_def, K_TIMEOUT_SECONDS,  default=30) or 30)
        expiry_minutes = int(cfg(auth_def, K_EXPIRY_MINUTES,   default=60) or 60)

        if not url:
            raise ValueError(f"Auth definition '{ref_name}' has no 'url' field")

        # Form-encoded vs JSON body
        content_type = (headers.get("Content-Type")
                        or headers.get("content-type")
                        or "")
        is_form = "form" in content_type.lower()

        logger.info(f"Fetching token '{ref_name}' via {method} {url}")

        if method == "POST":
            # Normalise body keys to lowercase for OAuth form fields
            form_body = {k.lower().replace(" ", "_"): v for k, v in body.items()}
            if is_form:
                resp = requests.post(url, headers=headers, data=form_body,
                                     timeout=timeout)
            else:
                resp = requests.post(url, headers=headers, json=form_body,
                                     timeout=timeout)
        elif method == "GET":
            resp = requests.get(url, headers=headers,
                                params={k.lower(): v for k, v in body.items()},
                                timeout=timeout)
        else:
            raise NotImplementedError(
                f"Auth method '{method}' not supported for '{ref_name}'"
            )

        resp.raise_for_status()
        data = resp.json()

        raw_token = extract_nested_value(data, token_path)
        if not raw_token:
            raise ValueError(
                f"token_json_path='{token_path}' not found in auth response "
                f"for '{ref_name}'. "
                f"Response keys: {list(data.keys()) if isinstance(data, dict) else type(data).__name__}"
            )

        entry = _TokenEntry(str(raw_token), token_prefix, expiry_minutes)
        self._cache[ref_name] = entry
        logger.info(
            f"Token '{ref_name}' cached — "
            f"prefix='{token_prefix}' expires_in={expiry_minutes}min "
            f"path='{token_path}'"
        )
        return entry.raw_token


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────
