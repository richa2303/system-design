"""
db/rds_tracker.py
─────────────────────────────────────────────────────────────────────────────
PostgreSQL-backed workflow orchestration state tracker.

Connection bootstrap
─────────────────────────────────────────────────────────────────────────────
The connection is obtained via GlueContext.extract_jdbc_conf(connection_name).
This returns a dict with keys:
    url      — full JDBC URL  jdbc:postgresql://host:port/database
    user     — DB username
    password — DB password (from Glue connection secrets)

We parse the JDBC URL to extract host / port / database for psycopg2.

Usage in glue_job_main.py:
    tracker = RDSTracker.from_glue_connection(glue_context, connection_name)

Tables (PostgreSQL DDL in sql/schema.sql):
  glue_workflow_execution  — one row per workflow run
  glue_group_execution     — one row per group per run
  glue_task_execution      — one row per task per run

Status values: STARTED → SUCCESS | FAILED | SKIPPED
"""
import json
import re
import uuid
from datetime import datetime
from typing import Optional

import psycopg2
import psycopg2.extras    # RealDictCursor

from utils.logger import get_logger

logger = get_logger("rds_tracker")

STATUS_STARTED = "STARTED"
STATUS_SUCCESS = "SUCCESS"
STATUS_FAILED  = "FAILED"
STATUS_SKIPPED = "SKIPPED"

# Regex to parse jdbc:postgresql://host:port/database
_JDBC_RE = re.compile(
    r"jdbc:postgresql://([^:/]+)(?::(\d+))?/([^?]+)",
    re.IGNORECASE,
)


class RDSTracker:
    """PostgreSQL workflow orchestration tracker via Glue JDBC connection."""

    def __init__(self, host: str, port: int, database: str,
                 user: str, password: str):
        self._conn_params: dict = dict(
            host=host,
            port=port,
            dbname=database,
            user=user,
            password=password,
            connect_timeout=10,
            cursor_factory=psycopg2.extras.RealDictCursor,
        )
        self._conn: Optional[psycopg2.extensions.connection] = None

    # ------------------------------------------------------------------
    # Factory: build from Glue connection name
    # ------------------------------------------------------------------

    @classmethod
    def from_glue_connection(cls, glue_context, connection_name: str) -> "RDSTracker":
        """
        Extract JDBC connection details from a named Glue connection and
        return an initialised RDSTracker.

        glue_context  — the GlueContext object from the Glue job
        connection_name — name of the Glue connection (e.g. "glue-postgres-conn")

        The Glue connection must be of type JDBC pointing at a PostgreSQL DB.
        GlueContext.extract_jdbc_conf returns:
            {
                "url":      "jdbc:postgresql://host:5432/mydb",
                "user":     "glue_user",
                "password": "s3cr3t"
            }
        """
        logger.info(f"Extracting JDBC config for Glue connection: '{connection_name}'")
        jdbc_conf = glue_context.extract_jdbc_conf(connection_name)

        jdbc_url = jdbc_conf.get("url", "")
        user     = jdbc_conf.get("user", "")
        password = jdbc_conf.get("password", "")

        match = _JDBC_RE.match(jdbc_url)
        if not match:
            raise ValueError(
                f"Cannot parse JDBC URL '{jdbc_url}' for connection "
                f"'{connection_name}'. Expected format: "
                f"jdbc:postgresql://host:port/database"
            )

        host     = match.group(1)
        port     = int(match.group(2) or 5432)
        database = match.group(3)

        logger.info(
            f"Connecting to PostgreSQL: host={host} port={port} "
            f"database={database} user={user}"
        )
        return cls(host=host, port=port, database=database,
                   user=user, password=password)

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    def _get_conn(self) -> psycopg2.extensions.connection:
        """Return a live connection, reconnecting if the socket dropped."""
        try:
            if self._conn and not self._conn.closed:
                self._conn.isolation_level   # cheap liveness check
                return self._conn
        except Exception:
            pass
        logger.debug("Opening new PostgreSQL connection …")
        self._conn = psycopg2.connect(**self._conn_params)
        self._conn.autocommit = True
        return self._conn

    def _exec(self, sql: str, params: tuple = ()):
        conn = self._get_conn()
        with conn.cursor() as cur:
            cur.execute(sql, params)

    def _fetch_one(self, sql: str, params: tuple = ()) -> Optional[dict]:
        conn = self._get_conn()
        with conn.cursor() as cur:
            cur.execute(sql, params)
            row = cur.fetchone()
            return dict(row) if row else None

    def _fetch_all(self, sql: str, params: tuple = ()) -> list[dict]:
        conn = self._get_conn()
        with conn.cursor() as cur:
            cur.execute(sql, params)
            return [dict(r) for r in cur.fetchall()]

    def close(self):
        """Explicitly close the connection (call at end of Glue job)."""
        try:
            if self._conn and not self._conn.closed:
                self._conn.close()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Workflow
    # ------------------------------------------------------------------

    def start_workflow(self, workflow_name: str, run_id: str,
                       input_params: dict = None,
                       is_retry: bool = False,
                       retry_of: str = None) -> str:
        wf_id = str(uuid.uuid4())
        self._exec(
            """INSERT INTO glue_workflow_execution
               (workflow_execution_id, workflow_name, run_id, is_retry,
                retry_of_execution_id, input_params, status, started_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
            (wf_id, workflow_name, run_id, is_retry,
             retry_of, json.dumps(input_params or {}),
             STATUS_STARTED, datetime.utcnow())
        )
        logger.info(
            f"Workflow STARTED | id={wf_id} name={workflow_name} retry={is_retry}"
        )
        return wf_id

    def complete_workflow(self, wf_exec_id: str, success: bool,
                          error: str = None):
        status = STATUS_SUCCESS if success else STATUS_FAILED
        self._exec(
            """UPDATE glue_workflow_execution
               SET status=%s, completed_at=%s, error_message=%s, updated_at=%s
               WHERE workflow_execution_id=%s""",
            (status, datetime.utcnow(), error, datetime.utcnow(), wf_exec_id)
        )
        logger.info(f"Workflow {wf_exec_id} → {status}")

    # ------------------------------------------------------------------
    # Group
    # ------------------------------------------------------------------

    def start_group(self, wf_exec_id: str, workflow_name: str,
                    group_id: str, depends_on: list) -> str:
        g_id = str(uuid.uuid4())
        self._exec(
            """INSERT INTO glue_group_execution
               (group_execution_id, workflow_execution_id, workflow_name,
                group_id, depends_on, status, started_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s)""",
            (g_id, wf_exec_id, workflow_name,
             group_id, json.dumps(depends_on),
             STATUS_STARTED, datetime.utcnow())
        )
        return g_id

    def complete_group(self, group_exec_id: str, success: bool,
                       error: str = None):
        status = STATUS_SUCCESS if success else STATUS_FAILED
        self._exec(
            """UPDATE glue_group_execution
               SET status=%s, completed_at=%s, error_message=%s, updated_at=%s
               WHERE group_execution_id=%s""",
            (status, datetime.utcnow(), error, datetime.utcnow(), group_exec_id)
        )

    def skip_group(self, wf_exec_id: str, workflow_name: str,
                   group_id: str, depends_on: list, reason: str):
        g_id = str(uuid.uuid4())
        self._exec(
            """INSERT INTO glue_group_execution
               (group_execution_id, workflow_execution_id, workflow_name,
                group_id, depends_on, status, error_message,
                started_at, completed_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (g_id, wf_exec_id, workflow_name, group_id,
             json.dumps(depends_on), STATUS_SKIPPED, reason,
             datetime.utcnow(), datetime.utcnow())
        )

    # ------------------------------------------------------------------
    # Task
    # ------------------------------------------------------------------

    def start_task(self, group_exec_id: str, wf_exec_id: str,
                   workflow_name: str, group_id: str,
                   task_name: str, service_name: str,
                   query_enabled: bool) -> str:
        t_id = str(uuid.uuid4())
        self._exec(
            """INSERT INTO glue_task_execution
               (task_execution_id, group_execution_id, workflow_execution_id,
                workflow_name, group_id, task_name, service_name,
                query_enabled, status, started_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (t_id, group_exec_id, wf_exec_id,
             workflow_name, group_id, task_name, service_name,
             query_enabled, STATUS_STARTED, datetime.utcnow())
        )
        return t_id

    def complete_task(self, task_exec_id: str, success: bool,
                      query_row_count: int = None,
                      api_batch_count: int = None,
                      api_success_count: int = None,
                      api_failure_count: int = None,
                      records_written: int = None,
                      error: str = None,
                      stack: str = None):
        status = STATUS_SUCCESS if success else STATUS_FAILED
        self._exec(
            """UPDATE glue_task_execution
               SET status=%s, completed_at=%s,
                   query_row_count=%s, api_batch_count=%s,
                   api_success_count=%s, api_failure_count=%s,
                   records_written=%s,
                   error_message=%s, stack_trace=%s, updated_at=%s
               WHERE task_execution_id=%s""",
            (status, datetime.utcnow(),
             query_row_count, api_batch_count,
             api_success_count, api_failure_count,
             records_written, error, stack,
             datetime.utcnow(), task_exec_id)
        )

    def skip_task(self, group_exec_id: str, wf_exec_id: str,
                  workflow_name: str, group_id: str,
                  task_name: str, reason: str):
        t_id = str(uuid.uuid4())
        self._exec(
            """INSERT INTO glue_task_execution
               (task_execution_id, group_execution_id, workflow_execution_id,
                workflow_name, group_id, task_name, service_name,
                query_enabled, status, error_message, started_at, completed_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (t_id, group_exec_id, wf_exec_id,
             workflow_name, group_id, task_name, None,
             False, STATUS_SKIPPED, reason,
             datetime.utcnow(), datetime.utcnow())
        )

    # ------------------------------------------------------------------
    # Retry helpers
    # ------------------------------------------------------------------

    def get_latest_failed_execution_id(self, workflow_name: str) -> Optional[str]:
        """
        Return the workflow_execution_id of the most recent FAILED run
        for the given workflow_name, or None if no failed run exists.
        """
        row = self._fetch_one(
            """SELECT workflow_execution_id
               FROM   glue_workflow_execution
               WHERE  workflow_name = %s
                 AND  status = %s
               ORDER  BY started_at DESC
               LIMIT  1""",
            (workflow_name, STATUS_FAILED)
        )
        return row["workflow_execution_id"] if row else None

    def get_groups_to_retry(self, wf_exec_id: str) -> list[dict]:
        """
        All FAILED + SKIPPED groups from a given execution — these must
        be re-run. Columns: group_id, depends_on (JSON str), status.
        """
        return self._fetch_all(
            """SELECT group_id, depends_on, status
               FROM   glue_group_execution
               WHERE  workflow_execution_id = %s
                 AND  status IN (%s, %s)""",
            (wf_exec_id, STATUS_FAILED, STATUS_SKIPPED)
        )

    def get_tasks_to_retry(self, wf_exec_id: str) -> list[dict]:
        """
        All FAILED + SKIPPED tasks from a given execution — these must
        be re-run. Columns: group_id, task_name, status.
        """
        return self._fetch_all(
            """SELECT group_id, task_name, status
               FROM   glue_task_execution
               WHERE  workflow_execution_id = %s
                 AND  status IN (%s, %s)""",
            (wf_exec_id, STATUS_FAILED, STATUS_SKIPPED)
        )

    def get_successful_tasks(self, wf_exec_id: str) -> list[dict]:
        """
        All SUCCESS tasks from a given execution — these are skipped in retry.
        Columns: group_id, task_name.
        """
        return self._fetch_all(
            """SELECT group_id, task_name
               FROM   glue_task_execution
               WHERE  workflow_execution_id = %s
                 AND  status = %s""",
            (wf_exec_id, STATUS_SUCCESS)
        )
