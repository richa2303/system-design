"""
ingestion/api_ingestion.py
API-based ingestion engine.

Responsibilities:
 - Execute Select_SQL via Spark when Query_enable=true → produces param rows
 - Each param row feeds one API call (query output IS the queryParams input)
 - Resolve per-call request params from queryParams config using the SQL row
 - Call APIs in configurable batches using ThreadPoolExecutor
 - Auto-refresh bearer tokens for long-running tasks (>1 hour)
 - Flatten nested JSON API responses using dot-notation column mappings
 - Enrich each response row with queryParams values via Extra_columns
 - Write all records to S3 Iceberg via Spark

─────────────────────────────────────────────────────────────────────────────
queryParams ↔ Select_SQL relationship
─────────────────────────────────────────────────────────────────────────────
When Query_enable=true the Select_SQL is run first.  Each row it returns
becomes the source of input values for ONE API call.  The queryParams section
maps SQL column names → API request param names:

    Select_SQL: "SELECT emp_department, input_date AS inputDate FROM …"
    queryParams:
      startDate:                 ← API param name sent in the request
        From: inputDate          ← column name from the SQL result row
        sourceType: query
        Transform: date:%Y-%m-%d
      Emp_department:            ← API param name
        From: emp_department     ← column name from the SQL result row
        sourceType: query

So if the SQL returns 200 rows, 200 API calls are made, each with a different
startDate / Emp_department combination.

─────────────────────────────────────────────────────────────────────────────
Extra_columns: storing queryParams alongside the API response
─────────────────────────────────────────────────────────────────────────────
After an API call returns, each response record is enriched with the param
values that were used for that call before writing to Iceberg.  Configure via:

    Extra_columns:
      - name: startDate          ← MUST match the queryParams key name exactly
        Source: query_param
        Nullable: true
        To_date: true
        Format: YYYY-MM-DD
        Alias: start_date        ← target column name in Iceberg

The `name` field is the lookup key into the resolved params dict.
No separate Param_key field is needed.

─────────────────────────────────────────────────────────────────────────────
Nested API response support
─────────────────────────────────────────────────────────────────────────────
Configure Response_key in the task config to point at a nested list:

    Response_key: data.records   ← dot-notation path to the list in the response

If Response_key is omitted the engine tries common keys (data, results, items)
and falls back to wrapping the whole response in a list.

Column names in the Columns section also support dot-notation to extract
nested fields from each response record:

    Columns:
      - name: department.name    ← extracts record["department"]["name"]
        Alias: department_name
"""
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, date
from typing import Any, Optional

import requests
from pyspark.sql import SparkSession
from pyspark.sql import Row

from core.auth_manager import AuthManager
from ingestion.custom.registry import get_custom_task_class
from utils.transforms import transform_row, extract_nested_value
from utils.logger import get_logger

logger = get_logger("api_ingestion")

_DEFAULT_BATCH_SIZE  = 50
_DEFAULT_MAX_WORKERS = 10
_DEFAULT_RETRIES     = 3
_DEFAULT_RETRY_DELAY = 5   # seconds

# Fallback keys tried when Response_key is not configured
_RESPONSE_LIST_KEYS = ("data", "results", "items", "records", "content")


class APIIngestionEngine:
    """Executes a single API-based task config."""

    def __init__(self, spark: SparkSession, auth_manager: AuthManager,
                 batch_cfg: dict):
        self.spark       = spark
        self.auth_manager = auth_manager
        self.batch_size  = batch_cfg.get("batch_size",        _DEFAULT_BATCH_SIZE)
        self.max_workers = batch_cfg.get("max_workers",       _DEFAULT_MAX_WORKERS)
        self.retry_count = batch_cfg.get("retry_attempts",    _DEFAULT_RETRIES)
        self.retry_delay = batch_cfg.get("retry_delay_seconds", _DEFAULT_RETRY_DELAY)

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def execute(self, task_cfg: dict, runtime_params: dict) -> dict:
        """
        Execute the task end-to-end and write to Iceberg.

        If CustomEnabled=true in the task config, the request is delegated
        to a registered custom task class looked up by Service_name.
        Custom tasks build their own parameter sets and call APIs directly;
        the framework only handles the final Iceberg write.

        Returns stats dict with keys:
            query_row_count, api_batch_count,
            api_success_count, api_failure_count, records_written
        """
        task_name      = task_cfg.get("Service_name", "unknown")
        custom_enabled = task_cfg.get("CustomEnabled", False)

        # ── Custom task routing ────────────────────────────────────────
        if custom_enabled:
            return self._execute_custom(task_cfg, runtime_params)

        query_enabled = task_cfg.get("Query_enable", False)
        auth_ref      = task_cfg.get("Auth_ref")
        extra_cols    = task_cfg.get("Extra_columns") or []

        if extra_cols:
            enrich_names = [e.get("Alias", e["name"]) for e in extra_cols
                            if e.get("Source") == "query_param"]
            if enrich_names:
                logger.info(f"[{task_name}] Extra_columns enrichment active "
                            f"for target columns: {enrich_names}")

        # ── Step 1: obtain input parameter rows ────────────────────────
        # When Query_enable=true: run Select_SQL → each row is one API call.
        # When false: a single empty row → one API call with no dynamic params.
        if query_enabled:
            param_rows = self._run_select_sql(task_cfg, runtime_params)
            logger.info(f"[{task_name}] SQL returned {len(param_rows)} param rows "
                        f"→ {len(param_rows)} API calls queued")
        else:
            param_rows = [{}]
            logger.info(f"[{task_name}] Query_enable=false → single API call")

        query_row_count = len(param_rows)

        # ── Step 2: batch API calls ────────────────────────────────────
        all_records: list[dict] = []
        api_success = api_failure = 0
        batches = self._make_batches(param_rows, self.batch_size)

        for batch_idx, batch in enumerate(batches):
            logger.info(f"[{task_name}] Executing batch "
                        f"{batch_idx + 1}/{len(batches)} ({len(batch)} calls)")
            results, s, f = self._execute_batch(task_cfg, batch, auth_ref,
                                                runtime_params)
            all_records.extend(results)
            api_success += s
            api_failure += f

        # ── Step 3: write to Iceberg ───────────────────────────────────
        records_written = 0
        if all_records:
            records_written = self._write_to_iceberg(task_cfg, all_records)
        else:
            logger.warning(f"[{task_name}] No records produced — nothing written.")

        return {
            "query_row_count":   query_row_count,
            "api_batch_count":   len(batches),
            "api_success_count": api_success,
            "api_failure_count": api_failure,
            "records_written":   records_written,
        }

    # ------------------------------------------------------------------
    # Custom task execution
    # ------------------------------------------------------------------

    def _execute_custom(self, task_cfg: dict, runtime_params: dict) -> dict:
        """
        Delegate to a registered custom task class identified by Service_name.

        Custom task lifecycle (all orchestrated inside the handler):
          1. handler.build_params()    — subclass builds param dicts manually
          2. handler.call_api_batch()  — base class calls API in parallel batches
                                         with token-refresh on every call
          3. transform_row()           — base class applies column mapping
                                         + extra_columns enrichment
          4. handler.write_to_iceberg()— base class writes records to Iceberg

        execute() returns the collected records; we then call write_to_iceberg
        so the Iceberg write is owned by the same handler instance that made
        the API calls (ensuring Target config is always in scope).
        """
        from ingestion.custom.registry import REGISTRY
        task_name    = task_cfg.get("Service_name", "unknown")
        custom_class = get_custom_task_class(task_name)

        if custom_class is None:
            raise ValueError(
                f"CustomEnabled=true for task '{task_name}' but no class "
                f"is registered. Available: {list(REGISTRY.keys())}. "
                f"Add @register_custom_task('{task_name}') to your class in "
                f"ingestion/custom/custom_task_examples.py (or a new file)."
            )

        logger.info(
            f"[{task_name}] Routing to custom handler: {custom_class.__name__}"
        )

        handler = custom_class(
            spark          = self.spark,
            auth_manager   = self.auth_manager,
            task_cfg       = task_cfg,
            runtime_params = runtime_params,
        )

        # execute() runs build_params → call_api_batch → transform_row
        # and returns the fully-transformed record list
        records = handler.execute()

        # Iceberg write is also owned by the handler so Target config is
        # always in scope and write path is consistent with the base class
        records_written = handler.write_to_iceberg(records)

        return {
            "query_row_count":    0,             # no Select_SQL in custom tasks
            "api_batch_count":    max(1, (len(records) // handler._batch_size) + 1),
            "api_success_count":  1 if records_written > 0 else 0,
            "api_failure_count":  0,
            "records_written":    records_written,
        }

    # ------------------------------------------------------------------
    # SQL execution
    # ------------------------------------------------------------------

    def _run_select_sql(self, task_cfg: dict, runtime_params: dict) -> list[dict]:
        """
        Run Select_SQL and return each row as a dict.
        These rows are the source of dynamic values for queryParams resolution.
        ${param} tokens in the SQL are substituted from runtime_params first.
        """
        sql = task_cfg.get("Select_SQL", "").strip()
        if not sql:
            logger.warning("Query_enable=true but Select_SQL is empty — "
                           "falling back to single empty param row")
            return [{}]

        # Substitute ${key} runtime tokens (e.g. ${inputDate})
        for k, v in runtime_params.items():
            sql = sql.replace(f"${{{k}}}", str(v))

        logger.info(f"Running Select_SQL: {sql[:300]}{'…' if len(sql) > 300 else ''}")
        df   = self.spark.sql(sql)
        rows = [row.asDict() for row in df.collect()]
        if not rows:
            logger.warning("Select_SQL returned 0 rows — no API calls will be made")
        return rows

    # ------------------------------------------------------------------
    # Batching
    # ------------------------------------------------------------------

    @staticmethod
    def _make_batches(items: list, size: int) -> list[list]:
        """Split items into chunks of at most `size`."""
        if not items:
            return [[]]
        return [items[i: i + size] for i in range(0, len(items), size)]

    # ------------------------------------------------------------------
    # Batch execution (parallel threads within a batch)
    # ------------------------------------------------------------------

    def _execute_batch(self, task_cfg: dict, param_rows: list[dict],
                       auth_ref: Optional[str],
                       runtime_params: dict) -> tuple[list, int, int]:
        """
        Execute one batch of API calls in parallel.
        Each param_row is a single SQL result row used as the input for one call.
        """
        records: list[dict] = []
        success = failure   = 0

        def call_one(sql_row: dict) -> tuple[list, bool]:
            return self._call_api_with_retry(task_cfg, sql_row, auth_ref,
                                             runtime_params)

        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futures = {pool.submit(call_one, row): row for row in param_rows}
            for fut in as_completed(futures):
                recs, ok = fut.result()
                if ok:
                    success += 1
                    records.extend(recs)
                else:
                    failure += 1

        return records, success, failure

    # ------------------------------------------------------------------
    # Single API call — retry wrapper (handles token refresh)
    # ------------------------------------------------------------------

    def _call_api_with_retry(self, task_cfg: dict, sql_row: dict,
                             auth_ref: Optional[str],
                             runtime_params: dict) -> tuple[list, bool]:
        """
        Call the API with automatic retry.
        On each attempt the auth token is re-fetched from AuthManager so that
        if it expired (> 1 hour job) the new token is used transparently.
        """
        for attempt in range(1, self.retry_count + 1):
            try:
                recs = self._call_api(task_cfg, sql_row, auth_ref, runtime_params)
                return recs, True
            except Exception as exc:
                logger.warning(f"Attempt {attempt}/{self.retry_count} failed: {exc}")
                if attempt == self.retry_count:
                    logger.error(f"All retries exhausted:\n{traceback.format_exc()}")
                    return [], False
                time.sleep(self.retry_delay)
        return [], False

    # ------------------------------------------------------------------
    # Single API call — core logic
    # ------------------------------------------------------------------

    def _call_api(self, task_cfg: dict, sql_row: dict,
                  auth_ref: Optional[str],
                  runtime_params: dict) -> list[dict]:
        """
        Make one HTTP request and return a list of transformed records.

        Flow:
          1. Resolve request params from queryParams config + sql_row values
          2. Build headers (substitute live auth token)
          3. Make HTTP request
          4. Extract the list of records from the response (nested support)
          5. Transform each record: apply column mappings + enrich with
             resolved params via Extra_columns
        """
        url         = task_cfg["SourceService"]
        method      = task_cfg.get("ServiceMethod", "GET").upper()
        raw_headers = task_cfg.get("ServiceHeader", {}) or {}
        param_defs  = task_cfg.get("queryParams", {}) or {}
        columns     = task_cfg.get("Columns", []) or []
        extra_cols  = task_cfg.get("Extra_columns", []) or []
        response_key = task_cfg.get("Response_key")   # optional dot-path to list

        # ── 1. Resolve request params ──────────────────────────────────
        # sql_row is one output row from Select_SQL.
        # resolved_params maps queryParams key names → final values.
        # This same dict is passed to transform_row for Extra_columns lookup.
        resolved_params = self._build_request_params(param_defs, sql_row,
                                                     runtime_params)

        # ── 2. Build headers with live auth token ──────────────────────
        if auth_ref:
            # AuthManager checks expiry and refreshes if needed — this is
            # what keeps long (>1h) jobs working without manual intervention
            headers = self.auth_manager.resolve_headers(raw_headers, auth_ref)
        else:
            headers = dict(raw_headers)

        # ── 3. Make HTTP request ───────────────────────────────────────
        resp = requests.request(
            method, url, headers=headers,
            params=resolved_params if method == "GET"          else None,
            json=resolved_params   if method in ("POST", "PUT") else None,
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()

        # ── 4. Extract list of records from (possibly nested) response ─
        items = self._extract_response_items(data, response_key, task_cfg)
        if not items:
            logger.debug(f"API call returned 0 items for params: {resolved_params}")

        # ── 5. Transform + enrich each record ─────────────────────────
        # resolved_params is passed so Extra_columns with Source=query_param
        # can look up values by their `name` key (same as queryParams key).
        return [
            transform_row(item, columns, extra_cols, resolved_params)
            for item in items
        ]

    # ------------------------------------------------------------------
    # Nested response extraction
    # ------------------------------------------------------------------

    def _extract_response_items(self, data: Any, response_key: Optional[str],
                                task_cfg: dict) -> list[dict]:
        """
        Extract the list of records from an API response.

        Priority:
          1. If Response_key is configured, follow that dot-notation path.
          2. Try common wrapper keys: data, results, items, records, content.
          3. If root is already a list, use it directly.
          4. Wrap the whole response object in a single-item list.
        """
        task_name = task_cfg.get("Service_name", "unknown")

        # Explicit Response_key configured — must find a list there
        if response_key:
            nested = extract_nested_value(data if isinstance(data, dict) else {},
                                          response_key)
            if isinstance(nested, list):
                return nested
            logger.warning(
                f"[{task_name}] Response_key='{response_key}' resolved to "
                f"{type(nested).__name__} (expected list) — falling back"
            )

        # Root is already a list
        if isinstance(data, list):
            return data

        # Root is a dict — try well-known wrapper keys
        if isinstance(data, dict):
            for key in _RESPONSE_LIST_KEYS:
                candidate = data.get(key)
                if isinstance(candidate, list):
                    logger.debug(f"[{task_name}] Found response list under key '{key}'")
                    return candidate
                # One level of nesting: e.g. {"data": {"records": [...]}}
                if isinstance(candidate, dict):
                    for sub_key, sub_val in candidate.items():
                        if isinstance(sub_val, list):
                            logger.debug(
                                f"[{task_name}] Found response list under "
                                f"'{key}.{sub_key}'"
                            )
                            return sub_val

            # No list found — treat the whole dict as one record
            logger.debug(
                f"[{task_name}] Response is a plain dict — wrapping as single record"
            )
            return [data]

        logger.warning(
            f"[{task_name}] Unexpected response type {type(data).__name__} — "
            f"returning empty list"
        )
        return []

    # ------------------------------------------------------------------
    # queryParams resolution
    # ------------------------------------------------------------------

    def _build_request_params(self, param_defs: dict, sql_row: dict,
                              runtime_params: dict) -> dict:
        """
        Resolve each entry in queryParams to its final value.

        For each queryParam:
          sourceType=query  → value comes from sql_row[From], fallback runtime_params[From]
          sourceType=custom → value comes from runtime_params[From], fallback DefaultValue

        Transform (e.g. "date:%Y-%m-%d") is applied after the value is resolved.

        Returns a dict keyed by the queryParams YAML key name (e.g. "startDate").
        This dict is:
          • Sent to the API as query string params (GET) or JSON body (POST/PUT)
          • Passed to transform_row so Extra_columns can reference values by name
        """
        params: dict = {}

        for param_name, spec in param_defs.items():
            source_type = spec.get("sourceType", "query")
            from_key    = spec.get("From", param_name)
            required    = spec.get("Required", False)
            default_val = spec.get("DefaultValue")
            transform   = spec.get("Transform")

            if source_type == "query":
                # Primary source is the SQL result row, fallback to runtime params
                value = sql_row.get(from_key)
                if value is None:
                    value = runtime_params.get(from_key)
            elif source_type == "custom":
                # Primary source is runtime params, fallback to DefaultValue
                value = runtime_params.get(from_key, default_val)
            else:
                value = default_val

            if value is None and required:
                raise ValueError(
                    f"Required queryParam '{param_name}' could not be resolved "
                    f"(From='{from_key}', sourceType='{source_type}'). "
                    f"SQL row keys: {list(sql_row.keys())}"
                )

            if value is not None and transform:
                value = self._apply_param_transform(value, transform)

            params[param_name] = value

        return params

    @staticmethod
    def _apply_param_transform(value: Any, transform: str) -> str:
        """Apply a transform specification, e.g. 'date:%Y-%m-%d'."""
        if transform.startswith("date:"):
            fmt = transform[5:]
            if isinstance(value, (date, datetime)):
                return value.strftime(fmt)
            for attempt_fmt in ("%Y-%m-%d", "%Y%m%d", "%d/%m/%Y"):
                try:
                    return datetime.strptime(str(value), attempt_fmt).strftime(fmt)
                except ValueError:
                    continue
        return str(value)

    # ------------------------------------------------------------------
    # Iceberg write
    # ------------------------------------------------------------------

    def _write_to_iceberg(self, task_cfg: dict, records: list[dict]) -> int:
        target     = task_cfg["Target"]
        catalog    = target["Catalog"]
        database   = target["Database"]
        table      = target["Table"]
        mode       = target.get("Mode", "append")
        full_table = f"{catalog}.{database}.{table}"

        rows = [Row(**r) for r in records]
        df   = self.spark.createDataFrame(rows)

        if mode == "overwrite":
            df.writeTo(full_table).overwritePartitions()
        else:
            df.writeTo(full_table).append()

        count = df.count()
        logger.info(f"Wrote {count} records → {full_table} (mode={mode})")
        return count
