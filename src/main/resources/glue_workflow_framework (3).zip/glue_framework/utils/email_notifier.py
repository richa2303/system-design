"""
utils/email_notifier.py
─────────────────────────────────────────────────────────────────────────────
Sends an HTML workflow execution report email via AWS SES after every
workflow run completes — success or failure.

Email structure
─────────────────────────────────────────────────────────────────────────────
  ┌─────────────────────────────────────────────────────┐
  │  Workflow Execution Report                          │
  │  Workflow : daily_data_sync                         │
  │  Execution ID : <uuid>                              │
  │  Run ID       : jr_abc123                           │
  │  Status       : ✅ SUCCESS  /  ❌ FAILED            │
  │  Started      : 2025-01-15 08:00:00 UTC             │
  │  Completed    : 2025-01-15 08:04:32 UTC             │
  │  Duration     : 4m 32s                              │
  │  Is Retry     : No                                  │
  ├─────────────────────────────────────────────────────┤
  │  Execution Summary                                  │
  │  Total Groups : 5   Succeeded : 4   Failed : 1      │
  │  Total Tasks  : 8   Succeeded : 6   Failed : 1   Skipped : 1 │
  │  Total Records Ingested : 142,830                   │
  ├─────────────────────────────────────────────────────┤
  │  Group & Task Detail Table                          │
  │  ┌────────┬──────────┬────────┬────────────────┐   │
  │  │ Group  │ Task     │ Status │ Records / Error│   │
  │  ├────────┼──────────┼────────┼────────────────┤   │
  │  │ group1 │ task1    │ ✅     │ 12,450 records │   │
  │  │ group1 │ task2    │ ❌     │ ValueError: …  │   │
  │  │ group2 │ task3    │ ⏭ Skip │ dep failed     │   │
  │  └────────┴──────────┴────────┴────────────────┘   │
  └─────────────────────────────────────────────────────┘

Configuration
─────────────────────────────────────────────────────────────────────────────
Pass a NotificationConfig to WorkflowOrchestrator:
    NotificationConfig(
        recipients = ["team@example.com", "oncall@example.com"],
        sender     = "glue-notifications@example.com",
        ses_region = "us-east-1",    # must match your SES verified identity
        enabled    = True,
    )

Or build from Glue job params — see glue_job_main.py.
"""
from __future__ import annotations

import html
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

import boto3

from utils.logger import get_logger

logger = get_logger("email_notifier")


# ──────────────────────────────────────────────────────────────────────────────
# Data model — populated during workflow execution
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class TaskReport:
    """Result of one task execution."""
    task_name:        str
    service_name:     str
    status:           str           # SUCCESS | FAILED | SKIPPED
    started_at:       Optional[datetime]
    completed_at:     Optional[datetime]
    records_written:  Optional[int]
    query_row_count:  Optional[int]
    api_success_count: Optional[int]
    api_failure_count: Optional[int]
    error_message:    Optional[str]

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None


@dataclass
class GroupReport:
    """Result of one group execution, containing all its task results."""
    group_id:     str
    depends_on:   list[str]
    status:       str           # SUCCESS | FAILED | SKIPPED
    started_at:   Optional[datetime]
    completed_at: Optional[datetime]
    tasks:        list[TaskReport] = field(default_factory=list)

    @property
    def total_records(self) -> int:
        return sum(t.records_written or 0 for t in self.tasks)

    @property
    def failed_task_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == "FAILED")

    @property
    def success_task_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == "SUCCESS")

    @property
    def skipped_task_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == "SKIPPED")

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None


@dataclass
class WorkflowReport:
    """Complete execution report for one workflow run."""
    workflow_name:      str
    execution_id:       str
    run_id:             str
    status:             str           # SUCCESS | FAILED
    is_retry:           bool
    retry_of_id:        Optional[str]
    started_at:         Optional[datetime]
    completed_at:       Optional[datetime]
    groups:             list[GroupReport] = field(default_factory=list)

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    @property
    def total_records(self) -> int:
        return sum(g.total_records for g in self.groups)

    @property
    def total_tasks(self) -> int:
        return sum(len(g.tasks) for g in self.groups)

    @property
    def failed_tasks(self) -> int:
        return sum(g.failed_task_count for g in self.groups)

    @property
    def success_tasks(self) -> int:
        return sum(g.success_task_count for g in self.groups)

    @property
    def skipped_tasks(self) -> int:
        return sum(g.skipped_task_count for g in self.groups)

    @property
    def failed_groups(self) -> int:
        return sum(1 for g in self.groups if g.status == "FAILED")

    @property
    def success_groups(self) -> int:
        return sum(1 for g in self.groups if g.status == "SUCCESS")

    @property
    def skipped_groups(self) -> int:
        return sum(1 for g in self.groups if g.status == "SKIPPED")


# ──────────────────────────────────────────────────────────────────────────────
# Notification configuration
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class NotificationConfig:
    """
    Email notification settings.

    recipients : list of To: addresses
    sender     : From: address — must be SES-verified
    ses_region : AWS region where SES is configured (e.g. "us-east-1")
    enabled    : set False to skip sending without removing the config
    send_on_success : send email even when workflow succeeds (default True)
    send_on_failure : send email when workflow fails (default True)
    """
    recipients:       list[str]
    sender:           str
    ses_region:       str  = "us-east-1"
    enabled:          bool = True
    send_on_success:  bool = True
    send_on_failure:  bool = True

    @classmethod
    def from_args(cls, args: dict) -> Optional["NotificationConfig"]:
        """
        Build from Glue job args dict.
        Returns None if notification_recipients is absent or empty.

        Expected keys:
            notification_recipients  comma-separated email addresses
            notification_sender      From: address
            ses_region               AWS SES region (default us-east-1)
        """
        raw = args.get("notification_recipients", "").strip()
        if not raw:
            return None
        recipients = [r.strip() for r in raw.split(",") if r.strip()]
        if not recipients:
            return None
        sender = args.get("notification_sender", "").strip()
        if not sender:
            logger.warning(
                "notification_recipients set but notification_sender is empty "
                "— email notifications disabled"
            )
            return None
        return cls(
            recipients  = recipients,
            sender      = sender,
            ses_region  = args.get("ses_region", "us-east-1"),
        )


# ──────────────────────────────────────────────────────────────────────────────
# Notifier
# ──────────────────────────────────────────────────────────────────────────────

class WorkflowEmailNotifier:
    """
    Sends an HTML workflow execution report email via AWS SES.

    Usage:
        notifier = WorkflowEmailNotifier(config)
        notifier.send(report)
    """

    def __init__(self, config: NotificationConfig):
        self._cfg = config
        self._ses = boto3.client("ses", region_name=config.ses_region)

    def send(self, report: WorkflowReport):
        """Build and send the HTML email for the given WorkflowReport."""
        cfg = self._cfg
        if not cfg.enabled:
            logger.info("Email notifications disabled — skipping")
            return

        if report.status == "SUCCESS" and not cfg.send_on_success:
            logger.info("send_on_success=False — skipping success notification")
            return
        if report.status == "FAILED" and not cfg.send_on_failure:
            logger.info("send_on_failure=False — skipping failure notification")
            return

        subject  = self._build_subject(report)
        html_body = self._build_html(report)
        text_body = self._build_text(report)

        logger.info(
            f"Sending execution report email to {cfg.recipients} "
            f"for workflow '{report.workflow_name}' "
            f"[{report.status}]"
        )

        try:
            self._ses.send_email(
                Source=cfg.sender,
                Destination={"ToAddresses": cfg.recipients},
                Message={
                    "Subject": {"Data": subject, "Charset": "UTF-8"},
                    "Body": {
                        "Text": {"Data": text_body, "Charset": "UTF-8"},
                        "Html": {"Data": html_body, "Charset": "UTF-8"},
                    },
                },
            )
            logger.info("Execution report email sent successfully")
        except Exception as exc:
            # Never let a notification failure crash the job
            logger.error(f"Failed to send notification email: {exc}")

    # ------------------------------------------------------------------
    # Subject line
    # ------------------------------------------------------------------

    def _build_subject(self, r: WorkflowReport) -> str:
        icon   = "✅" if r.status == "SUCCESS" else "❌"
        retry  = " [RETRY]" if r.is_retry else ""
        return (
            f"{icon} Workflow {r.status}{retry} | "
            f"{r.workflow_name} | "
            f"{_fmt_dt(r.started_at)}"
        )

    # ------------------------------------------------------------------
    # Plain-text fallback
    # ------------------------------------------------------------------

    def _build_text(self, r: WorkflowReport) -> str:
        lines = [
            f"WORKFLOW EXECUTION REPORT",
            f"{'=' * 60}",
            f"Workflow      : {r.workflow_name}",
            f"Execution ID  : {r.execution_id}",
            f"Run ID        : {r.run_id}",
            f"Status        : {r.status}",
            f"Started       : {_fmt_dt(r.started_at)}",
            f"Completed     : {_fmt_dt(r.completed_at)}",
            f"Duration      : {_fmt_duration(r.duration_seconds)}",
            f"Is Retry      : {'Yes (of ' + r.retry_of_id + ')' if r.is_retry else 'No'}",
            f"",
            f"SUMMARY",
            f"{'=' * 60}",
            f"Groups   — Total: {len(r.groups)}  "
            f"Success: {r.success_groups}  "
            f"Failed: {r.failed_groups}  "
            f"Skipped: {r.skipped_groups}",
            f"Tasks    — Total: {r.total_tasks}  "
            f"Success: {r.success_tasks}  "
            f"Failed: {r.failed_tasks}  "
            f"Skipped: {r.skipped_tasks}",
            f"Total Records Ingested: {r.total_records:,}",
            f"",
            f"GROUP & TASK DETAIL",
            f"{'=' * 60}",
        ]
        for g in r.groups:
            lines.append(
                f"\n[{g.status}] Group: {g.group_id}  "
                f"Duration: {_fmt_duration(g.duration_seconds)}  "
                f"Records: {g.total_records:,}"
            )
            for t in g.tasks:
                if t.status == "SUCCESS":
                    detail = f"{(t.records_written or 0):,} records ingested"
                    if t.query_row_count:
                        detail += f"  |  {t.query_row_count} query rows"
                    if t.api_failure_count:
                        detail += f"  |  {t.api_failure_count} API failures"
                elif t.status == "FAILED":
                    detail = f"ERROR: {(t.error_message or 'unknown error')[:200]}"
                else:
                    detail = t.error_message or "skipped"

                lines.append(
                    f"  [{t.status:7s}] {t.task_name:40s}  {detail}"
                )
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # HTML email body
    # ------------------------------------------------------------------

    def _build_html(self, r: WorkflowReport) -> str:
        wf_color  = "#2e7d32" if r.status == "SUCCESS" else "#c62828"
        wf_icon   = "✅" if r.status == "SUCCESS" else "❌"
        retry_txt = (
            f'Yes <span style="color:#666;font-size:12px;">'
            f'(of {html.escape(r.retry_of_id or "")})</span>'
            if r.is_retry else "No"
        )

        # ── header card ───────────────────────────────────────────────
        header = f"""
        <table width="100%" cellpadding="0" cellspacing="0"
               style="background:{wf_color};border-radius:6px 6px 0 0;">
          <tr>
            <td style="padding:20px 28px;">
              <span style="font-size:22px;font-weight:700;color:#fff;">
                {wf_icon}&nbsp; Workflow Execution Report
              </span>
            </td>
          </tr>
        </table>"""

        # ── workflow info card ─────────────────────────────────────────
        info_rows = [
            ("Workflow",       html.escape(r.workflow_name)),
            ("Execution ID",   f'<code style="font-size:12px;">{html.escape(r.execution_id)}</code>'),
            ("Run ID",         f'<code style="font-size:12px;">{html.escape(r.run_id)}</code>'),
            ("Status",         f'<strong style="color:{wf_color};">{r.status}</strong>'),
            ("Started",        html.escape(_fmt_dt(r.started_at))),
            ("Completed",      html.escape(_fmt_dt(r.completed_at))),
            ("Duration",       html.escape(_fmt_duration(r.duration_seconds))),
            ("Is Retry",       retry_txt),
        ]
        info_html = _kv_table(info_rows)

        # ── summary card ───────────────────────────────────────────────
        g_total   = len(r.groups)
        summary_rows = [
            ("Groups",
             _badge(str(g_total), "#1565c0") + "&nbsp;" +
             _badge(f"✅ {r.success_groups}", "#2e7d32") + "&nbsp;" +
             _badge(f"❌ {r.failed_groups}", "#c62828") + "&nbsp;" +
             _badge(f"⏭ {r.skipped_groups}", "#757575")),
            ("Tasks",
             _badge(str(r.total_tasks), "#1565c0") + "&nbsp;" +
             _badge(f"✅ {r.success_tasks}", "#2e7d32") + "&nbsp;" +
             _badge(f"❌ {r.failed_tasks}", "#c62828") + "&nbsp;" +
             _badge(f"⏭ {r.skipped_tasks}", "#757575")),
            ("Total Records Ingested",
             f'<strong style="font-size:16px;">{r.total_records:,}</strong>'),
        ]
        summary_html = _kv_table(summary_rows)

        # ── group + task detail table ──────────────────────────────────
        detail_rows_html = ""
        for g in r.groups:
            g_color      = _status_color(g.status)
            g_icon       = _status_icon(g.status)
            g_duration   = html.escape(_fmt_duration(g.duration_seconds))
            g_records    = f"{g.total_records:,}"
            g_dep        = html.escape(", ".join(g.depends_on) if g.depends_on else "—")

            # Group header row (spans all columns, shaded)
            detail_rows_html += f"""
            <tr style="background:#f5f5f5;">
              <td colspan="6"
                  style="padding:10px 14px;font-weight:700;
                         border-left:4px solid {g_color};font-size:13px;">
                {g_icon}&nbsp;
                <span style="color:{g_color};">Group: {html.escape(g.group_id)}</span>
                &nbsp;
                <span style="color:#555;font-weight:400;font-size:12px;">
                  Depends on: {g_dep} &nbsp;|&nbsp;
                  Duration: {g_duration} &nbsp;|&nbsp;
                  Records: {g_records}
                </span>
              </td>
            </tr>"""

            # Task rows
            for t in g.tasks:
                t_color = _status_color(t.status)
                t_icon  = _status_icon(t.status)
                t_dur   = html.escape(_fmt_duration(t.duration_seconds))

                # Detail column: records written (success) or error (failed/skipped)
                if t.status == "SUCCESS":
                    rec_str  = f"{(t.records_written or 0):,}"
                    api_info = ""
                    if t.query_row_count:
                        api_info += f"<br><small>Query rows: {t.query_row_count:,}</small>"
                    if t.api_failure_count:
                        api_info += (
                            f'<br><small style="color:#e65100;">'
                            f'API failures: {t.api_failure_count}</small>'
                        )
                    detail_cell = (
                        f'<strong style="color:#2e7d32;">{rec_str}</strong>'
                        f'<small> records ingested</small>{api_info}'
                    )
                elif t.status == "FAILED":
                    err = html.escape((t.error_message or "unknown error")[:300])
                    detail_cell = (
                        f'<span style="color:#c62828;font-size:12px;">'
                        f'<strong>ERROR:</strong> {err}</span>'
                    )
                else:  # SKIPPED
                    reason = html.escape((t.error_message or "skipped")[:200])
                    detail_cell = (
                        f'<span style="color:#757575;font-size:12px;">{reason}</span>'
                    )

                detail_rows_html += f"""
                <tr style="border-bottom:1px solid #e0e0e0;">
                  <td style="padding:8px 14px 8px 28px;font-size:12px;color:#555;">
                    {html.escape(t.task_name)}
                  </td>
                  <td style="padding:8px 10px;font-size:12px;color:#777;">
                    {html.escape(t.service_name or '—')}
                  </td>
                  <td style="padding:8px 10px;text-align:center;">
                    <span style="font-size:16px;">{t_icon}</span>
                    <br>
                    <small style="color:{t_color};font-weight:600;">{t.status}</small>
                  </td>
                  <td style="padding:8px 10px;font-size:12px;color:#555;
                             text-align:right;">
                    {t_dur}
                  </td>
                  <td style="padding:8px 14px;font-size:13px;">
                    {detail_cell}
                  </td>
                </tr>"""

        detail_table = f"""
        <table width="100%" cellpadding="0" cellspacing="0"
               style="border-collapse:collapse;border:1px solid #e0e0e0;
                      border-radius:4px;overflow:hidden;">
          <thead>
            <tr style="background:#1565c0;color:#fff;">
              <th style="padding:10px 14px;text-align:left;font-size:12px;">
                Task Name
              </th>
              <th style="padding:10px 10px;text-align:left;font-size:12px;">
                Service
              </th>
              <th style="padding:10px 10px;text-align:center;font-size:12px;">
                Status
              </th>
              <th style="padding:10px 10px;text-align:right;font-size:12px;">
                Duration
              </th>
              <th style="padding:10px 14px;text-align:left;font-size:12px;">
                Records Ingested / Error
              </th>
            </tr>
          </thead>
          <tbody>
            {detail_rows_html}
          </tbody>
        </table>"""

        # ── assemble full email ────────────────────────────────────────
        body = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body style="margin:0;padding:0;background:#f0f2f5;font-family:
             'Segoe UI',Arial,sans-serif;color:#212121;">

  <table width="100%" cellpadding="0" cellspacing="0"
         style="padding:32px 0;">
    <tr>
      <td align="center">
        <table width="780" cellpadding="0" cellspacing="0"
               style="background:#fff;border-radius:6px;
                      box-shadow:0 2px 8px rgba(0,0,0,.12);">

          <!-- header -->
          <tr><td>{header}</td></tr>

          <!-- workflow info -->
          <tr>
            <td style="padding:24px 28px 0;">
              <p style="margin:0 0 8px;font-size:13px;font-weight:700;
                        color:#1565c0;text-transform:uppercase;
                        letter-spacing:.5px;">
                Workflow Information
              </p>
              {info_html}
            </td>
          </tr>

          <!-- summary -->
          <tr>
            <td style="padding:20px 28px 0;">
              <p style="margin:0 0 8px;font-size:13px;font-weight:700;
                        color:#1565c0;text-transform:uppercase;
                        letter-spacing:.5px;">
                Execution Summary
              </p>
              {summary_html}
            </td>
          </tr>

          <!-- detail table -->
          <tr>
            <td style="padding:20px 28px 28px;">
              <p style="margin:0 0 10px;font-size:13px;font-weight:700;
                        color:#1565c0;text-transform:uppercase;
                        letter-spacing:.5px;">
                Group &amp; Task Detail
              </p>
              {detail_table}
            </td>
          </tr>

          <!-- footer -->
          <tr>
            <td style="padding:16px 28px;background:#f5f5f5;
                       border-radius:0 0 6px 6px;border-top:1px solid #e0e0e0;">
              <p style="margin:0;font-size:11px;color:#9e9e9e;text-align:center;">
                Generated by AWS Glue Workflow Orchestration Framework
                &nbsp;·&nbsp;
                {html.escape(_fmt_dt(datetime.now(timezone.utc)))} UTC
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>

</body>
</html>"""
        return body


# ──────────────────────────────────────────────────────────────────────────────
# HTML helpers
# ──────────────────────────────────────────────────────────────────────────────

def _kv_table(rows: list[tuple[str, str]]) -> str:
    """Render a two-column key-value info table."""
    inner = ""
    for label, value in rows:
        inner += f"""
        <tr>
          <td style="padding:6px 14px 6px 0;font-size:13px;color:#555;
                     white-space:nowrap;vertical-align:top;width:160px;">
            {html.escape(label)}
          </td>
          <td style="padding:6px 0;font-size:13px;color:#212121;">
            {value}
          </td>
        </tr>"""
    return (
        f'<table cellpadding="0" cellspacing="0" '
        f'style="border-collapse:collapse;width:100%;">'
        f'{inner}</table>'
    )


def _badge(text: str, color: str) -> str:
    return (
        f'<span style="display:inline-block;padding:3px 9px;'
        f'background:{color};color:#fff;border-radius:12px;'
        f'font-size:12px;font-weight:600;">{text}</span>'
    )


def _status_color(status: str) -> str:
    return {"SUCCESS": "#2e7d32", "FAILED": "#c62828", "SKIPPED": "#757575"}.get(
        status, "#1565c0"
    )


def _status_icon(status: str) -> str:
    return {"SUCCESS": "✅", "FAILED": "❌", "SKIPPED": "⏭"}.get(status, "🔵")


# ──────────────────────────────────────────────────────────────────────────────
# Formatting helpers
# ──────────────────────────────────────────────────────────────────────────────

def _fmt_dt(dt: Optional[datetime]) -> str:
    if dt is None:
        return "—"
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.strftime("%Y-%m-%d %H:%M:%S UTC")


def _fmt_duration(seconds: Optional[float]) -> str:
    if seconds is None:
        return "—"
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h {m:02d}m {s:02d}s"
