"""
db/rds_tracker.py
─────────────────────────────────────────────────────────────────────────────
PostgreSQL-backed workflow orchestration state tracker.

Table names
─────────────────────────────────────────────────────────────────────────────
  workflow_info   — one row per workflow run
  group_info      — one row per group per run
  task_info       — one row per task per run

Primary key strategy
─────────────────────────────────────────────────────────────────────────────
  workflow_info.workflow_execution_id
      = Glue JOB_RUN_ID (e.g. "jr_1234abcd…")
      Glue guarantees this is unique per job invocation, so we use it
      directly as the PK.  No UUID generation needed for workflows.

  group_info.group_execution_id
  task_info.task_execution_id
      = uuid4()  (multiple groups/tasks share the same workflow run)

Connection bootstrap
─────────────────────────────────────────────────────────────────────────────
    tracker = RDSTracker.from_glue_connection(glue_context, "conn-name")

GlueContext.extract_jdbc_conf returns:
    { "url": "jdbc:postgresql://host:port/db", "user": "…", "password": "…" }

Status values: STARTED → SUCCESS | FAILED | SKIPPED
"""
import json
import re
import uuid
from datetime import datetime
from typing import Optional

import psycopg2
import psycopg2.extras

from utils.logger import get_logger

logger = get_logger("rds_tracker")

STATUS_STARTED = "STARTED"
STATUS_SUCCESS = "SUCCESS"
STATUS_FAILED  = "FAILED"
STATUS_SKIPPED = "SKIPPED"

# Table names — single source of truth
_TBL_WORKFLOW = "workflow_info"
_TBL_GROUP    = "group_info"
_TBL_TASK     = "task_info"

# Regex to parse jdbc:postgresql://host[:port]/database
_JDBC_RE = re.compile(
    r"jdbc:postgresql://([^:/]+)(?::(\d+))?/([^?]+)",
    re.IGNORECASE,
)


class RDSTracker:
    """PostgreSQL orchestration state tracker using Glue JDBC connection."""

    def __init__(self, host: str, port: int, database: str,
                 user: str, password: str):
        self._conn_params = dict(
            host=host,
            port=port,
            dbname=database,
            user=user,
            password=password,
            connect_timeout=10,
            cursor_factory=psycopg2.extras.RealDictCursor,
        )
        self._conn: Optional[psycopg2.extensions.connection] = None

    # ------------------------------------------------------------------
    # Factory: build from Glue connection name
    # ------------------------------------------------------------------

    @classmethod
    def from_glue_connection(cls, glue_context, connection_name: str) -> "RDSTracker":
        """
        Extract JDBC config from a named Glue connection and return an
        initialised RDSTracker.

        The Glue connection must be of type JDBC pointing at PostgreSQL.
        GlueContext.extract_jdbc_conf returns:
            { "url": "jdbc:postgresql://host:5432/mydb",
              "user": "glue_user", "password": "…" }
        """
        logger.info(
            f"Extracting JDBC config for Glue connection: '{connection_name}'"
        )
        jdbc_conf = glue_context.extract_jdbc_conf(connection_name)

        jdbc_url = jdbc_conf.get("url", "")
        user     = jdbc_conf.get("user", "")
        password = jdbc_conf.get("password", "")

        match = _JDBC_RE.match(jdbc_url)
        if not match:
            raise ValueError(
                f"Cannot parse JDBC URL '{jdbc_url}' from connection "
                f"'{connection_name}'. Expected: "
                f"jdbc:postgresql://host[:port]/database"
            )

        host     = match.group(1)
        port     = int(match.group(2) or 5432)
        database = match.group(3)

        logger.info(
            f"Connecting → host={host} port={port} database={database} user={user}"
        )
        return cls(host=host, port=port, database=database,
                   user=user, password=password)

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    def _get_conn(self) -> psycopg2.extensions.connection:
        """Return a live connection, reconnecting if the socket dropped."""
        try:
            if self._conn and not self._conn.closed:
                self._conn.isolation_level    # cheap liveness check
                return self._conn
        except Exception:
            pass
        logger.debug("Opening new PostgreSQL connection …")
        self._conn = psycopg2.connect(**self._conn_params)
        self._conn.autocommit = True
        return self._conn

    def _exec(self, sql: str, params: tuple = ()):
        with self._get_conn().cursor() as cur:
            cur.execute(sql, params)

    def _fetch_one(self, sql: str, params: tuple = ()) -> Optional[dict]:
        with self._get_conn().cursor() as cur:
            cur.execute(sql, params)
            row = cur.fetchone()
            return dict(row) if row else None

    def _fetch_all(self, sql: str, params: tuple = ()) -> list[dict]:
        with self._get_conn().cursor() as cur:
            cur.execute(sql, params)
            return [dict(r) for r in cur.fetchall()]

    def close(self):
        """Release the PostgreSQL connection."""
        try:
            if self._conn and not self._conn.closed:
                self._conn.close()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # workflow_info
    # ------------------------------------------------------------------

    def start_workflow(self, workflow_name: str, run_id: str,
                       input_params: dict = None,
                       is_retry: bool = False,
                       retry_of: str = None) -> str:
        """
        Insert a STARTED row into workflow_info.

        workflow_execution_id = run_id (the Glue JOB_RUN_ID).
        Glue guarantees uniqueness per invocation, so no uuid4() is needed.

        Returns run_id so the caller can use it as the FK in group/task rows.
        """
        self._exec(
            f"""INSERT INTO {_TBL_WORKFLOW}
               (workflow_execution_id, workflow_name, run_id, is_retry,
                retry_of_execution_id, input_params, status, started_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
            (run_id, workflow_name, run_id, is_retry,
             retry_of, json.dumps(input_params or {}),
             STATUS_STARTED, datetime.utcnow())
        )
        logger.info(
            f"workflow_info STARTED | execution_id={run_id} "
            f"name={workflow_name} retry={is_retry}"
        )
        return run_id   # <── PK = Glue run_id

    def complete_workflow(self, wf_exec_id: str, success: bool,
                          error: str = None):
        status = STATUS_SUCCESS if success else STATUS_FAILED
        self._exec(
            f"""UPDATE {_TBL_WORKFLOW}
               SET status=%s, completed_at=%s, error_message=%s, updated_at=%s
               WHERE workflow_execution_id=%s""",
            (status, datetime.utcnow(), error, datetime.utcnow(), wf_exec_id)
        )
        logger.info(f"workflow_info {wf_exec_id} → {status}")

    # ------------------------------------------------------------------
    # group_info
    # ------------------------------------------------------------------

    def start_group(self, wf_exec_id: str, workflow_name: str,
                    group_id: str, depends_on: list) -> str:
        """Insert a STARTED row into group_info. Returns a new uuid4 PK."""
        g_id = str(uuid.uuid4())
        self._exec(
            f"""INSERT INTO {_TBL_GROUP}
               (group_execution_id, workflow_execution_id, workflow_name,
                group_id, depends_on, status, started_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s)""",
            (g_id, wf_exec_id, workflow_name,
             group_id, json.dumps(depends_on),
             STATUS_STARTED, datetime.utcnow())
        )
        return g_id

    def complete_group(self, group_exec_id: str, success: bool,
                       error: str = None):
        status = STATUS_SUCCESS if success else STATUS_FAILED
        self._exec(
            f"""UPDATE {_TBL_GROUP}
               SET status=%s, completed_at=%s, error_message=%s, updated_at=%s
               WHERE group_execution_id=%s""",
            (status, datetime.utcnow(), error, datetime.utcnow(), group_exec_id)
        )

    def skip_group(self, wf_exec_id: str, workflow_name: str,
                   group_id: str, depends_on: list, reason: str):
        g_id = str(uuid.uuid4())
        self._exec(
            f"""INSERT INTO {_TBL_GROUP}
               (group_execution_id, workflow_execution_id, workflow_name,
                group_id, depends_on, status, error_message,
                started_at, completed_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (g_id, wf_exec_id, workflow_name, group_id,
             json.dumps(depends_on), STATUS_SKIPPED, reason,
             datetime.utcnow(), datetime.utcnow())
        )

    # ------------------------------------------------------------------
    # task_info
    # ------------------------------------------------------------------

    def start_task(self, group_exec_id: str, wf_exec_id: str,
                   workflow_name: str, group_id: str,
                   task_name: str, service_name: str,
                   query_enabled: bool) -> str:
        """Insert a STARTED row into task_info. Returns a new uuid4 PK."""
        t_id = str(uuid.uuid4())
        self._exec(
            f"""INSERT INTO {_TBL_TASK}
               (task_execution_id, group_execution_id, workflow_execution_id,
                workflow_name, group_id, task_name, service_name,
                query_enabled, status, started_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (t_id, group_exec_id, wf_exec_id,
             workflow_name, group_id, task_name, service_name,
             query_enabled, STATUS_STARTED, datetime.utcnow())
        )
        return t_id

    def complete_task(self, task_exec_id: str, success: bool,
                      query_row_count: int = None,
                      api_batch_count: int = None,
                      api_success_count: int = None,
                      api_failure_count: int = None,
                      records_written: int = None,
                      error: str = None,
                      stack: str = None):
        status = STATUS_SUCCESS if success else STATUS_FAILED
        self._exec(
            f"""UPDATE {_TBL_TASK}
               SET status=%s, completed_at=%s,
                   query_row_count=%s, api_batch_count=%s,
                   api_success_count=%s, api_failure_count=%s,
                   records_written=%s,
                   error_message=%s, stack_trace=%s, updated_at=%s
               WHERE task_execution_id=%s""",
            (status, datetime.utcnow(),
             query_row_count, api_batch_count,
             api_success_count, api_failure_count,
             records_written, error, stack,
             datetime.utcnow(), task_exec_id)
        )

    def skip_task(self, group_exec_id: str, wf_exec_id: str,
                  workflow_name: str, group_id: str,
                  task_name: str, reason: str):
        t_id = str(uuid.uuid4())
        self._exec(
            f"""INSERT INTO {_TBL_TASK}
               (task_execution_id, group_execution_id, workflow_execution_id,
                workflow_name, group_id, task_name, service_name,
                query_enabled, status, error_message, started_at, completed_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (t_id, group_exec_id, wf_exec_id,
             workflow_name, group_id, task_name, None,
             False, STATUS_SKIPPED, reason,
             datetime.utcnow(), datetime.utcnow())
        )

    # ------------------------------------------------------------------
    # Retry helpers
    # ------------------------------------------------------------------

    def get_latest_failed_execution_id(self, workflow_name: str) -> Optional[str]:
        """Return workflow_execution_id (= Glue run_id) of the latest FAILED run."""
        row = self._fetch_one(
            f"""SELECT workflow_execution_id
               FROM   {_TBL_WORKFLOW}
               WHERE  workflow_name = %s
                 AND  status = %s
               ORDER  BY started_at DESC
               LIMIT  1""",
            (workflow_name, STATUS_FAILED)
        )
        return row["workflow_execution_id"] if row else None

    def get_groups_to_retry(self, wf_exec_id: str) -> list[dict]:
        """All FAILED + SKIPPED groups from a given execution."""
        return self._fetch_all(
            f"""SELECT group_id, depends_on, status
               FROM   {_TBL_GROUP}
               WHERE  workflow_execution_id = %s
                 AND  status IN (%s, %s)""",
            (wf_exec_id, STATUS_FAILED, STATUS_SKIPPED)
        )

    def get_tasks_to_retry(self, wf_exec_id: str) -> list[dict]:
        """All FAILED + SKIPPED tasks from a given execution."""
        return self._fetch_all(
            f"""SELECT group_id, task_name, status
               FROM   {_TBL_TASK}
               WHERE  workflow_execution_id = %s
                 AND  status IN (%s, %s)""",
            (wf_exec_id, STATUS_FAILED, STATUS_SKIPPED)
        )

    def get_successful_tasks(self, wf_exec_id: str) -> list[dict]:
        """All SUCCESS tasks from a given execution (skipped on retry)."""
        return self._fetch_all(
            f"""SELECT group_id, task_name
               FROM   {_TBL_TASK}
               WHERE  workflow_execution_id = %s
                 AND  status = %s""",
            (wf_exec_id, STATUS_SUCCESS)
        )

    # ------------------------------------------------------------------
    # Execution report — used by email notifier
    # ------------------------------------------------------------------

    def get_execution_report(self, wf_exec_id: str) -> dict:
        """
        Fetch the complete execution picture for one workflow run.
        Returns: { workflow: dict, groups: [dict], tasks: [dict] }
        """
        workflow = self._fetch_one(
            f"""SELECT workflow_execution_id, workflow_name, run_id,
                      is_retry, retry_of_execution_id,
                      status, started_at, completed_at, error_message
               FROM   {_TBL_WORKFLOW}
               WHERE  workflow_execution_id = %s""",
            (wf_exec_id,)
        )
        groups = self._fetch_all(
            f"""SELECT group_id, depends_on, status,
                      started_at, completed_at, error_message
               FROM   {_TBL_GROUP}
               WHERE  workflow_execution_id = %s
               ORDER  BY COALESCE(started_at, NOW()) ASC""",
            (wf_exec_id,)
        )
        tasks = self._fetch_all(
            f"""SELECT group_id, task_name, service_name, status,
                      started_at, completed_at,
                      records_written, query_row_count,
                      api_success_count, api_failure_count,
                      error_message
               FROM   {_TBL_TASK}
               WHERE  workflow_execution_id = %s
               ORDER  BY group_id ASC,
                         COALESCE(started_at, NOW()) ASC""",
            (wf_exec_id,)
        )
        return {
            "workflow": dict(workflow) if workflow else {},
            "groups":   [dict(g) for g in groups],
            "tasks":    [dict(t) for t in tasks],
        }
