"""
glue_job_main.py
─────────────────────────────────────────────────────────────────────────────
AWS Glue Job Entry Point — Workflow Orchestration Framework
─────────────────────────────────────────────────────────────────────────────

Job Parameters  (passed via Glue job --parameters or AWS Console):

  Required:
    --workflow_name          Name of the workflow to execute
    --glue_connection_name   Name of the Glue JDBC connection to PostgreSQL
                             (used by RDSTracker.from_glue_connection)

  Conditionally required:
    --auth_config_s3_path    S3 URI to the auth YAML file
                             (required when workflow has Auth_enabled=true)
                             e.g. s3://my-config-bucket/auth/auth.yaml

  Required:
    --workflow_name              Name of the workflow to execute
    --glue_connection_name       Glue JDBC connection name → PostgreSQL
    --config_s3_bucket           S3 bucket holding all config YAML files

  Optional (config file locations):
    --config_s3_prefix           Key prefix within config_s3_bucket
                                 (e.g. "glue/config")
                                 Constructs:
                                   {bucket}/{prefix}/{workflow}_task_config.yaml
                                   {bucket}/{prefix}/{workflow}_workflow_config.yaml
    --auth_config_s3_path        Full S3 URI to auth.yaml
                                 (required when workflow has Auth_enabled=true)
    --task_config_s3_path        Full S3 URI override for task config
    --workflow_config_s3_path    Full S3 URI override for workflow config

  Optional (execution):
    --input_date                 Business date for tasks (default: today)
    --retry                      "true" to retry last failed run
    --JOB_RUN_ID                 Injected automatically by Glue

  Optional (SMTP notifications):
    --notification_recipients    Comma-separated To: addresses (omit to disable)
    --notification_sender        From: address
    --smtp_host                  SMTP server hostname or IP
    --smtp_port                  SMTP port (default: 587)
    --smtp_user                  SMTP username (omit for anonymous relay)
    --smtp_password_param        SSM SecureString path for SMTP password
    --smtp_use_tls               true/false — STARTTLS (default: true)
"""
import sys
from datetime import date

from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession

from utils.logger import get_logger
from utils.config_loader import ConfigLoader, _parse_s3_uri
from utils.email_notifier import NotificationConfig
from db.rds_tracker import RDSTracker
from core.workflow_orchestrator import WorkflowOrchestrator

logger = get_logger("glue_main")


# ─────────────────────────────────────────────────────────────────────────────
# Argument parsing
# ─────────────────────────────────────────────────────────────────────────────

REQUIRED_ARGS = [
    "workflow_name",
    "glue_connection_name",   # Glue JDBC connection → PostgreSQL
    "config_s3_bucket",       # S3 bucket holding all config YAMLs
]

OPTIONAL_DEFAULTS = {
    "input_date":                str(date.today()),
    "retry":                     "false",
    # ── Config file locations ──────────────────────────────────────────
    "config_s3_prefix":          "",   # key prefix inside config_s3_bucket
    "auth_config_s3_path":       "",   # full s3:// URI to auth.yaml
    "task_config_s3_path":       "",   # full URI override (skips naming convention)
    "workflow_config_s3_path":   "",   # full URI override (skips naming convention)
    # ── SMTP notifications ────────────────────────────────────────────
    "notification_recipients":   "",   # comma-separated To: addresses
    "notification_sender":       "",   # From: address
    "smtp_host":                 "",   # SMTP server hostname
    "smtp_port":                 "587",
    "smtp_user":                 "",   # blank = anonymous relay
    "smtp_password_param":       "",   # SSM path to SMTP password
    "smtp_use_tls":              "true",
    "JOB_RUN_ID":                "local_run",
}


def parse_args() -> dict:
    passed_keys   = [a.lstrip("-") for a in sys.argv if a.startswith("--")]
    keys_to_fetch = list(set(REQUIRED_ARGS) | (set(passed_keys) - {""}))
    try:
        args = getResolvedOptions(sys.argv, keys_to_fetch)
    except Exception:
        # Fallback for local unit testing outside Glue
        args = {k: OPTIONAL_DEFAULTS.get(k, "") for k in REQUIRED_ARGS}

    for k, v in OPTIONAL_DEFAULTS.items():
        args.setdefault(k, v)

    return args


# ─────────────────────────────────────────────────────────────────────────────
# Glue / Spark context
# ─────────────────────────────────────────────────────────────────────────────

def build_glue_context() -> tuple[GlueContext, SparkSession]:
    sc           = SparkContext.getOrCreate()
    glue_context = GlueContext(sc)
    spark        = glue_context.spark_session

    # Iceberg catalog configuration
    spark.conf.set(
        "spark.sql.extensions",
        "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
    )
    spark.conf.set("spark.sql.catalog.glue_emp_catalog",
                   "org.apache.iceberg.spark.SparkCatalog")
    spark.conf.set("spark.sql.catalog.glue_emp_catalog.catalog-impl",
                   "org.apache.iceberg.aws.glue.GlueCatalog")
    spark.conf.set("spark.sql.catalog.glue_emp_catalog.warehouse",
                   "s3://your-iceberg-warehouse-bucket/warehouse/")
    spark.conf.set("spark.sql.catalog.glue_emp_catalog.io-impl",
                   "org.apache.iceberg.aws.s3.S3FileIO")

    return glue_context, spark


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    args             = parse_args()
    workflow_name    = args["workflow_name"]
    connection_name  = args["glue_connection_name"]
    retry_mode       = args.get("retry", "false").lower() == "true"
    run_id           = args.get("JOB_RUN_ID", "local_run")

    logger.info("=" * 60)
    logger.info("Glue Workflow Job Starting")
    logger.info(f"  workflow_name       : {workflow_name}")
    logger.info(f"  glue_connection     : {connection_name}")
    logger.info(f"  auth_config_s3_path : {auth_s3_path or '(none)'}")
    logger.info(f"  retry_mode          : {retry_mode}")
    logger.info(f"  run_id              : {run_id}")
    logger.info("=" * 60)

    # ── Build Glue / Spark context ────────────────────────────────────
    glue_context, spark = build_glue_context()

    # ── Load workflow & task configs directly from S3 ───────────────
    # Paths are derived from job params — no SSM lookup required.
    # Naming convention: {bucket}/{prefix}/{workflow_name}_task_config.yaml
    #                    {bucket}/{prefix}/{workflow_name}_workflow_config.yaml
    # Override with explicit --task_config_s3_path / --workflow_config_s3_path.
    loader              = ConfigLoader.from_args(args)
    task_cfg, workflow_cfg = loader.load_configs(workflow_name)

    # auth_config_s3_path comes from args (via loader) or stays empty
    auth_s3_path = loader.auth_config_s3_path

    # ── Build RDS tracker via Glue JDBC connection ────────────────────
    # GlueContext.extract_jdbc_conf resolves the JDBC URL, user, and
    # password from the named Glue connection automatically.
    tracker = RDSTracker.from_glue_connection(glue_context, connection_name)

    # ── Build runtime params dict ─────────────────────────────────────
    runtime_params: dict = {
        "inputDate":    args.get("input_date", str(date.today())),
        "workflowName": workflow_name,
    }
    # Merge any additional --key=value Glue job params the operator passed
    _skip = {"glue_connection_name", "auth_config_s3_path",
             "retry", "param_store_prefix", "JOB_RUN_ID"}
    for k, v in args.items():
        if k not in _skip:
            runtime_params.setdefault(k, v)

    # ── Build notification config ─────────────────────────────────────
    notification_cfg = NotificationConfig.from_args(args)
    if notification_cfg:
        logger.info(
            f"Email notifications enabled → {notification_cfg.recipients}"
        )
    else:
        logger.info("Email notifications disabled (no recipients configured)")

    # ── Run the workflow ──────────────────────────────────────────────
    try:
        orchestrator = WorkflowOrchestrator(
            spark               = spark,
            tracker             = tracker,
            workflow_cfg        = workflow_cfg,
            task_cfg            = task_cfg,
            runtime_params      = runtime_params,
            run_id              = run_id,
            retry_mode          = retry_mode,
            auth_config_s3_path = auth_s3_path or None,
            notification_config = notification_cfg,
        )
        success = orchestrator.run()
    finally:
        tracker.close()   # ensure PostgreSQL connection is released

    if not success:
        logger.error("Workflow completed with FAILURES — exiting with code 1")
        sys.exit(1)

    logger.info("Glue Workflow Job completed successfully")


if __name__ == "__main__":
    main()
