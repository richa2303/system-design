-- ============================================================
-- AWS Glue Workflow Orchestration — PostgreSQL Schema
-- ============================================================
-- Tables: workflow_info, group_info, task_info
--
-- workflow_info.workflow_execution_id = Glue JOB_RUN_ID
--   Glue guarantees a unique run ID per invocation so no UUID
--   generation is needed for the workflow-level primary key.
--
-- group_info.group_execution_id  = uuid4  (many per workflow run)
-- task_info.task_execution_id    = uuid4  (many per group run)
-- ============================================================

-- ──────────────────────────────────────────────────────────
-- workflow_info — one row per Glue job invocation
-- ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS workflow_info (
    workflow_execution_id   VARCHAR(256)    NOT NULL,   -- = Glue JOB_RUN_ID
    workflow_name           VARCHAR(256)    NOT NULL,
    run_id                  VARCHAR(256)    NOT NULL,   -- same as PK for clarity
    is_retry                BOOLEAN         NOT NULL DEFAULT FALSE,
    retry_of_execution_id   VARCHAR(256),               -- FK to previous run
    input_params            JSONB,
    status                  VARCHAR(32)     NOT NULL,   -- STARTED|SUCCESS|FAILED
    started_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    completed_at            TIMESTAMP,
    error_message           TEXT,
    created_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    PRIMARY KEY (workflow_execution_id)
);

CREATE INDEX IF NOT EXISTS idx_wi_name_status
    ON workflow_info (workflow_name, status);
CREATE INDEX IF NOT EXISTS idx_wi_name_started
    ON workflow_info (workflow_name, started_at DESC);


-- ──────────────────────────────────────────────────────────
-- group_info — one row per group per workflow run
-- ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS group_info (
    group_execution_id      VARCHAR(64)     NOT NULL,   -- uuid4
    workflow_execution_id   VARCHAR(256)    NOT NULL,   -- FK → workflow_info
    workflow_name           VARCHAR(256)    NOT NULL,
    group_id                VARCHAR(256)    NOT NULL,
    depends_on              JSONB,
    status                  VARCHAR(32)     NOT NULL,   -- STARTED|SUCCESS|FAILED|SKIPPED
    started_at              TIMESTAMP,
    completed_at            TIMESTAMP,
    error_message           TEXT,
    created_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    PRIMARY KEY (group_execution_id),
    FOREIGN KEY (workflow_execution_id)
        REFERENCES workflow_info (workflow_execution_id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_gi_workflow_exec
    ON group_info (workflow_execution_id);
CREATE INDEX IF NOT EXISTS idx_gi_name_group
    ON group_info (workflow_name, group_id);


-- ──────────────────────────────────────────────────────────
-- task_info — one row per task per workflow run
-- ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS task_info (
    task_execution_id       VARCHAR(64)     NOT NULL,   -- uuid4
    group_execution_id      VARCHAR(64)     NOT NULL,   -- FK → group_info
    workflow_execution_id   VARCHAR(256)    NOT NULL,   -- FK → workflow_info
    workflow_name           VARCHAR(256)    NOT NULL,
    group_id                VARCHAR(256)    NOT NULL,
    task_name               VARCHAR(256)    NOT NULL,
    service_name            VARCHAR(256),
    query_enabled           BOOLEAN         NOT NULL DEFAULT FALSE,
    status                  VARCHAR(32)     NOT NULL,   -- STARTED|SUCCESS|FAILED|SKIPPED
    query_row_count         INTEGER,
    api_batch_count         INTEGER,
    api_success_count       INTEGER,
    api_failure_count       INTEGER,
    records_written         BIGINT,
    started_at              TIMESTAMP,
    completed_at            TIMESTAMP,
    error_message           TEXT,
    stack_trace             TEXT,
    created_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    PRIMARY KEY (task_execution_id),
    FOREIGN KEY (group_execution_id)
        REFERENCES group_info (group_execution_id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_ti_group_exec
    ON task_info (group_execution_id);
CREATE INDEX IF NOT EXISTS idx_ti_workflow_exec
    ON task_info (workflow_execution_id);
CREATE INDEX IF NOT EXISTS idx_ti_task_status
    ON task_info (workflow_name, task_name, status);


-- ============================================================
-- Monitoring views
-- ============================================================

CREATE OR REPLACE VIEW v_workflow_summary AS
SELECT
    wi.workflow_name,
    wi.workflow_execution_id,
    wi.run_id,
    wi.is_retry,
    wi.status                                               AS workflow_status,
    wi.started_at,
    wi.completed_at,
    EXTRACT(EPOCH FROM (wi.completed_at - wi.started_at))   AS duration_seconds,
    COUNT(DISTINCT gi.group_id)                             AS total_groups,
    COUNT(DISTINCT gi.group_id) FILTER (WHERE gi.status = 'SUCCESS')  AS succeeded_groups,
    COUNT(DISTINCT gi.group_id) FILTER (WHERE gi.status = 'FAILED')   AS failed_groups,
    COUNT(DISTINCT gi.group_id) FILTER (WHERE gi.status = 'SKIPPED')  AS skipped_groups,
    COUNT(ti.task_execution_id)                             AS total_tasks,
    COUNT(ti.task_execution_id) FILTER (WHERE ti.status = 'SUCCESS')  AS succeeded_tasks,
    COUNT(ti.task_execution_id) FILTER (WHERE ti.status = 'FAILED')   AS failed_tasks,
    COALESCE(SUM(ti.records_written), 0)                    AS total_records_written
FROM       workflow_info wi
LEFT JOIN  group_info    gi ON gi.workflow_execution_id = wi.workflow_execution_id
LEFT JOIN  task_info     ti ON ti.workflow_execution_id = wi.workflow_execution_id
GROUP BY   wi.workflow_execution_id, wi.workflow_name, wi.run_id,
           wi.is_retry, wi.status, wi.started_at, wi.completed_at;


CREATE OR REPLACE VIEW v_retry_candidates AS
-- Latest FAILED execution per workflow with all failed/skipped group+task detail
SELECT
    wi.workflow_name,
    wi.workflow_execution_id,
    wi.started_at                                           AS failed_at,
    gi.group_id,
    gi.status                                               AS group_status,
    ti.task_name,
    ti.status                                               AS task_status,
    ti.error_message
FROM (
    SELECT DISTINCT ON (workflow_name)
           workflow_execution_id, workflow_name, started_at
    FROM   workflow_info
    WHERE  status = 'FAILED'
    ORDER  BY workflow_name, started_at DESC
)                                   wi
JOIN  group_info                    gi
      ON gi.workflow_execution_id = wi.workflow_execution_id
     AND gi.status IN ('FAILED', 'SKIPPED')
JOIN  task_info                     ti
      ON ti.workflow_execution_id = wi.workflow_execution_id
     AND ti.group_id = gi.group_id
     AND ti.status IN ('FAILED', 'SKIPPED')
ORDER BY wi.workflow_name, gi.group_id, ti.task_name;


-- ============================================================
-- Migration script — run once if upgrading from old schema
-- (old tables: glue_workflow_execution, glue_group_execution,
--              glue_task_execution)
-- ============================================================

-- Step 1: rename existing tables (safe, reversible)
-- ALTER TABLE glue_task_execution     RENAME TO task_info;
-- ALTER TABLE glue_group_execution    RENAME TO group_info;
-- ALTER TABLE glue_workflow_execution RENAME TO workflow_info;

-- Step 2: widen workflow_execution_id columns to VARCHAR(256)
--         (Glue run IDs are longer than uuid4 36-char strings)
-- ALTER TABLE workflow_info ALTER COLUMN workflow_execution_id TYPE VARCHAR(256);
-- ALTER TABLE group_info    ALTER COLUMN workflow_execution_id TYPE VARCHAR(256);
-- ALTER TABLE task_info     ALTER COLUMN workflow_execution_id TYPE VARCHAR(256);

-- Step 3: add run_id column if missing
-- ALTER TABLE workflow_info ADD COLUMN IF NOT EXISTS run_id VARCHAR(256);
-- UPDATE workflow_info SET run_id = workflow_execution_id WHERE run_id IS NULL;

-- Uncomment steps above to run migration. Test in non-production first.
