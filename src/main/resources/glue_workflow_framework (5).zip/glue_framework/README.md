# AWS Glue Workflow Orchestration Framework

A scalable, production-grade AWS Glue job framework supporting multi-group workflows,
API-based ingestion with batched parallel calls, file-based ingestion from S3 zip files,
Aurora RDS state tracking, and automatic retry of failed executions.

---

## Architecture Overview

```
glue_job_main.py                  ← Entry point (Glue job)
│
├── utils/config_loader.py        ← Loads YAML configs from S3 via SSM paths
├── utils/transforms.py           ← Column transforms, nested key extraction
├── utils/logger.py               ← Structured logger
│
├── core/auth_manager.py          ← OAuth token cache + auto-refresh
├── core/workflow_orchestrator.py ← Group dependency resolution, parallel execution
│
├── ingestion/api_ingestion.py    ← API batched calls, query-param resolution, Iceberg write
├── ingestion/file_ingestion.py   ← S3 zip extraction, CSV/Excel/Parquet read, Iceberg write
│
├── db/rds_tracker.py             ← Aurora RDS state writes (workflow/group/task)
│
├── config/sample/
│   ├── daily_data_sync_task_config.yaml
│   ├── daily_data_sync_workflow_config.yaml
│   ├── file_ingestion_sync_task_config.yaml
│   └── file_ingestion_sync_workflow_config.yaml
│
└── sql/schema.sql                ← Aurora RDS DDL
```

---

## Workflow Execution Model

```
Workflow
  └── Groups (resolved in dependency waves)
        └── Tasks (executed sequentially per group; groups run in parallel)
```

### Execution Waves (Example)

```
Wave 1: group1, group2          ← no dependencies
Wave 2: group3 (→group1),
        group4 (→group2),
        group5 (→group2)        ← all deps from wave 1
```

Groups within the same wave run **in parallel threads**.
Groups in later waves wait for all their dependencies to succeed.
If a dependency group **fails**, all dependant groups are **SKIPPED** (not failed).

---

## Config File Naming Convention

| File                                    | SSM Parameter                                      |
|-----------------------------------------|----------------------------------------------------|
| `{workflow_name}_task_config.yaml`      | `/glue/workflows/{workflow_name}_task_config_s3_path`     |
| `{workflow_name}_workflow_config.yaml`  | `/glue/workflows/{workflow_name}_workflow_config_s3_path` |

SSM parameters hold S3 URIs, e.g. `s3://my-config-bucket/configs/daily_data_sync_task_config.yaml`

---

## Glue Job Parameters

| Parameter              | Required | Default         | Description                           |
|------------------------|----------|-----------------|---------------------------------------|
| `--workflow_name`      | ✅        | —               | Workflow to run                       |
| `--input_date`         | ❌        | today           | Business date for API params          |
| `--retry`              | ❌        | `false`         | Set `true` to retry last failed run   |
| `--param_store_prefix` | ❌        | `/glue/workflows` | SSM prefix for config paths         |
| `--rds_host`           | ✅        | —               | Aurora RDS host                       |
| `--rds_port`           | ❌        | `3306`          | Aurora RDS port                       |
| `--rds_database`       | ✅        | —               | Aurora RDS database                   |
| `--rds_user_param`     | ✅        | —               | SSM param for RDS username            |
| `--rds_password_param` | ✅        | —               | SSM param for RDS password (SecureString) |

---

## Task Config Reference

```yaml
taskConfig:
  Data_config.task1:
    Service_name: task_1          # Logical name used in logging/DB
    Auth_ref: type1_auth_token    # References Auth_tokens in workflow config
    Query_enable: true            # Run Select_SQL first to get param rows
    Enable: true                  # false = skip this task

    SourceService: "https://api.example.com/v1/employees"
    ServiceMethod: GET            # GET | POST | PUT
    ServiceHeader:
      Accept: "application/json"
      Authorization: "${type1_auth_token}"   # Substituted at runtime

    queryParams:
      startDate:
        From: "inputDate"         # Key in query result row or runtime_params
        sourceType: "query"       # query | custom
        Transform: "date:%Y-%m-%d"
        Required: true
      Emp_department:
        From: "emp_department"
        sourceType: "custom"
        DefaultValue: "Information_Technology"
        Required: true

    Select_SQL: "SELECT ..."      # Used when Query_enable: true

    Target:
      Catalog: "glue_emp_catalog"
      Database: "emp_db"
      Table: "emp_info"
      Mode: "append"              # append | overwrite

    Columns:
      - name: businessDaysBetween     # Supports dot-notation for nested JSON
        Raw_type: int
        Nullable: true
        Cast: int                     # int | double | float | string | bool
        Alias: business_days_between  # Target column name

      - name: department.name         # Nested: record["department"]["name"]
        Raw_type: string
        Alias: department_name

      - name: firstCurrentBusinessYear
        Raw_type: string
        To_date: true
        Format: "YYYY-MM-DD"
        Alias: first_current_business_year

    Extra_columns:                    # Columns sourced from query params, not API response
      - name: start_date
        Source: query_param
        Param_key: startDate
        Nullable: true
        To_date: true
        Format: "YYYY-MM-DD"
        Alias: start_date
```

---

## API Ingestion Flow

```
1. Pre-load all auth tokens
2. For each group wave (parallel):
   For each group in wave (parallel threads):
     For each task in group (sequential):
       a. If Query_enable=true:  run Select_SQL → N param rows
          Else:                  use single empty param row
       b. Split param rows into batches of batch_size
       c. For each batch: call APIs in ThreadPoolExecutor (max_workers)
          - Auto-refresh token if near expiry (< 2 min buffer)
          - Retry each call up to retry_attempts times
       d. Flatten nested JSON using dot-notation column mappings
       e. Write all records to Iceberg (append/overwrite)
       f. Log stats to Aurora RDS
```

---

## File Ingestion Flow

```
1. Find latest zip in s3://bucket/source_prefix/
2. Extract zip → s3://bucket/staging_prefix/
3. Archive zip → s3://bucket/archive_prefix/
4. For each task:
   a. Match extracted file by File_prefix (case-insensitive)
   b. Read as CSV / Excel / Parquet via Pandas
   c. Apply column transforms (cast, date, alias)
   d. Write to Iceberg
```

---

## Retry Mechanism

When `--retry true` is passed:
1. Query RDS for the **latest FAILED** execution of the workflow
2. Fetch all **FAILED** and **SKIPPED** groups from that execution
3. Fetch all **FAILED** and **SKIPPED** tasks from that execution
4. Re-run only those groups and tasks; mark already-successful ones as skipped
5. Register as a new execution with `is_retry=true` and `retry_of_execution_id`

---

## Aurora RDS Tables

| Table                       | Purpose                                  |
|-----------------------------|------------------------------------------|
| `glue_workflow_execution`   | One row per workflow run                 |
| `glue_group_execution`      | One row per group per workflow run       |
| `glue_task_execution`       | One row per task per workflow run        |

Status values: `STARTED` → `SUCCESS` / `FAILED` / `SKIPPED`

---

## Deployment

### 1. Upload configs to S3
```bash
aws s3 cp config/sample/daily_data_sync_task_config.yaml \
    s3://my-config-bucket/configs/daily_data_sync_task_config.yaml

aws s3 cp config/sample/daily_data_sync_workflow_config.yaml \
    s3://my-config-bucket/configs/daily_data_sync_workflow_config.yaml
```

### 2. Set SSM Parameters
```bash
# Config file paths
aws ssm put-parameter --name "/glue/workflows/daily_data_sync_task_config_s3_path" \
    --value "s3://my-config-bucket/configs/daily_data_sync_task_config.yaml" --type String

aws ssm put-parameter --name "/glue/workflows/daily_data_sync_workflow_config_s3_path" \
    --value "s3://my-config-bucket/configs/daily_data_sync_workflow_config.yaml" --type String

# Auth credentials
aws ssm put-parameter --name "/glue/auth/type1/client_id"     --value "..." --type SecureString
aws ssm put-parameter --name "/glue/auth/type1/client_secret" --value "..." --type SecureString

# RDS credentials
aws ssm put-parameter --name "/glue/rds/user"     --value "glue_user" --type SecureString
aws ssm put-parameter --name "/glue/rds/password" --value "..."       --type SecureString
```

### 3. Create Aurora RDS schema
```bash
mysql -h your-aurora-host -u admin -p your_database < sql/schema.sql
```

### 4. Configure Glue Job
- **Script**: `glue_job_main.py`
- **Extra Python files**: zip the entire framework, upload to S3
- **Additional Python modules**: `PyYAML==6.0.1,requests==2.31.0,pymysql==1.1.0,openpyxl==3.1.2,pandas==1.5.3,pyarrow==12.0.1`
- **Glue version**: 4.0
- **Worker type**: G.1X (scale up for large file ingestion)

### 5. Trigger the job
```bash
# Normal run
aws glue start-job-run --job-name my-workflow-job \
    --arguments '{"--workflow_name":"daily_data_sync","--input_date":"2025-01-15","--rds_host":"aurora.cluster.rds.amazonaws.com","--rds_database":"glue_db","--rds_user_param":"/glue/rds/user","--rds_password_param":"/glue/rds/password"}'

# Retry failed run
aws glue start-job-run --job-name my-workflow-job \
    --arguments '{"--workflow_name":"daily_data_sync","--retry":"true",...}'
```

---

## Adding a New Workflow

1. Create `{name}_task_config.yaml` and `{name}_workflow_config.yaml`
2. Upload to S3
3. Register SSM parameters for both file paths
4. Trigger job with `--workflow_name {name}`

No code changes needed.
