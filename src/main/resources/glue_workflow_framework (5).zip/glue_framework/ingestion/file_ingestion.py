"""
ingestion/file_ingestion.py
File-based ingestion engine.

Flow:
 1. Fetch zip from S3 source location
 2. Extract to staging S3 prefix
 3. For each task, match file by prefix
 4. Read as CSV / Excel / Parquet via Pandas → Spark
 5. Apply column transforms
 6. Write to Iceberg

Designed to run inside AWS Glue (Spark available).
"""
import io
import os
import zipfile
import tempfile
from typing import Optional

import boto3
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql import Row

from utils.transforms import transform_row
from utils.logger import get_logger

logger = get_logger("file_ingestion")


class FileIngestionEngine:
    """Handles zip-file based ingestion tasks."""

    def __init__(self, spark: SparkSession, file_cfg: dict):
        """
        file_cfg: Workflow.File_config section
            source_bucket_param: SSM param name for source bucket
            source_prefix:       S3 prefix where zip files are uploaded
            staging_prefix:      S3 prefix to unzip into
            archive_prefix:      S3 prefix to move processed zip files
        """
        self.spark    = spark
        self.s3       = boto3.client("s3")
        self.ssm      = boto3.client("ssm")
        self.file_cfg = file_cfg
        self._bucket: Optional[str] = None

    # ------------------------------------------------------------------
    # Bucket resolution
    # ------------------------------------------------------------------

    def _get_bucket(self) -> str:
        if self._bucket:
            return self._bucket
        param = self.file_cfg["source_bucket_param"]
        resp  = self.ssm.get_parameter(Name=param, WithDecryption=False)
        self._bucket = resp["Parameter"]["Value"]
        return self._bucket

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def prepare_zip(self) -> dict[str, str]:
        """
        Find the latest zip in source_prefix, extract it to staging_prefix.
        Returns mapping {filename_upper → s3_uri}.
        """
        bucket         = self._get_bucket()
        source_prefix  = self.file_cfg.get("source_prefix", "")
        staging_prefix = self.file_cfg.get("staging_prefix", "staging/")

        zip_key = self._find_latest_zip(bucket, source_prefix)
        if not zip_key:
            raise FileNotFoundError(
                f"No zip file found in s3://{bucket}/{source_prefix}")

        logger.info(f"Extracting s3://{bucket}/{zip_key} → {staging_prefix}")
        extracted = self._extract_zip_to_s3(bucket, zip_key, staging_prefix)

        # Archive the zip
        archive_key = zip_key.replace(
            source_prefix,
            self.file_cfg.get("archive_prefix", "archive/"))
        self.s3.copy_object(
            Bucket=bucket,
            CopySource={"Bucket": bucket, "Key": zip_key},
            Key=archive_key
        )
        logger.info(f"Archived zip → s3://{bucket}/{archive_key}")

        return extracted  # {FILENAME.UPPER → s3_uri}

    def execute(self, task_cfg: dict, extracted_files: dict[str, str]) -> dict:
        """
        Execute one file ingestion task.
        Returns stats dict.
        """
        task_name  = task_cfg.get("Service_name", "unknown")
        prefix     = task_cfg.get("File_prefix", "").upper()
        file_fmt   = task_cfg.get("File_format", "csv").lower()

        # Find matching file
        matched_uri = self._match_file(extracted_files, prefix)
        if not matched_uri:
            raise FileNotFoundError(
                f"[{task_name}] No file found with prefix '{prefix}' "
                f"in extracted files: {list(extracted_files.keys())}")

        logger.info(f"[{task_name}] Matched file: {matched_uri}")

        # Read into Pandas then Spark
        pdf = self._read_file(matched_uri, file_fmt, task_cfg)
        logger.info(f"[{task_name}] Read {len(pdf)} rows from file")

        # Transform
        columns    = task_cfg.get("Columns", [])
        extra_cols = task_cfg.get("Extra_columns", [])
        records    = [transform_row(row_dict, columns, extra_cols)
                      for row_dict in pdf.to_dict(orient="records")]

        # Write to Iceberg
        records_written = self._write_to_iceberg(task_cfg, records)

        return {
            "file_uri":       matched_uri,
            "rows_read":      len(pdf),
            "records_written": records_written,
        }

    # ------------------------------------------------------------------
    # S3 helpers
    # ------------------------------------------------------------------

    def _find_latest_zip(self, bucket: str, prefix: str) -> Optional[str]:
        """Return key of the most recently modified .zip object."""
        paginator = self.s3.get_paginator("list_objects_v2")
        pages     = paginator.paginate(Bucket=bucket, Prefix=prefix)
        latest_key   = None
        latest_mtime = None
        for page in pages:
            for obj in page.get("Contents", []):
                if obj["Key"].endswith(".zip"):
                    if latest_mtime is None or obj["LastModified"] > latest_mtime:
                        latest_mtime = obj["LastModified"]
                        latest_key   = obj["Key"]
        return latest_key

    def _extract_zip_to_s3(self, bucket: str, zip_key: str,
                           staging_prefix: str) -> dict[str, str]:
        """Download zip, extract, re-upload each file to staging. Returns file map."""
        obj     = self.s3.get_object(Bucket=bucket, Key=zip_key)
        content = obj["Body"].read()
        extracted = {}

        with zipfile.ZipFile(io.BytesIO(content)) as zf:
            for name in zf.namelist():
                if name.endswith("/"):
                    continue   # skip directories
                data    = zf.read(name)
                basename = os.path.basename(name)
                dest_key = f"{staging_prefix.rstrip('/')}/{basename}"
                self.s3.put_object(Bucket=bucket, Key=dest_key, Body=data)
                s3_uri = f"s3://{bucket}/{dest_key}"
                extracted[basename.upper()] = s3_uri
                logger.info(f"Extracted → {s3_uri}")

        return extracted

    # ------------------------------------------------------------------
    # File matching
    # ------------------------------------------------------------------

    @staticmethod
    def _match_file(extracted: dict[str, str], prefix: str) -> Optional[str]:
        """Find first extracted file whose UPPER name starts with prefix."""
        for fname_upper, uri in extracted.items():
            if fname_upper.startswith(prefix):
                return uri
        return None

    # ------------------------------------------------------------------
    # File reading
    # ------------------------------------------------------------------

    def _read_file(self, s3_uri: str, fmt: str, task_cfg: dict) -> pd.DataFrame:
        bucket, key = self._parse_uri(s3_uri)
        obj     = self.s3.get_object(Bucket=bucket, Key=key)
        content = obj["Body"].read()
        buf     = io.BytesIO(content)

        if fmt == "csv":
            skip = task_cfg.get("Skip_rows", 0)
            return pd.read_csv(buf, skiprows=skip)
        elif fmt in ("excel", "xlsx", "xls"):
            sheet     = task_cfg.get("Sheet_name", 0)
            skip      = task_cfg.get("Skip_rows", 0)
            return pd.read_excel(buf, sheet_name=sheet, skiprows=skip)
        elif fmt == "parquet":
            return pd.read_parquet(buf)
        else:
            raise ValueError(f"Unsupported file format: {fmt}")

    @staticmethod
    def _parse_uri(uri: str) -> tuple[str, str]:
        parts  = uri[5:].split("/", 1)
        return parts[0], parts[1]

    # ------------------------------------------------------------------
    # Iceberg write
    # ------------------------------------------------------------------

    def _write_to_iceberg(self, task_cfg: dict, records: list[dict]) -> int:
        if not records:
            return 0
        target   = task_cfg["Target"]
        catalog  = target["Catalog"]
        database = target["Database"]
        table    = target["Table"]
        mode     = target.get("Mode", "append")
        full_table = f"{catalog}.{database}.{table}"

        rows = [Row(**r) for r in records]
        df   = self.spark.createDataFrame(rows)

        if mode == "overwrite":
            df.writeTo(full_table).overwritePartitions()
        else:
            df.writeTo(full_table).append()

        count = df.count()
        logger.info(f"Wrote {count} records to {full_table} (mode={mode})")
        return count
