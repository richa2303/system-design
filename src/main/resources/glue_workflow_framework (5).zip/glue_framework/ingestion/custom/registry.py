"""
ingestion/custom/registry.py
─────────────────────────────────────────────────────────────────────────────
Central registry for custom task classes.

Registration
─────────────────────────────────────────────────────────────────────────────
Use the @register_custom_task("service_name") decorator on your subclass:

    from ingestion.custom.registry import register_custom_task
    from ingestion.custom.base_custom_task import BaseCustomTask

    @register_custom_task("my_special_task")
    class MySpecialTask(BaseCustomTask):
        def execute(self) -> list[dict]:
            ...

The key must match Service_name in the task_config YAML for tasks that have
CustomEnabled: true.

Lookup
─────────────────────────────────────────────────────────────────────────────
    from ingestion.custom.registry import get_custom_task_class
    cls = get_custom_task_class("my_special_task")   # None if not found
"""
from __future__ import annotations
from typing import Type, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ingestion.custom.base_custom_task import BaseCustomTask

# service_name (str) → subclass of BaseCustomTask
REGISTRY: dict[str, Type] = {}


def register_custom_task(service_name: str):
    """
    Class decorator that registers a BaseCustomTask subclass under
    the given service_name key.
    """
    def decorator(cls):
        REGISTRY[service_name] = cls
        return cls
    return decorator


def get_custom_task_class(service_name: str) -> Optional[Type]:
    """
    Return the registered class for service_name, or None if not registered.
    """
    return REGISTRY.get(service_name)
