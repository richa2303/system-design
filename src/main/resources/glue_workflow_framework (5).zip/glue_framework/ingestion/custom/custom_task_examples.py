"""
ingestion/custom/custom_task_examples.py
─────────────────────────────────────────────────────────────────────────────
Concrete custom task implementations.

The ONLY method each class needs to implement is build_params().
Everything else — calling the API, handling retries, token refresh,
response normalisation, column transforms, Iceberg write — is handled
by BaseCustomTask automatically.

build_params() must return:  list[dict]
    Each dict in the list → one API call.
    Keys in each dict → the query/body params sent to the API.
    These same dicts are passed as resolved_params to transform_row()
    so Extra_columns with Source=query_param can reference them by name.

─────────────────────────────────────────────────────────────────────────────
How to add a new custom task
─────────────────────────────────────────────────────────────────────────────
1. Add a class here (or in a new file imported from __init__.py)
2. Decorate with @register_custom_task("your_service_name")
3. Inherit BaseCustomTask
4. Implement build_params(self) -> list[dict]
5. Set Service_name: your_service_name  +  CustomEnabled: true  in task YAML

That's it.  The framework handles everything from the API call onwards.
"""
from __future__ import annotations

from datetime import date, timedelta

from ingestion.custom.base_custom_task import BaseCustomTask
from ingestion.custom.registry import register_custom_task


# ──────────────────────────────────────────────────────────────────────
# Custom Task 1 — AttendanceSpecialTask
#
# Scenario: The attendance API requires (emp_id, start_date, end_date)
# per call, but we can't derive these from a single SQL query because:
#   • emp_ids come from one Iceberg table
#   • Dates must be computed as a rolling 7-day window per department
#   • Only employees whose cost_centre is in a configured whitelist should
#     be included
#   • Each (emp_id, week_start) pair is one API call
# ──────────────────────────────────────────────────────────────────────

@register_custom_task("attendance_special_task")
class AttendanceSpecialTask(BaseCustomTask):
    """
    Builds params by:
      1. Running SQL to get active employees with their cost_centre.
      2. Running SQL to get the target date ranges (one row per week).
      3. Cross-joining employees × date_ranges, filtered by whitelist.
      4. Each (emp_id, start_date, end_date) dict → one API call.

    task_config YAML:
        Custom_config.attendance_special:
          Service_name: attendance_special_task
          CustomEnabled: true
          Enable: true
          Auth_ref: type1_auth_token
          SourceService: "https://api.example.com/v1/attendance"
          ServiceMethod: GET
          ServiceHeader:
            Accept: "application/json"
            Authorization: "${type1_auth_token}"
          Api_timeout_seconds: 30
          Target:
            Catalog: glue_emp_catalog
            Database: emp_db
            Table: attendance_detail
            Mode: append
          Columns:
            - name: attendanceId
              Alias: attendance_id
            - name: empId
              Alias: emp_id
            - name: attendanceDate
              To_date: true
              Format: YYYY-MM-DD
              Alias: attendance_date
            - name: hoursWorked
              Cast: double
              Alias: hours_worked
          Extra_columns:
            - name: emp_id          # matches key in the param dict
              Source: query_param
              Alias: source_emp_id
            - name: start_date      # matches key in the param dict
              Source: query_param
              To_date: true
              Format: YYYY-MM-DD
              Alias: period_start
          Custom_params:
            SQL_employees: >
              SELECT emp_id, cost_centre, department
              FROM   emp_db.active_employees
              WHERE  status = 'ACTIVE'
            SQL_date_ranges: >
              SELECT week_start_date, week_end_date
              FROM   emp_db.payroll_weeks
              WHERE  pay_period = '${inputDate}'
            Cost_centre_whitelist:
              - CC001
              - CC002
              - CC003
    """

    def validate_config(self):
        super().validate_config()
        cp = self.task_cfg.get("Custom_params", {}) or {}
        for key in ("SQL_employees", "SQL_date_ranges"):
            if not cp.get(key):
                raise ValueError(
                    f"AttendanceSpecialTask requires Custom_params.{key}"
                )

    def build_params(self) -> list[dict]:
        """
        Cross-join employees × date_ranges filtered by cost_centre whitelist.
        Returns one param dict per (emp_id, week) combination.
        """
        cp        = self.task_cfg.get("Custom_params", {}) or {}
        whitelist = set(cp.get("Cost_centre_whitelist", []) or [])

        # ── Step 1: get active employees ───────────────────────────────
        employees   = self.run_sql(cp["SQL_employees"])
        date_ranges = self.run_sql(cp["SQL_date_ranges"])

        self.logger.info(
            f"{len(employees)} employees, {len(date_ranges)} date ranges "
            f"→ up to {len(employees) * len(date_ranges)} API calls before filter"
        )

        # ── Step 2: apply whitelist and build param dicts ──────────────
        params: list[dict] = []
        for emp in employees:
            if whitelist and emp.get("cost_centre") not in whitelist:
                continue
            for dr in date_ranges:
                params.append({
                    "emp_id":     str(emp["emp_id"]),
                    "start_date": str(dr["week_start_date"]),
                    "end_date":   str(dr["week_end_date"]),
                    "department": str(emp.get("department", "")),
                })

        self.logger.info(
            f"After whitelist filter: {len(params)} API calls"
        )
        return params


# ──────────────────────────────────────────────────────────────────────
# Custom Task 2 — PayrollReconciliationTask
#
# Scenario: Payroll reconciliation uses a two-phase pattern:
#   Phase 1 — call the control-summary endpoint to get a list of
#             payroll batch IDs for the given period
#   Phase 2 — for each batch_id, call the detail endpoint
#
# The control-summary call happens inside build_params() so its result
# (the list of batch_ids) drives the parameter list that the base class
# then fans out to the detail API in parallel.
# ──────────────────────────────────────────────────────────────────────

@register_custom_task("payroll_reconciliation_task")
class PayrollReconciliationTask(BaseCustomTask):
    """
    Phase 1: call the control API → get batch_ids for the period.
    Phase 2: return [{batch_id, period}, …] — one dict per batch_id.
             BaseCustomTask fans these out to the detail API automatically.

    The detail API URL is set as SourceService in the task config.
    The control API URL is set under Custom_params.Control_api_url.

    task_config YAML:
        Custom_config.payroll_recon:
          Service_name: payroll_reconciliation_task
          CustomEnabled: true
          Enable: true
          Auth_ref: type2_auth_token
          SourceService: "https://api.example.com/v1/payroll/detail"
          ServiceMethod: GET
          ServiceHeader:
            Accept: "application/json"
            Authorization: "${type2_auth_token}"
          Response_key: "data.line_items"
          Api_timeout_seconds: 45
          Target:
            Catalog: glue_emp_catalog
            Database: emp_db
            Table: payroll_reconciliation
            Mode: append
          Columns:
            - name: lineItemId
              Alias: line_item_id
            - name: batchId
              Alias: batch_id
            - name: amount
              Cast: double
              Alias: amount
            - name: currency
              Alias: currency_code
          Extra_columns:
            - name: batch_id    # matches key in param dict
              Source: query_param
              Alias: source_batch_id
            - name: period      # matches key in param dict
              Source: query_param
              Alias: payroll_period
          Custom_params:
            Control_api_url: "https://api.example.com/v1/payroll/control"
            Period_param: "inputDate"     # runtime_params key for the period
            Batch_id_field: "batchId"     # field name in control response
    """

    def validate_config(self):
        super().validate_config()
        cp = self.task_cfg.get("Custom_params", {}) or {}
        if not cp.get("Control_api_url"):
            raise ValueError(
                "PayrollReconciliationTask requires "
                "Custom_params.Control_api_url"
            )

    def build_params(self) -> list[dict]:
        """
        Call the control API once → extract batch_ids → return as param list.
        The base class will call the detail API (SourceService) once per batch_id.
        """
        cp          = self.task_cfg.get("Custom_params", {}) or {}
        ctrl_url    = cp["Control_api_url"]
        period_key  = cp.get("Period_param", "inputDate")
        batch_field = cp.get("Batch_id_field", "batchId")

        period = self.runtime_params.get(period_key)
        if not period:
            raise ValueError(
                f"PayrollReconciliationTask: runtime_params['{period_key}'] "
                f"is missing. Pass --{period_key} as a Glue job parameter."
            )

        # ── Phase 1: single call to control endpoint ───────────────────
        self.logger.info(
            f"Phase 1: calling control API {ctrl_url} for period={period}"
        )
        ctrl_records = self.call_api(
            params={"period": period},
            url=ctrl_url,
            method="GET",
        )
        self.logger.info(
            f"Control API returned {len(ctrl_records)} batch(es)"
        )

        # ── Build phase-2 param list ───────────────────────────────────
        params: list[dict] = []
        for rec in ctrl_records:
            batch_id = rec.get(batch_field)
            if not batch_id:
                self.logger.warning(
                    f"Control record missing '{batch_field}' — skipping: {rec}"
                )
                continue
            params.append({
                "batch_id": str(batch_id),
                "period":   str(period),
            })

        self.logger.info(
            f"Phase 2 will call detail API for {len(params)} batch_id(s)"
        )
        return params


# ──────────────────────────────────────────────────────────────────────
# Custom Task 3 — RollingDateRangeTask
#
# Scenario: The API accepts a single date and returns data for that day.
# We want to backfill a rolling N-day window without a database table —
# the date list is computed entirely in code.
# ──────────────────────────────────────────────────────────────────────

@register_custom_task("rolling_date_range_task")
class RollingDateRangeTask(BaseCustomTask):
    """
    Generates a list of {target_date} params covering the last N days
    purely from Python — no SQL query needed.

    task_config YAML:
        Custom_config.daily_metrics:
          Service_name: rolling_date_range_task
          CustomEnabled: true
          Enable: true
          Auth_ref: type1_auth_token
          SourceService: "https://api.example.com/v1/metrics/daily"
          ServiceMethod: GET
          ServiceHeader:
            Accept: "application/json"
            Authorization: "${type1_auth_token}"
          Target:
            Catalog: glue_emp_catalog
            Database: emp_db
            Table: daily_metrics
            Mode: append
          Columns:
            - name: metricId
              Alias: metric_id
            - name: value
              Cast: double
              Alias: metric_value
          Extra_columns:
            - name: target_date    # matches key in param dict
              Source: query_param
              To_date: true
              Format: YYYY-MM-DD
              Alias: metric_date
          Custom_params:
            Lookback_days: 7        # how many days back to fetch
            Date_param_name: "targetDate"   # API query param name for the date
    """

    def build_params(self) -> list[dict]:
        """
        Build one param dict per day in the lookback window.
        e.g. Lookback_days=7 → 7 API calls for the past 7 days.
        """
        cp             = self.task_cfg.get("Custom_params", {}) or {}
        lookback_days  = int(cp.get("Lookback_days", 7))
        date_param_name = cp.get("Date_param_name", "targetDate")

        # Anchor date: use inputDate from runtime_params if provided,
        # otherwise default to today
        anchor_str = self.runtime_params.get("inputDate", str(date.today()))
        try:
            anchor = date.fromisoformat(anchor_str)
        except ValueError:
            anchor = date.today()

        params: list[dict] = []
        for offset in range(lookback_days):
            target = anchor - timedelta(days=offset)
            params.append({
                date_param_name: target.strftime("%Y-%m-%d"),
                "target_date":   target.strftime("%Y-%m-%d"),  # for Extra_columns
            })

        self.logger.info(
            f"RollingDateRangeTask: {len(params)} days "
            f"({params[-1][date_param_name]} → {params[0][date_param_name]})"
        )
        return params
