"""
core/auth_manager.py
─────────────────────────────────────────────────────────────────────────────
Manages OAuth bearer tokens for API ingestion.

Auth config is loaded from an S3 YAML file whose path is passed as the
job parameter  --auth_config_s3_path  (e.g. s3://my-bucket/auth/auth.yaml).

Auth YAML format
─────────────────────────────────────────────────────────────────────────────
Auth:
  Type1_auth:
    Url: "https://auth.example.com/oauth/token"
    Method: "POST"
    Headers:
      Content-Type: "application/x-www-form-urlencoded"
    Json:
      Client_id: "my-client-id"
      Client_secret: "my-secret"
      Grant_type: "client_credentials"
      Scope: "read write"
    Token_json_path: "access_token"   # dot-notation path into the JSON response
    Token_prefix: "Bearer"            # prepended when substituting into headers
    Timeout_seconds: 30
    Expiry_minutes: 60                # how long to cache the token

  Type2_auth:
    Url: "https://auth2.example.com/token"
    Method: "POST"
    Headers:
      Content-Type: "application/x-www-form-urlencoded"
    Json:
      Client_id: "client2"
      Client_secret: "secret2"
      Grant_type: "password"
      Scope: "api"
    Token_json_path: "data.token"     # nested path: response["data"]["token"]
    Token_prefix: ""                  # no prefix (raw token used in header)
    Timeout_seconds: 30
    Expiry_minutes: 55

─────────────────────────────────────────────────────────────────────────────
Key behaviours
─────────────────────────────────────────────────────────────────────────────
• All token definitions are loaded from the S3 file at startup.
• Tokens are cached with an expiry window; a 2-minute safety buffer triggers
  a proactive refresh so long-running (>1 hour) jobs never send expired tokens.
• get_token() and resolve_headers() are thread-safe (RLock).
• Token_json_path supports dot-notation to extract from nested responses.
• Token_prefix is prepended with a space when non-empty (e.g. "Bearer <token>").
"""
import io
import threading
from datetime import datetime, timedelta
from typing import Any, Optional

import boto3
import requests
import yaml

from utils.logger import get_logger
from utils.transforms import extract_nested_value  # reuse dot-notation helper

logger = get_logger("auth_manager")

_REFRESH_BUFFER_SECS = 120   # refresh 2 minutes before expiry


# ──────────────────────────────────────────────────────────────────────
# Token cache entry
# ──────────────────────────────────────────────────────────────────────

class _TokenEntry:
    __slots__ = ("raw_token", "prefixed_token", "expires_at")

    def __init__(self, raw_token: str, prefix: str, expiry_minutes: int):
        self.raw_token      = raw_token
        self.prefixed_token = f"{prefix} {raw_token}".strip() if prefix else raw_token
        self.expires_at     = datetime.utcnow() + timedelta(minutes=expiry_minutes)

    def is_valid(self) -> bool:
        return (self.expires_at - datetime.utcnow()).total_seconds() > _REFRESH_BUFFER_SECS


# ──────────────────────────────────────────────────────────────────────
# Auth Manager
# ──────────────────────────────────────────────────────────────────────

class AuthManager:
    """
    Thread-safe OAuth token manager driven entirely by an S3 YAML auth file.

    Usage:
        auth_manager = AuthManager.from_s3(s3_uri)
        auth_manager.preload_all()
        headers = auth_manager.resolve_headers(raw_headers, "Type1_auth")
    """

    def __init__(self, auth_defs: dict):
        """
        auth_defs: the parsed contents of the Auth: section of the YAML.
        Keys are auth ref names (e.g. "Type1_auth"); values are the config dicts.
        """
        self._defs:  dict[str, dict]       = auth_defs or {}
        self._cache: dict[str, _TokenEntry] = {}
        self._lock   = threading.RLock()
        self._s3     = boto3.client("s3")

    # ------------------------------------------------------------------
    # Factory: build from S3 YAML path
    # ------------------------------------------------------------------

    @classmethod
    def from_s3(cls, s3_uri: str) -> "AuthManager":
        """
        Load the auth YAML from S3 and return an AuthManager instance.

        s3_uri format: s3://bucket-name/path/to/auth.yaml
        """
        s3 = boto3.client("s3")
        bucket, key = _parse_s3_uri(s3_uri)
        logger.info(f"Loading auth config from s3://{bucket}/{key}")
        obj     = s3.get_object(Bucket=bucket, Key=key)
        content = obj["Body"].read().decode("utf-8")
        cfg     = yaml.safe_load(content)

        if not cfg or "Auth" not in cfg:
            raise ValueError(
                f"Auth YAML at {s3_uri} must have a top-level 'Auth:' key"
            )

        auth_defs = cfg["Auth"]
        logger.info(f"Loaded {len(auth_defs)} auth definition(s): "
                    f"{list(auth_defs.keys())}")
        return cls(auth_defs)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def preload_all(self):
        """Eagerly fetch and cache every token defined in the auth file."""
        for ref_name in self._defs:
            logger.info(f"Pre-loading auth token: '{ref_name}'")
            self._fetch_and_cache(ref_name)

    def get_token(self, ref_name: str) -> str:
        """
        Return the raw token string for `ref_name`, refreshing if expired.
        Thread-safe.
        """
        with self._lock:
            entry = self._cache.get(ref_name)
            if entry and entry.is_valid():
                return entry.raw_token
            logger.info(f"Token '{ref_name}' missing or near-expiry — refreshing …")
            return self._fetch_and_cache(ref_name)

    def force_refresh_token(self, ref_name: str) -> str:
        """
        Immediately evict the cached token for `ref_name` and fetch a
        fresh one from the auth endpoint, regardless of expiry.

        Called when the API returns HTTP 403 — the cached token may have
        been revoked or invalidated server-side before its stated expiry.

        Returns the new raw token string.
        Thread-safe.
        """
        with self._lock:
            # Evict so _fetch_and_cache always makes a real HTTP call
            self._cache.pop(ref_name, None)
            logger.info(
                f"Force-refreshing token '{ref_name}' "
                f"(triggered by 403 response)"
            )
            return self._fetch_and_cache(ref_name)

    def get_prefixed_token(self, ref_name: str) -> str:
        """
        Return the token with its configured prefix (e.g. "Bearer <token>").
        Use this when you need the full Authorization header value.
        """
        with self._lock:
            entry = self._cache.get(ref_name)
            if entry and entry.is_valid():
                return entry.prefixed_token
            self._fetch_and_cache(ref_name)
            return self._cache[ref_name].prefixed_token

    def resolve_headers(self, raw_headers: dict, ref_name: str) -> dict:
        """
        Return a copy of raw_headers with every  ${ref_name}  placeholder
        replaced by the live prefixed token for that auth ref.

        Example header config:
            Authorization: "${type1_auth_token}"
        becomes:
            Authorization: "Bearer eyJhbGc..."
        """
        prefixed = self.get_prefixed_token(ref_name)
        resolved = {}
        for k, v in raw_headers.items():
            if isinstance(v, str):
                # Replace both the exact ref_name and lower-case variants
                v = v.replace(f"${{{ref_name}}}", prefixed)
            resolved[k] = v
        return resolved

    # ------------------------------------------------------------------
    # Internal fetch + cache
    # ------------------------------------------------------------------

    def _fetch_and_cache(self, ref_name: str) -> str:
        """Fetch a fresh token and store it in the cache. Returns raw token."""
        cfg = self._defs.get(ref_name)
        if not cfg:
            raise ValueError(
                f"No auth definition found for ref '{ref_name}'. "
                f"Available: {list(self._defs.keys())}"
            )

        url             = cfg["Url"]
        method          = cfg.get("Method", "POST").upper()
        headers         = dict(cfg.get("Headers", {}) or {})
        body            = dict(cfg.get("Json",    {}) or {})
        token_path      = cfg.get("Token_json_path", "access_token")
        token_prefix    = cfg.get("Token_prefix", "Bearer") or ""
        timeout         = int(cfg.get("Timeout_seconds", 30))
        expiry_minutes  = int(cfg.get("Expiry_minutes", 60))

        # Build the form-encoded or JSON payload based on Content-Type
        content_type = headers.get("Content-Type", headers.get("content-type", ""))
        is_form      = "form" in content_type.lower()

        logger.info(f"Fetching token for '{ref_name}' via {method} {url}")

        if method == "POST":
            if is_form:
                # application/x-www-form-urlencoded — lowercase the keys for OAuth
                form_body = {_snake(k): v for k, v in body.items()}
                resp = requests.post(url, headers=headers, data=form_body,
                                     timeout=timeout)
            else:
                resp = requests.post(url, headers=headers, json=body,
                                     timeout=timeout)
        elif method == "GET":
            resp = requests.get(url, headers=headers, params=body,
                                timeout=timeout)
        else:
            raise NotImplementedError(
                f"Auth method '{method}' not supported for '{ref_name}'"
            )

        resp.raise_for_status()
        data = resp.json()

        # Extract token using dot-notation path (e.g. "data.access_token")
        raw_token = extract_nested_value(data, token_path)
        if not raw_token:
            raise ValueError(
                f"Token path '{token_path}' not found in auth response "
                f"for '{ref_name}'. Response keys: {list(data.keys()) if isinstance(data, dict) else type(data)}"
            )

        entry = _TokenEntry(str(raw_token), token_prefix, expiry_minutes)
        self._cache[ref_name] = entry
        logger.info(
            f"Token '{ref_name}' cached "
            f"(prefix='{token_prefix}', "
            f"expires_in={expiry_minutes}min, "
            f"path='{token_path}')"
        )
        return entry.raw_token


# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────

def _parse_s3_uri(uri: str) -> tuple[str, str]:
    assert uri.startswith("s3://"), f"Expected s3:// URI, got: {uri}"
    parts  = uri[5:].split("/", 1)
    bucket = parts[0]
    key    = parts[1] if len(parts) > 1 else ""
    return bucket, key


def _snake(key: str) -> str:
    """Normalise a YAML key like 'Client_id' → 'client_id' for OAuth forms."""
    return key.lower().replace(" ", "_")
