"""
utils/transforms.py
Column-level transformation helpers used by both API and file ingestion.

Supports:
  - Nested key extraction via dot-notation  (e.g. "department.name")
  - Type casting  (int / double / float / string / bool)
  - Date conversion with configurable Format strings
  - Alias renaming
  - Extra_columns enrichment: stitch queryParams values into response rows

Extra_columns key convention:
    The `name` field of an Extra_column entry MUST exactly match the
    corresponding queryParams key name (e.g. "startDate").  No separate
    Param_key field is needed.  The resolved_params dict passed from
    _build_request_params is keyed by queryParams names, so a direct lookup
    by `name` always finds the right value.

    Config example:
        queryParams:
          startDate:               ← queryParams key
            From: inputDate
            Transform: date:%Y-%m-%d
          Emp_department:          ← queryParams key
            From: emp_department
            sourceType: query

        Extra_columns:
          - name: startDate        ← MUST match queryParams key exactly
            Source: query_param
            Nullable: true
            To_date: true
            Format: YYYY-MM-DD
            Alias: start_date      ← Iceberg target column name

          - name: Emp_department   ← MUST match queryParams key exactly
            Source: query_param
            Nullable: true
            Alias: emp_department
"""
from datetime import datetime
from typing import Any

from utils.logger import get_logger

logger = get_logger("transforms")


# ------------------------------------------------------------------ #
#  Nested key extraction                                               #
# ------------------------------------------------------------------ #

def extract_nested_value(record: dict, key_path: str, default=None) -> Any:
    """
    Extract a value from a (possibly nested) dict using dot notation.

    Examples:
        extract_nested_value(rec, "department.name")
            → rec["department"]["name"]
        extract_nested_value(rec, "address.city.zip")
            → rec["address"]["city"]["zip"]
        extract_nested_value(rec, "simpleKey")
            → rec["simpleKey"]

    Returns `default` if any key is missing or the path goes through a
    non-dict value.
    """
    if not isinstance(record, dict):
        return default
    keys  = key_path.split(".")
    value = record
    for k in keys:
        if not isinstance(value, dict):
            return default
        value = value.get(k)
        if value is None:
            return default
    return value


# ------------------------------------------------------------------ #
#  Column-level transform                                              #
# ------------------------------------------------------------------ #

def apply_column_transform(value: Any, col_def: dict) -> Any:
    """
    Apply cast / to_date transformation as defined in a column config entry.
    To_date takes precedence over Cast when both are present.
    """
    if value is None:
        return None

    cast    = col_def.get("Cast")
    to_date = col_def.get("To_date", False)
    fmt     = col_def.get("Format")

    if to_date:
        return _parse_date(value, fmt)

    if cast:
        value = _cast_value(value, str(cast).lower())

    return value


def _parse_date(value: Any, fmt: str = None) -> Any:
    """Convert a string/datetime value to datetime.date."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    str_val = str(value).strip()
    if not str_val:
        return None

    if fmt:
        # Normalise common token aliases: YYYY→%Y  MM→%m  DD→%d
        py_fmt = (fmt
                  .replace("YYYY", "%Y")
                  .replace("MM",   "%m")
                  .replace("DD",   "%d"))
        try:
            return datetime.strptime(str_val, py_fmt).date()
        except ValueError:
            pass

    # Fallback format attempts
    for attempt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%Y%m%d"):
        try:
            return datetime.strptime(str_val, attempt).date()
        except ValueError:
            continue

    logger.warning(f"Could not parse date value='{value}' with format='{fmt}'")
    return None


def _cast_value(value: Any, cast_type: str) -> Any:
    """Safe type cast. Returns original value if cast fails."""
    try:
        if cast_type == "int":
            return int(float(str(value))) if value not in (None, "") else None
        if cast_type in ("double", "float"):
            return float(str(value)) if value not in (None, "") else None
        if cast_type == "bool":
            return str(value).lower() in ("true", "1", "yes")
        if cast_type == "string":
            return str(value)
    except (ValueError, TypeError) as exc:
        logger.warning(
            f"Cast failed: value='{value}', target_type='{cast_type}': {exc}"
        )
    return value


# ------------------------------------------------------------------ #
#  Full row transform                                                  #
# ------------------------------------------------------------------ #

def transform_row(
    raw_record:    dict,
    columns:       list[dict],
    extra_columns: list[dict],
    resolved_params: dict = None,
) -> dict:
    """
    Transform one raw record (from API response or file row) into the
    target Iceberg schema.

    Args:
        raw_record:      Raw dict from the API response or file row.
        columns:         Column definitions from task config `Columns` list.
                         `name` supports dot-notation for nested API fields.
        extra_columns:   Extra column definitions from `Extra_columns` list.
                         When Source=query_param, the value is pulled from
                         resolved_params using the `name` field as the key.
        resolved_params: The output of _build_request_params() for this call —
                         a dict keyed by queryParams key names (e.g. "startDate").
                         Required when Extra_columns with Source=query_param exist.

    Returns:
        A flat dict ready to be written as one Iceberg row.
    """
    row: dict = {}

    # ── Standard response columns ──────────────────────────────────────
    for col in (columns or []):
        raw_name = col["name"]
        alias    = col.get("Alias", raw_name)
        nullable = col.get("Nullable", True)

        # Dot-notation extraction supports nested API response objects
        raw_val     = extract_nested_value(raw_record, raw_name)
        transformed = apply_column_transform(raw_val, col)

        if not nullable and transformed is None:
            logger.warning(
                f"Non-nullable column '{raw_name}' resolved to None in record"
            )

        row[alias] = transformed

    # ── Extra columns: queryParams passthrough enrichment ──────────────
    for ecol in (extra_columns or []):
        source   = ecol.get("Source")
        # `name` MUST match the queryParams key name exactly
        col_name = ecol["name"]
        alias    = ecol.get("Alias", col_name)
        nullable = ecol.get("Nullable", True)

        if source == "query_param":
            if not resolved_params:
                # Config declares enrichment but no resolved params were passed.
                # This is a call-site bug — warn clearly so it shows in Glue logs.
                logger.warning(
                    f"Extra_column '{alias}' (name='{col_name}') has "
                    f"Source=query_param but resolved_params is empty/None — "
                    f"column will be NULL. Check that _call_api passes "
                    f"resolved_params to transform_row."
                )
                raw_val = None
            else:
                # Direct lookup by name — which equals the queryParams key
                raw_val = resolved_params.get(col_name)
                if raw_val is None and not nullable:
                    logger.warning(
                        f"Extra_column '{alias}': name='{col_name}' not found "
                        f"in resolved_params. Available keys: "
                        f"{list(resolved_params.keys())}"
                    )
        else:
            raw_val = None

        row[alias] = apply_column_transform(raw_val, ecol)

    return row
