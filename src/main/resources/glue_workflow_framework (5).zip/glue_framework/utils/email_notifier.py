"""
utils/email_notifier.py
─────────────────────────────────────────────────────────────────────────────
Sends an HTML workflow execution report email via SMTP after every
workflow run completes — success or failure.

Supports any SMTP server: corporate relay, Gmail, Outlook, SendGrid, etc.
TLS (STARTTLS on port 587) and plain (port 25, no auth) are both supported.

Email structure
─────────────────────────────────────────────────────────────────────────────
  ┌──────────────────────────────────────────────────────────────┐
  │  ❌ / ✅  Workflow Execution Report                          │
  ├──────────────────────────────────────────────────────────────┤
  │  Workflow Information                                        │
  │    Workflow Name   : daily_data_sync                         │
  │    Execution ID    : <uuid>                                  │
  │    Run ID          : jr_abc123                               │
  │    Status          : ❌ FAILED / ✅ SUCCESS                  │
  │    Started         : 2025-01-15 08:00:00 UTC                 │
  │    Completed       : 2025-01-15 08:04:32 UTC                 │
  │    Duration        : 4m 32s                                  │
  │    Is Retry        : No                                      │
  ├──────────────────────────────────────────────────────────────┤
  │  Execution Summary                                           │
  │    Groups : 5 total  ✅4  ❌1  ⏭0                           │
  │    Tasks  : 8 total  ✅6  ❌1  ⏭1                           │
  │    Total Records Ingested : 142,830                          │
  ├──────────────────────────────────────────────────────────────┤
  │  Group & Task Detail                                         │
  │  ┌──────────────────────────────────────────────────────┐   │
  │  │ ✅ Group: group1  Depends on: —  Duration: 1m05s     │   │
  │  │   task1  task_1  ✅  1m05s   12,450 records ingested │   │
  │  │ ❌ Group: group3  Depends on: group1  Duration: 2m33s│   │
  │  │   task3  task_3  ✅  1m18s   41,680 records ingested │   │
  │  │   task_f task_f  ❌  1m14s   ERROR: ValueError …     │   │
  │  │ ⏭ Group: group4  Depends on: group2  (skipped)       │   │
  │  │   task4  task_4  ⏭         dep failed                │   │
  │  └──────────────────────────────────────────────────────┘   │
  └──────────────────────────────────────────────────────────────┘

Configuration (Glue job parameters)
─────────────────────────────────────────────────────────────────────────────
  --notification_recipients   team@corp.com,oncall@corp.com
  --notification_sender       glue-alerts@corp.com
  --smtp_host                 smtp.corp.com
  --smtp_port                 587           (default: 587)
  --smtp_user                 glue-smtp-user
  --smtp_password_param       /glue/smtp/password   (SSM SecureString path)
  --smtp_use_tls              true          (default: true)
"""
from __future__ import annotations

import html
import smtplib
import ssl
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

import boto3

from utils.logger import get_logger

logger = get_logger("email_notifier")


# ──────────────────────────────────────────────────────────────────────────────
# Data model
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class TaskReport:
    """Result of one task execution."""
    task_name:         str
    service_name:      str
    status:            str            # SUCCESS | FAILED | SKIPPED
    started_at:        Optional[datetime]
    completed_at:      Optional[datetime]
    records_written:   Optional[int]
    query_row_count:   Optional[int]
    api_success_count: Optional[int]
    api_failure_count: Optional[int]
    error_message:     Optional[str]

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None


@dataclass
class GroupReport:
    """Result of one group execution, containing all its task results."""
    group_id:     str
    depends_on:   list[str]
    status:       str
    started_at:   Optional[datetime]
    completed_at: Optional[datetime]
    tasks:        list[TaskReport] = field(default_factory=list)

    @property
    def total_records(self) -> int:
        return sum(t.records_written or 0 for t in self.tasks)

    @property
    def failed_task_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == "FAILED")

    @property
    def success_task_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == "SUCCESS")

    @property
    def skipped_task_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == "SKIPPED")

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None


@dataclass
class WorkflowReport:
    """Complete execution report for one workflow run."""
    workflow_name:  str
    execution_id:   str
    run_id:         str
    status:         str
    is_retry:       bool
    retry_of_id:    Optional[str]
    started_at:     Optional[datetime]
    completed_at:   Optional[datetime]
    groups:         list[GroupReport] = field(default_factory=list)

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    @property
    def total_records(self) -> int:
        return sum(g.total_records for g in self.groups)

    @property
    def total_tasks(self) -> int:
        return sum(len(g.tasks) for g in self.groups)

    @property
    def failed_tasks(self) -> int:
        return sum(g.failed_task_count for g in self.groups)

    @property
    def success_tasks(self) -> int:
        return sum(g.success_task_count for g in self.groups)

    @property
    def skipped_tasks(self) -> int:
        return sum(g.skipped_task_count for g in self.groups)

    @property
    def failed_groups(self) -> int:
        return sum(1 for g in self.groups if g.status == "FAILED")

    @property
    def success_groups(self) -> int:
        return sum(1 for g in self.groups if g.status == "SUCCESS")

    @property
    def skipped_groups(self) -> int:
        return sum(1 for g in self.groups if g.status == "SKIPPED")


# ──────────────────────────────────────────────────────────────────────────────
# SMTP configuration
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class NotificationConfig:
    """
    SMTP email notification settings.

    smtp_host             SMTP server hostname or IP
    smtp_port             Port — 587 for STARTTLS (default), 25 for plain,
                          465 for implicit TLS
    smtp_user             SMTP login username (leave blank for anonymous relay)
    smtp_password_param   AWS SSM parameter name (SecureString) holding the
                          SMTP password.  Fetched at send time — never stored
                          in plain text.  Leave blank for anonymous relay.
    smtp_use_tls          Use STARTTLS (default True).  Set False for plain
                          port-25 relay that needs no auth.
    recipients            List of To: addresses
    sender                From: address (must be allowed by your SMTP server)
    enabled               Master on/off switch
    send_on_success       Send on SUCCESS runs (default True)
    send_on_failure       Send on FAILED runs (default True)
    """
    recipients:          list[str]
    sender:              str
    smtp_host:           str
    smtp_port:           int  = 587
    smtp_user:           str  = ""
    smtp_password_param: str  = ""   # SSM parameter path
    smtp_use_tls:        bool = True
    enabled:             bool = True
    send_on_success:     bool = True
    send_on_failure:     bool = True

    # ------------------------------------------------------------------
    # Factory: build from Glue job args dict
    # ------------------------------------------------------------------

    @classmethod
    def from_args(cls, args: dict) -> Optional["NotificationConfig"]:
        """
        Build from Glue job args.  Returns None when notifications are
        not configured (no recipients or no smtp_host).

        Recognised keys (all optional except the two marked required):
            notification_recipients   [required] comma-separated To: addresses
            notification_sender       [required] From: address
            smtp_host                 [required] SMTP server host
            smtp_port                 default 587
            smtp_user                 SMTP username (omit for anonymous)
            smtp_password_param       SSM path to password (omit for anonymous)
            smtp_use_tls              "true"/"false" (default "true")
        """
        raw_recip = args.get("notification_recipients", "").strip()
        smtp_host = args.get("smtp_host", "").strip()
        sender    = args.get("notification_sender", "").strip()

        if not raw_recip:
            return None
        if not smtp_host:
            logger.warning(
                "notification_recipients set but smtp_host is missing — "
                "email notifications disabled"
            )
            return None
        if not sender:
            logger.warning(
                "notification_recipients set but notification_sender is "
                "missing — email notifications disabled"
            )
            return None

        recipients = [r.strip() for r in raw_recip.split(",") if r.strip()]
        if not recipients:
            return None

        use_tls = args.get("smtp_use_tls", "true").lower() != "false"

        return cls(
            recipients          = recipients,
            sender              = sender,
            smtp_host           = smtp_host,
            smtp_port           = int(args.get("smtp_port", 587)),
            smtp_user           = args.get("smtp_user", "").strip(),
            smtp_password_param = args.get("smtp_password_param", "").strip(),
            smtp_use_tls        = use_tls,
        )

    def _resolve_password(self) -> str:
        """
        Fetch the SMTP password from AWS SSM at send time.
        Returns an empty string if no password param is configured
        (anonymous / relay mode).
        """
        if not self.smtp_password_param:
            return ""
        ssm  = boto3.client("ssm")
        resp = ssm.get_parameter(
            Name=self.smtp_password_param, WithDecryption=True
        )
        return resp["Parameter"]["Value"]


# ──────────────────────────────────────────────────────────────────────────────
# Notifier
# ──────────────────────────────────────────────────────────────────────────────

class WorkflowEmailNotifier:
    """
    Sends an HTML workflow execution report email via SMTP.

    Usage:
        cfg      = NotificationConfig.from_args(args)
        notifier = WorkflowEmailNotifier(cfg)
        notifier.send(report)
    """

    def __init__(self, config: NotificationConfig):
        self._cfg = config

    # ------------------------------------------------------------------
    # Public send
    # ------------------------------------------------------------------

    def send(self, report: WorkflowReport):
        """
        Build and dispatch the execution report email.
        Errors are caught and logged — a notification failure never
        crashes the Glue job.
        """
        cfg = self._cfg
        if not cfg.enabled:
            logger.info("Email notifications disabled — skipping")
            return

        if report.status == "SUCCESS" and not cfg.send_on_success:
            logger.info("send_on_success=False — skipping")
            return
        if report.status == "FAILED" and not cfg.send_on_failure:
            logger.info("send_on_failure=False — skipping")
            return

        subject   = self._build_subject(report)
        html_body = self._build_html(report)
        text_body = self._build_text(report)

        logger.info(
            f"Sending execution report via SMTP "
            f"({cfg.smtp_host}:{cfg.smtp_port}) "
            f"to {cfg.recipients} — workflow '{report.workflow_name}' "
            f"[{report.status}]"
        )

        try:
            self._smtp_send(subject, html_body, text_body)
            logger.info("Execution report email sent successfully")
        except Exception as exc:
            logger.error(f"Failed to send notification email: {exc}")

    # ------------------------------------------------------------------
    # SMTP dispatch
    # ------------------------------------------------------------------

    def _smtp_send(self, subject: str, html_body: str, text_body: str):
        """
        Build a MIME multipart/alternative message and send via SMTP.

        Connection strategy:
          smtp_use_tls=True  (default) → SMTP with STARTTLS on smtp_port
          smtp_use_tls=False           → plain SMTP (port 25 relay, no TLS)

        Authentication:
          smtp_user set     → login with user + SSM-resolved password
          smtp_user absent  → anonymous send (corporate relay)
        """
        cfg = self._cfg

        # Build MIME message
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = cfg.sender
        msg["To"]      = ", ".join(cfg.recipients)

        # Attach plain text first, then HTML (clients prefer the last part)
        msg.attach(MIMEText(text_body, "plain", "utf-8"))
        msg.attach(MIMEText(html_body, "html",  "utf-8"))

        # Connect and send
        if cfg.smtp_use_tls:
            # STARTTLS — standard for port 587
            context = ssl.create_default_context()
            with smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=30) as srv:
                srv.ehlo()
                srv.starttls(context=context)
                srv.ehlo()
                if cfg.smtp_user:
                    password = cfg._resolve_password()
                    srv.login(cfg.smtp_user, password)
                srv.sendmail(cfg.sender, cfg.recipients, msg.as_string())
        else:
            # Plain SMTP — port 25 anonymous corporate relay
            with smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=30) as srv:
                srv.ehlo()
                if cfg.smtp_user:
                    password = cfg._resolve_password()
                    srv.login(cfg.smtp_user, password)
                srv.sendmail(cfg.sender, cfg.recipients, msg.as_string())

    # ------------------------------------------------------------------
    # Subject line
    # ------------------------------------------------------------------

    def _build_subject(self, r: WorkflowReport) -> str:
        icon  = "SUCCESS" if r.status == "SUCCESS" else "FAILED"
        retry = " [RETRY]" if r.is_retry else ""
        return (
            f"[{icon}]{retry} Workflow: {r.workflow_name} | "
            f"Started: {_fmt_dt(r.started_at)}"
        )

    # ------------------------------------------------------------------
    # Plain-text fallback
    # ------------------------------------------------------------------

    def _build_text(self, r: WorkflowReport) -> str:
        lines = [
            "WORKFLOW EXECUTION REPORT",
            "=" * 70,
            f"Workflow Name  : {r.workflow_name}",
            f"Execution ID   : {r.execution_id}",
            f"Run ID         : {r.run_id}",
            f"Status         : {r.status}",
            f"Started        : {_fmt_dt(r.started_at)}",
            f"Completed      : {_fmt_dt(r.completed_at)}",
            f"Duration       : {_fmt_duration(r.duration_seconds)}",
            f"Is Retry       : {'Yes (of ' + (r.retry_of_id or '') + ')' if r.is_retry else 'No'}",
            "",
            "EXECUTION SUMMARY",
            "=" * 70,
            f"Groups  — Total: {len(r.groups):3d}  "
            f"Success: {r.success_groups:3d}  "
            f"Failed: {r.failed_groups:3d}  "
            f"Skipped: {r.skipped_groups:3d}",
            f"Tasks   — Total: {r.total_tasks:3d}  "
            f"Success: {r.success_tasks:3d}  "
            f"Failed: {r.failed_tasks:3d}  "
            f"Skipped: {r.skipped_tasks:3d}",
            f"Total Records Ingested : {r.total_records:,}",
            "",
            "GROUP & TASK DETAIL",
            "=" * 70,
        ]
        for g in r.groups:
            dep = ", ".join(g.depends_on) if g.depends_on else "—"
            lines.append(
                f"\n[{g.status:7s}] Group: {g.group_id}"
                f"  Depends on: {dep}"
                f"  Duration: {_fmt_duration(g.duration_seconds)}"
                f"  Records: {g.total_records:,}"
            )
            lines.append(
                f"  {'Task Name':<45} {'Status':<8} {'Duration':<10} Detail"
            )
            lines.append("  " + "-" * 90)
            for t in g.tasks:
                if t.status == "SUCCESS":
                    detail = f"{(t.records_written or 0):,} records ingested"
                    if t.query_row_count:
                        detail += f"  |  {t.query_row_count} query rows"
                    if t.api_failure_count:
                        detail += f"  |  {t.api_failure_count} API failures"
                elif t.status == "FAILED":
                    detail = f"ERROR: {(t.error_message or 'unknown')[:120]}"
                else:
                    detail = t.error_message or "skipped"
                dur = _fmt_duration(t.duration_seconds)
                lines.append(
                    f"  {t.task_name:<45} {t.status:<8} {dur:<10} {detail}"
                )
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # HTML email body
    # ------------------------------------------------------------------

    def _build_html(self, r: WorkflowReport) -> str:
        wf_color = "#2e7d32" if r.status == "SUCCESS" else "#c62828"
        wf_icon  = "&#x2705;" if r.status == "SUCCESS" else "&#x274C;"  # ✅ / ❌
        retry_txt = (
            f'Yes <span style="color:#666;font-size:12px;">'
            f'(of {html.escape(r.retry_of_id or "")})</span>'
            if r.is_retry else "No"
        )

        # ── header ────────────────────────────────────────────────────
        header_html = f"""
        <table width="100%" cellpadding="0" cellspacing="0"
               style="background:{wf_color};border-radius:6px 6px 0 0;">
          <tr>
            <td style="padding:20px 28px;">
              <span style="font-size:22px;font-weight:700;color:#fff;">
                {wf_icon}&nbsp; Workflow Execution Report
              </span>
            </td>
            <td style="padding:20px 28px;text-align:right;">
              <span style="font-size:13px;color:rgba(255,255,255,.8);">
                {html.escape(_fmt_dt(datetime.now(timezone.utc)))}
              </span>
            </td>
          </tr>
        </table>"""

        # ── workflow info ──────────────────────────────────────────────
        info_rows = [
            ("Workflow Name",
             f'<strong>{html.escape(r.workflow_name)}</strong>'),
            ("Execution ID",
             f'<code style="font-size:12px;background:#f5f5f5;'
             f'padding:2px 6px;border-radius:3px;">'
             f'{html.escape(r.execution_id)}</code>'),
            ("Run ID",
             f'<code style="font-size:12px;background:#f5f5f5;'
             f'padding:2px 6px;border-radius:3px;">'
             f'{html.escape(r.run_id)}</code>'),
            ("Status",
             f'<strong style="color:{wf_color};font-size:15px;">'
             f'{wf_icon} {r.status}</strong>'),
            ("Started",    html.escape(_fmt_dt(r.started_at))),
            ("Completed",  html.escape(_fmt_dt(r.completed_at))),
            ("Duration",   f'<strong>{html.escape(_fmt_duration(r.duration_seconds))}</strong>'),
            ("Is Retry",   retry_txt),
        ]
        info_html = _kv_table(info_rows)

        # ── summary ────────────────────────────────────────────────────
        summary_rows = [
            ("Groups",
             _badge(f"Total {len(r.groups)}", "#1565c0") + "&nbsp;" +
             _badge(f"&#x2705; {r.success_groups}", "#2e7d32") + "&nbsp;" +
             _badge(f"&#x274C; {r.failed_groups}", "#c62828") + "&nbsp;" +
             _badge(f"&#x23ED; {r.skipped_groups}", "#757575")),
            ("Tasks",
             _badge(f"Total {r.total_tasks}", "#1565c0") + "&nbsp;" +
             _badge(f"&#x2705; {r.success_tasks}", "#2e7d32") + "&nbsp;" +
             _badge(f"&#x274C; {r.failed_tasks}", "#c62828") + "&nbsp;" +
             _badge(f"&#x23ED; {r.skipped_tasks}", "#757575")),
            ("Total Records Ingested",
             f'<span style="font-size:18px;font-weight:700;color:#1565c0;">'
             f'{r.total_records:,}</span>'),
        ]
        summary_html = _kv_table(summary_rows)

        # ── group + task detail table ──────────────────────────────────
        tbody = ""
        for g in r.groups:
            g_color  = _status_color(g.status)
            g_icon   = _status_icon(g.status)
            g_dur    = html.escape(_fmt_duration(g.duration_seconds))
            g_rec    = f"{g.total_records:,}"
            g_dep    = html.escape(", ".join(g.depends_on) if g.depends_on else "—")

            # Group header row — spans all 5 task columns
            tbody += f"""
            <tr style="background:#f0f4f8;">
              <td colspan="5"
                  style="padding:10px 14px;
                         font-weight:700;font-size:13px;
                         border-left:4px solid {g_color};
                         border-top:2px solid #dee2e6;">
                <span style="font-size:16px;">{g_icon}</span>&nbsp;
                <span style="color:{g_color};">
                  Group: {html.escape(g.group_id)}
                </span>
                &nbsp;
                <span style="color:#555;font-weight:400;font-size:12px;">
                  Depends&nbsp;on:&nbsp;{g_dep}
                  &nbsp;|&nbsp;Duration:&nbsp;{g_dur}
                  &nbsp;|&nbsp;Records:&nbsp;{g_rec}
                  &nbsp;|&nbsp;Tasks:&nbsp;
                  <span style="color:#2e7d32;">&#x2705;{g.success_task_count}</span>&nbsp;
                  <span style="color:#c62828;">&#x274C;{g.failed_task_count}</span>&nbsp;
                  <span style="color:#757575;">&#x23ED;{g.skipped_task_count}</span>
                </span>
              </td>
            </tr>"""

            # Task rows
            for t in g.tasks:
                t_color = _status_color(t.status)
                t_icon  = _status_icon(t.status)
                t_dur   = html.escape(_fmt_duration(t.duration_seconds))

                if t.status == "SUCCESS":
                    rec_str  = f"{(t.records_written or 0):,}"
                    extras   = ""
                    if t.query_row_count:
                        extras += (
                            f'<br><small style="color:#555;">'
                            f'Query rows: {t.query_row_count:,}</small>'
                        )
                    if t.api_failure_count:
                        extras += (
                            f'<br><small style="color:#e65100;">'
                            f'API failures: {t.api_failure_count}</small>'
                        )
                    detail_cell = (
                        f'<strong style="color:#2e7d32;">{rec_str}</strong>'
                        f'<small style="color:#555;"> records ingested</small>'
                        f'{extras}'
                    )
                elif t.status == "FAILED":
                    err = html.escape(
                        (t.error_message or "unknown error")[:350]
                    )
                    detail_cell = (
                        f'<span style="color:#c62828;">'
                        f'<strong>ERROR:</strong> '
                        f'<span style="font-size:12px;">{err}</span></span>'
                    )
                else:  # SKIPPED
                    reason = html.escape(
                        (t.error_message or "skipped")[:200]
                    )
                    detail_cell = (
                        f'<span style="color:#757575;font-size:12px;">'
                        f'{reason}</span>'
                    )

                tbody += f"""
                <tr style="border-bottom:1px solid #e8ecef;">
                  <td style="padding:8px 14px 8px 32px;font-size:12px;">
                    <strong>{html.escape(t.task_name)}</strong>
                  </td>
                  <td style="padding:8px 10px;font-size:12px;color:#666;">
                    {html.escape(t.service_name or "—")}
                  </td>
                  <td style="padding:8px 10px;text-align:center;white-space:nowrap;">
                    <span style="font-size:16px;">{t_icon}</span><br>
                    <small style="color:{t_color};font-weight:600;">
                      {t.status}
                    </small>
                  </td>
                  <td style="padding:8px 10px;font-size:12px;
                             color:#555;text-align:right;white-space:nowrap;">
                    {t_dur}
                  </td>
                  <td style="padding:8px 14px;font-size:13px;">
                    {detail_cell}
                  </td>
                </tr>"""

        detail_table = f"""
        <table width="100%" cellpadding="0" cellspacing="0"
               style="border-collapse:collapse;
                      border:1px solid #dee2e6;border-radius:4px;">
          <thead>
            <tr style="background:#1565c0;color:#fff;">
              <th style="padding:10px 14px;text-align:left;
                         font-size:12px;font-weight:600;">
                Task Name
              </th>
              <th style="padding:10px 10px;text-align:left;
                         font-size:12px;font-weight:600;">
                Service
              </th>
              <th style="padding:10px 10px;text-align:center;
                         font-size:12px;font-weight:600;">
                Status
              </th>
              <th style="padding:10px 10px;text-align:right;
                         font-size:12px;font-weight:600;">
                Duration
              </th>
              <th style="padding:10px 14px;text-align:left;
                         font-size:12px;font-weight:600;">
                Records Ingested / Error Detail
              </th>
            </tr>
          </thead>
          <tbody>{tbody}</tbody>
        </table>"""

        # ── assemble full email ────────────────────────────────────────
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body style="margin:0;padding:0;background:#eef0f3;
             font-family:'Segoe UI',Arial,Helvetica,sans-serif;
             color:#212121;">

  <table width="100%" cellpadding="0" cellspacing="0"
         style="padding:32px 16px;">
    <tr>
      <td align="center">
        <table width="820" cellpadding="0" cellspacing="0"
               style="background:#ffffff;border-radius:6px;
                      box-shadow:0 2px 10px rgba(0,0,0,.10);">

          <!-- HEADER -->
          <tr><td>{header_html}</td></tr>

          <!-- WORKFLOW INFO -->
          <tr>
            <td style="padding:24px 28px 0;">
              <p style="margin:0 0 10px;font-size:12px;font-weight:700;
                        color:#1565c0;text-transform:uppercase;
                        letter-spacing:.6px;">
                Workflow Information
              </p>
              {info_html}
            </td>
          </tr>

          <!-- SUMMARY -->
          <tr>
            <td style="padding:20px 28px 0;">
              <p style="margin:0 0 10px;font-size:12px;font-weight:700;
                        color:#1565c0;text-transform:uppercase;
                        letter-spacing:.6px;">
                Execution Summary
              </p>
              {summary_html}
            </td>
          </tr>

          <!-- DETAIL TABLE -->
          <tr>
            <td style="padding:20px 28px 32px;">
              <p style="margin:0 0 10px;font-size:12px;font-weight:700;
                        color:#1565c0;text-transform:uppercase;
                        letter-spacing:.6px;">
                Group &amp; Task Detail
              </p>
              {detail_table}
            </td>
          </tr>

          <!-- FOOTER -->
          <tr>
            <td style="padding:14px 28px;background:#f8f9fa;
                       border-top:1px solid #dee2e6;
                       border-radius:0 0 6px 6px;">
              <p style="margin:0;font-size:11px;color:#9e9e9e;
                        text-align:center;">
                AWS Glue Workflow Orchestration Framework
                &nbsp;&bull;&nbsp;
                Auto-generated notification
                &nbsp;&bull;&nbsp;
                Do not reply to this email
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>

</body>
</html>"""


# ──────────────────────────────────────────────────────────────────────────────
# HTML helpers
# ──────────────────────────────────────────────────────────────────────────────

def _kv_table(rows: list[tuple[str, str]]) -> str:
    inner = ""
    for label, value in rows:
        inner += (
            f'<tr>'
            f'<td style="padding:5px 16px 5px 0;font-size:13px;color:#666;'
            f'white-space:nowrap;vertical-align:top;width:170px;">'
            f'{html.escape(label)}</td>'
            f'<td style="padding:5px 0;font-size:13px;color:#212121;">'
            f'{value}</td>'
            f'</tr>'
        )
    return (
        '<table cellpadding="0" cellspacing="0" '
        'style="border-collapse:collapse;width:100%;">'
        f'{inner}</table>'
    )


def _badge(text: str, color: str) -> str:
    return (
        f'<span style="display:inline-block;padding:3px 10px;'
        f'background:{color};color:#fff;border-radius:12px;'
        f'font-size:12px;font-weight:600;">{text}</span>'
    )


def _status_color(status: str) -> str:
    return {
        "SUCCESS": "#2e7d32",
        "FAILED":  "#c62828",
        "SKIPPED": "#757575",
    }.get(status, "#1565c0")


def _status_icon(status: str) -> str:
    return {
        "SUCCESS": "&#x2705;",   # ✅
        "FAILED":  "&#x274C;",   # ❌
        "SKIPPED": "&#x23ED;",   # ⏭
    }.get(status, "&#x1F535;")   # 🔵


# ──────────────────────────────────────────────────────────────────────────────
# Formatting helpers
# ──────────────────────────────────────────────────────────────────────────────

def _fmt_dt(dt: Optional[datetime]) -> str:
    if dt is None:
        return "—"
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.strftime("%Y-%m-%d %H:%M:%S UTC")


def _fmt_duration(seconds: Optional[float]) -> str:
    if seconds is None:
        return "—"
    s = int(seconds)
    if s < 60:
        return f"{s}s"
    m, s = divmod(s, 60)
    if m < 60:
        return f"{m}m {s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h {m:02d}m {s:02d}s"
