"""
utils/config_loader.py
─────────────────────────────────────────────────────────────────────────────
Loads all YAML configuration files directly from S3.

All three config file paths are passed as Glue job parameters — no SSM
parameter store indirection is needed.  This keeps the config loading
simple, auditable, and independent of SSM availability.

Config file naming convention (enforced by the loader):
    {workflow_name}_task_config.yaml
    {workflow_name}_workflow_config.yaml
    auth.yaml  (shared across workflows, path passed separately)

Glue job parameters resolved here:
    --config_s3_bucket          S3 bucket that holds all config files
    --config_s3_prefix          S3 key prefix (e.g. "glue/config")
                                The loader constructs full S3 URIs as:
                                  s3://{bucket}/{prefix}/{workflow_name}_task_config.yaml
                                  s3://{bucket}/{prefix}/{workflow_name}_workflow_config.yaml
    --auth_config_s3_path       Full S3 URI to the auth YAML
                                  e.g. s3://my-bucket/glue/config/auth.yaml

Alternative: pass full explicit paths as:
    --task_config_s3_path       Full S3 URI to the task config YAML
    --workflow_config_s3_path   Full S3 URI to the workflow config YAML

The explicit full-path params take precedence over the bucket+prefix
convention if both are provided.

Usage in glue_job_main.py:
    loader = ConfigLoader.from_args(args)
    task_cfg, workflow_cfg = loader.load_configs(workflow_name)
    auth_s3_path = loader.auth_config_s3_path
"""
import boto3
import yaml

from utils.logger import get_logger

logger = get_logger("config_loader")


class ConfigLoader:
    """
    Reads workflow and task YAML configs from S3.
    S3 URIs are derived from Glue job parameters — no SSM lookups.
    """

    def __init__(
        self,
        config_s3_bucket: str = "",
        config_s3_prefix: str = "",
        auth_config_s3_path: str = "",
        task_config_s3_path: str = "",
        workflow_config_s3_path: str = "",
    ):
        """
        config_s3_bucket / config_s3_prefix
            Used to auto-build config URIs using the naming convention:
                s3://{bucket}/{prefix}/{workflow_name}_task_config.yaml
                s3://{bucket}/{prefix}/{workflow_name}_workflow_config.yaml

        auth_config_s3_path
            Full S3 URI to the auth YAML file.
            Stored here so glue_job_main can retrieve it after construction.

        task_config_s3_path / workflow_config_s3_path
            Explicit full URIs. Take precedence over bucket+prefix when set.
        """
        self._bucket                  = config_s3_bucket.rstrip("/")
        self._prefix                  = config_s3_prefix.strip("/")
        self.auth_config_s3_path      = auth_config_s3_path
        self._explicit_task_path      = task_config_s3_path
        self._explicit_workflow_path  = workflow_config_s3_path
        self._s3                      = boto3.client("s3")

    # ------------------------------------------------------------------
    # Factory: build from Glue job args dict
    # ------------------------------------------------------------------

    @classmethod
    def from_args(cls, args: dict) -> "ConfigLoader":
        """
        Build a ConfigLoader from the Glue job args dict.

        Reads:
            config_s3_bucket          (required unless explicit paths given)
            config_s3_prefix          (optional, default empty)
            auth_config_s3_path       (optional — required if auth enabled)
            task_config_s3_path       (optional override)
            workflow_config_s3_path   (optional override)
        """
        return cls(
            config_s3_bucket        = args.get("config_s3_bucket", "").strip(),
            config_s3_prefix        = args.get("config_s3_prefix", "").strip(),
            auth_config_s3_path     = args.get("auth_config_s3_path", "").strip(),
            task_config_s3_path     = args.get("task_config_s3_path", "").strip(),
            workflow_config_s3_path = args.get("workflow_config_s3_path", "").strip(),
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_configs(self, workflow_name: str) -> tuple[dict, dict]:
        """
        Load and return (task_config, workflow_config) for the workflow.

        URI resolution order:
          1. Explicit --task_config_s3_path / --workflow_config_s3_path args
          2. Auto-built from --config_s3_bucket + --config_s3_prefix +
             naming convention:
               {prefix}/{workflow_name}_task_config.yaml
               {prefix}/{workflow_name}_workflow_config.yaml
        """
        task_uri     = self._resolve_task_uri(workflow_name)
        workflow_uri = self._resolve_workflow_uri(workflow_name)

        logger.info(f"Loading task config     : {task_uri}")
        logger.info(f"Loading workflow config : {workflow_uri}")
        if self.auth_config_s3_path:
            logger.info(f"Auth config path        : {self.auth_config_s3_path}")

        task_cfg     = self._read_yaml(task_uri)
        workflow_cfg = self._read_yaml(workflow_uri)

        # Validate minimal required keys
        if "taskConfig" not in task_cfg:
            raise ValueError(
                f"Task config at {task_uri} must have a top-level 'taskConfig:' key"
            )
        if "Workflow" not in workflow_cfg:
            raise ValueError(
                f"Workflow config at {workflow_uri} must have a top-level 'Workflow:' key"
            )

        logger.info(
            f"Loaded {len(task_cfg.get('taskConfig', {}))} task(s) from task config"
        )
        groups = workflow_cfg.get("Workflow", {}).get("Groups", [])
        logger.info(
            f"Loaded {len(groups)} group(s) from workflow config"
        )

        return task_cfg, workflow_cfg

    def load_auth_config(self) -> dict:
        """
        Load and return the auth YAML dict.
        Raises ValueError if auth_config_s3_path was not set.
        """
        if not self.auth_config_s3_path:
            raise ValueError(
                "auth_config_s3_path is not configured. "
                "Pass --auth_config_s3_path to the Glue job."
            )
        logger.info(f"Loading auth config: {self.auth_config_s3_path}")
        cfg = self._read_yaml(self.auth_config_s3_path)
        if "Auth" not in cfg:
            raise ValueError(
                f"Auth config at {self.auth_config_s3_path} must have a "
                f"top-level 'Auth:' key"
            )
        return cfg

    # ------------------------------------------------------------------
    # URI resolution
    # ------------------------------------------------------------------

    def _resolve_task_uri(self, workflow_name: str) -> str:
        if self._explicit_task_path:
            return self._explicit_task_path
        return self._build_uri(f"{workflow_name}_task_config.yaml")

    def _resolve_workflow_uri(self, workflow_name: str) -> str:
        if self._explicit_workflow_path:
            return self._explicit_workflow_path
        return self._build_uri(f"{workflow_name}_workflow_config.yaml")

    def _build_uri(self, filename: str) -> str:
        if not self._bucket:
            raise ValueError(
                "config_s3_bucket is required when explicit config paths are "
                "not provided. Pass --config_s3_bucket to the Glue job."
            )
        if self._prefix:
            key = f"{self._prefix}/{filename}"
        else:
            key = filename
        return f"s3://{self._bucket}/{key}"

    # ------------------------------------------------------------------
    # S3 read + YAML parse
    # ------------------------------------------------------------------

    def _read_yaml(self, s3_uri: str) -> dict:
        """Fetch an S3 object and parse it as YAML. Returns a dict."""
        bucket, key = _parse_s3_uri(s3_uri)
        logger.info(f"Reading s3://{bucket}/{key}")
        try:
            obj     = self._s3.get_object(Bucket=bucket, Key=key)
            content = obj["Body"].read().decode("utf-8")
        except self._s3.exceptions.NoSuchKey:
            raise FileNotFoundError(
                f"Config file not found: s3://{bucket}/{key}. "
                f"Ensure the file has been uploaded to S3."
            )
        parsed = yaml.safe_load(content)
        if not isinstance(parsed, dict):
            raise ValueError(
                f"Expected a YAML mapping at {s3_uri}, "
                f"got {type(parsed).__name__}"
            )
        return parsed


# ------------------------------------------------------------------
# Module-level helper
# ------------------------------------------------------------------

def _parse_s3_uri(uri: str) -> tuple[str, str]:
    """Split s3://bucket/key/path into (bucket, key/path)."""
    if not uri.startswith("s3://"):
        raise ValueError(f"Expected an s3:// URI, got: {uri!r}")
    rest   = uri[5:]
    parts  = rest.split("/", 1)
    bucket = parts[0]
    key    = parts[1] if len(parts) > 1 else ""
    if not bucket:
        raise ValueError(f"S3 URI has no bucket: {uri!r}")
    return bucket, key
