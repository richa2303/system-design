"""
utils/logger.py
Centralised structured logger for the Glue Workflow Framework.
"""
import logging
import sys


def get_logger(name: str = "glue_workflow") -> logging.Logger:
    """Return a logger wired to stdout with a consistent format."""
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger
